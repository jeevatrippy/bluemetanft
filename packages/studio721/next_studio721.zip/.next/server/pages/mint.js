"use strict";
(() => {
var exports = {};
exports.id = 687;
exports.ids = [687];
exports.modules = {

/***/ 7415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ BackgroundFill)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


const BackgroundFill = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function BackgroundFill({
  background
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      background
    }
  });
});

/***/ }),

/***/ 3458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ ColorPicker)
/* harmony export */ });
/* harmony import */ var _openpalette_color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4812);
/* harmony import */ var _openpalette_color__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openpalette_color__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var csscolorparser_ts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1572);
/* harmony import */ var csscolorparser_ts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(csscolorparser_ts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_colorful__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9559);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_colorful__WEBPACK_IMPORTED_MODULE_4__, designsystem__WEBPACK_IMPORTED_MODULE_2__]);
([react_colorful__WEBPACK_IMPORTED_MODULE_4__, designsystem__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






const ColorPicker = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function ColorPicker({
  color,
  onChange
}) {
  const parsedColor = (0,csscolorparser_ts__WEBPACK_IMPORTED_MODULE_1__.parseCSSColor)(color);
  const hexColor = parsedColor ? (0,_openpalette_color__WEBPACK_IMPORTED_MODULE_0__.rgbaToHex)({
    r: parsedColor[0] / 255,
    g: parsedColor[1] / 255,
    b: parsedColor[2] / 255,
    a: 1
  }) : '#000000';
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Popover */ .J2, {
    trigger: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("button", {
      style: {
        appearance: 'none',
        alignSelf: 'stretch',
        position: 'relative',
        margin: 0,
        padding: 0,
        borderRadius: '4px',
        overflow: 'hidden',
        width: '30px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        background: color,
        boxShadow: '0 0 0 1px rgba(255,255,255,0.1) inset'
      }
    }),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_colorful__WEBPACK_IMPORTED_MODULE_4__.HexColorPicker, {
      style: {
        width: 'auto',
        height: '200px'
      },
      color: hexColor,
      onChange: value => {
        onChange(value);
      }
    })
  });
});
});

/***/ }),

/***/ 7296:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ MintingCard)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9693);
/* harmony import */ var _radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9022);
/* harmony import */ var contract_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4044);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1801);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5781);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8531);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6221);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9772);
/* harmony import */ var _BackgroundFill__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7415);
/* harmony import */ var _MintingCardDetails__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5288);
/* harmony import */ var _contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7770);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MintingCardDetails__WEBPACK_IMPORTED_MODULE_12__, state__WEBPACK_IMPORTED_MODULE_7__, designsystem__WEBPACK_IMPORTED_MODULE_4__, _contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__]);
([_MintingCardDetails__WEBPACK_IMPORTED_MODULE_12__, state__WEBPACK_IMPORTED_MODULE_7__, designsystem__WEBPACK_IMPORTED_MODULE_4__, _contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}


















function useTokenImageUrl({
  abi,
  contract,
  chainId,
  tokenId
}) {
  const tokenURIFunction = abi.functions['tokenURI(uint256)'];
  const tokenURIResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_3__/* .useReadOnlyContractData */ .IH)({
    fragment: tokenURIFunction,
    contract,
    chainId,
    args: [tokenId]
  });
  const proxyTokenURI = tokenURIResult.type === 'success' ? (0,_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__/* .proxyURL */ .u2)((0,_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__/* .baseURIToHTTPS */ .C3)(tokenURIResult.value)) : undefined;
  const tokenMetadata = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useFetch */ .ib)(proxyTokenURI, 'json');
  if (tokenMetadata.type !== 'success') return tokenMetadata;
  return {
    type: 'success',
    value: {
      name: tokenMetadata.value.name || '',
      imageUrl: (0,_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_13__/* .baseURIToHTTPS */ .C3)(tokenMetadata.value.image || '')
    }
  };
}

function MintedTokenCard({
  abi,
  contract,
  chainId,
  tokenId,
  invert
}) {
  const metadata = useTokenImageUrl({
    abi,
    contract,
    chainId,
    tokenId
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
    gap: 4,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
      alignItems: "center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Body */ .uT, {
        children: metadata.type === 'success' && metadata.value.name
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .zx, {
        as: "a",
        href: (0,web3_utils__WEBPACK_IMPORTED_MODULE_10__/* .getOpenSeaUrl */ .TN)(chainId, contract.address, tokenId),
        target: '_blank',
        rel: 'noreferrer',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .OpenSeaLogoIcon */ .CT, {
          width: 20,
          height: 20
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_0__.Root, {
      ratio: 1,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
        position: "absolute",
        inset: "0",
        overflow: "hidden",
        children: [metadata.type !== 'success' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
          flex: "1",
          alignItems: "center",
          justifyContent: "center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
            className: "flickerAnimation",
            children: "Loading..."
          })
        }), metadata.type === 'success' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("img", {
          alt: "Token preview",
          src: metadata.value.imageUrl,
          style: _objectSpread({
            maxWidth: '100%',
            objectFit: 'cover',
            objectPosition: 'center'
          }, invert && {
            filter: 'invert()'
          })
        })]
      })
    })]
  });
}

const Grid = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "MintingCard__Grid",
  componentId: "sc-1bivjz6-0"
})({
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(120px, calc(50% - 5px)))',
  gridTemplateRows: '1fr',
  gridGap: '10px',
  flex: '1 1 0%'
});

function MintedTokenGrid({
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
    id: "container",
    flex: "1 1 auto",
    position: "relative",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
      overflowY: "auto",
      position: "absolute",
      inset: "0",
      breakpoints: {
        [800]: {
          position: 'relative',
          maxHeight: '600px',
          inset: 'initial'
        }
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(Grid, {
        children: children
      })
    })
  });
}

async function handleMint(contract, options) {
  const signer = (0,utils__WEBPACK_IMPORTED_MODULE_9__.getSignerFromProvider)(contract.provider);
  if (!contract || !signer) return contexts__WEBPACK_IMPORTED_MODULE_2__/* .FAILURE_NOT_LOADED */ .Sp;
  contract = contract.connect(signer);
  const mintFunction = (0,utils__WEBPACK_IMPORTED_MODULE_9__.getFirstFunctionFragment)(contract.interface, {
    name: 'mint'
  });

  if (!mintFunction) {
    return {
      type: 'failure',
      reason: 'error',
      message: `Couldn't find compatible mint function`
    };
  }

  const mintParameters = (0,_MintingCardDetails__WEBPACK_IMPORTED_MODULE_12__/* .getMintingParameters */ .BR)(mintFunction, options.parameterMapping);

  if (!mintParameters) {
    return {
      type: 'failure',
      reason: 'error',
      message: `This site doesn't support minting with this contract. Not all mint functions are supported.`
    };
  }

  try {
    const count = Number(options.countInputValue);

    if (mintFunction.payable && options.price === undefined) {
      return {
        type: 'failure',
        reason: 'error',
        message: `Mint price isn't properly defined.`
      };
    }

    const args = [...mintParameters.flatMap(name => name === options.parameterMapping.count ? [count] : []), ...(mintFunction.payable ? [{
      value: options.price.mul(count)
    }] : [])]; // console.log('mint args', args, options.price.mul(count).toString());

    const transaction = await contract.mint(...args);
    const result = await transaction.wait();
    const tokenIds = result.events.filter(event => event.event === 'Transfer').flatMap(event => {
      var _event$args;

      const tokenId = (_event$args = event.args) === null || _event$args === void 0 ? void 0 : _event$args.tokenId;
      return tokenId !== undefined ? [tokenId.toNumber()] : [];
    });
    return {
      type: 'success',
      tokenIds
    };
  } catch (error) {
    console.warn(error);
    if (!('code' in error)) return contexts__WEBPACK_IMPORTED_MODULE_2__/* .FAILURE_UNKNOWN */ .g7;
    if (error.code === 4001) return contexts__WEBPACK_IMPORTED_MODULE_2__/* .FAILURE_ABORTED */ .l;
    return {
      type: 'failure',
      reason: 'error',
      message: error.message
    };
  }
}

function MintingCard({
  editing,
  title,
  intrinsicName,
  description,
  contract,
  abi,
  background,
  invertForeground,
  coverAsset,
  contractChainId,
  dataSources,
  dispatch
}) {
  const theme = (0,styled_components__WEBPACK_IMPORTED_MODULE_8__.useTheme)();
  const {
    0: mintingState,
    1: dispatchMintingState
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useReducer)(state__WEBPACK_IMPORTED_MODULE_7__/* .mintStateReducer */ .FV, {
    type: 'ready'
  });
  const widthNumber = Number(coverAsset.size.width);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
    order: 1,
    position: "relative",
    maxWidth: coverAsset.size.width && !isNaN(widthNumber) ? Math.max(widthNumber, 800) : 500,
    borderRadius: 4,
    overflow: "hidden",
    padding: '30px 40px',
    boxShadow: ['2.8px 2.8px 2.2px rgba(0, 0, 0, 0.02)', '6.7px 6.7px 5.3px rgba(0, 0, 0, 0.028)', '12.5px 12.5px 10px rgba(0, 0, 0, 0.035)', '22.3px 22.3px 17.9px rgba(0, 0, 0, 0.042)', '41.8px 41.8px 33.4px rgba(0, 0, 0, 0.05)', '100px 100px 80px rgba(0, 0, 0, 0.07)'].join(', '),
    breakpoints: {
      [600]: {
        padding: '20px'
      }
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_BackgroundFill__WEBPACK_IMPORTED_MODULE_11__/* .BackgroundFill */ .o, {
      background: background
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
      gap: 20,
      filter: invertForeground ? 'invert()' : undefined,
      children: [mintingState.type === 'ready' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_MintingCardDetails__WEBPACK_IMPORTED_MODULE_12__/* .MintingCardDetails */ .zv, {
        editing: editing,
        title: title,
        intrinsicName: intrinsicName,
        description: description,
        contract: contract,
        abi: abi,
        invertForeground: invertForeground,
        coverAsset: coverAsset,
        contractChainId: contractChainId,
        dataSources: dataSources,
        dispatch: dispatch,
        onClickMint: async options => {
          if (!contract) return;
          dispatchMintingState({
            type: 'mint'
          });
          const status = await handleMint(contract, options);

          switch (status.type) {
            case 'success':
              dispatchMintingState({
                type: 'success',
                tokenIds: status.tokenIds
              });
              return;

            case 'failure':
              if (status.reason === 'aborted') {
                dispatchMintingState({
                  type: 'reset'
                });
                return;
              }

              dispatchMintingState({
                type: 'failure',
                message: status.message,
                reason: status.reason
              });
              return;
          }
        }
      }), mintingState.type === 'minting' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
        maxWidth: 250,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Body */ .uT, {
          className: "flickerAnimation",
          children: "Minting..."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 10
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "After you confirm the transaction, this typically takes between 20 seconds to 1 minute, but can take longer."
        })]
      }), mintingState.type === 'success' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Body */ .uT, {
          children: "Success!"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 4
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: ["You minted", ' ', title || (intrinsicName.type === 'success' ? intrinsicName.value : ''), ' ', mintingState.tokenIds.map(n => `#${n}`).join(', '), "."]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 4
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Note: NFTs may take 30 minutes or longer before they appear on marketplaces like OpenSea."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
          minWidth: 250,
          children: mintingState.tokenIds.length > 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_0__.Root, {
            ratio: 1,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
              position: "absolute",
              inset: "0",
              overflow: "hidden",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(MintedTokenGrid, {
                children: contract && mintingState.tokenIds.map(id => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(MintedTokenCard, {
                  invert: invertForeground,
                  tokenId: id,
                  abi: abi,
                  contract: contract,
                  chainId: contractChainId
                }, id.toString()))
              })
            })
          }) : contract && mintingState.tokenIds.map(id => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(MintedTokenCard, {
            invert: invertForeground,
            tokenId: id,
            abi: abi,
            contract: contract,
            chainId: contractChainId
          }, id.toString()))
        })]
      }), mintingState.type === 'failure' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Body */ .uT, {
          children: "Looks like there was an error."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 10
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Here's what we know:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 10
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
          height: 200,
          background: theme.colors.inputBackground,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .ScrollableStack */ .nq, {
            innerProps: {
              padding: 10
            },
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Code */ .EK, {
              children: mintingState.message
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 10
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Please refresh if you'd like to try again."
        })]
      })]
    })]
  });
}
});

/***/ }),

/***/ 4270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dB": () => (/* binding */ decodeConfigParameter),
/* harmony export */   "VX": () => (/* binding */ useUrlConfigReducer)
/* harmony export */ });
/* unused harmony export encodeConfigParameter */
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}



const SCHEMA_VERSION_KEY = 'schemaVersion';
function decodeConfigParameter(configString) {
  try {
    const config = JSON.parse(decodeURIComponent(configString));
    delete config[SCHEMA_VERSION_KEY];
    return config;
  } catch {
    return {};
  }
}
function encodeConfigParameter(state, createInitialState) {
  const json = JSON.stringify(_objectSpread(_objectSpread({}, cloneChangedProperties(state, createInitialState)), {}, {
    [SCHEMA_VERSION_KEY]: '1.0.0'
  }));
  return encodeURIComponent(json);
}

function cloneChangedProperties(state, createInitialState) {
  const initialState = createInitialState();
  if (JSON.stringify(state) === JSON.stringify(initialState)) return;

  const clone = _objectSpread({}, state);

  Object.entries(initialState).forEach(([key, value]) => {
    if (JSON.stringify(clone[key]) === JSON.stringify(value)) {
      delete clone[key];
    }

    if (typeof clone[key] === 'object' && clone[key] !== null) {
      const result = cloneChangedProperties(state[key], () => initialState[key]);

      if (result === undefined) {
        delete clone[key];
      } else {
        clone[key] = result;
      }
    }
  });
  return clone;
}

function useUrlConfigReducer({
  reducer,
  createInitialState
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)(); // The initial config passed to `useReducer`

  const initialConfig = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => {
    if (typeof router.query.config !== 'string') return {};
    return decodeConfigParameter(router.query.config);
  }, [router.query.config]);
  const {
    0: state,
    1: dispatch
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, createInitialState(initialConfig));
  const updatedConfig = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => {
    return `config=${encodeConfigParameter(state, createInitialState)}`;
  }, [createInitialState, state]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (router.asPath.includes(updatedConfig)) return;
    router.replace({
      query: updatedConfig
    }, undefined, {
      scroll: false,
      shallow: true
    });
  }, [updatedConfig, router]);
  return [state, dispatch];
}

/***/ }),

/***/ 7427:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Mint),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2792);
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_contracts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _openpalette_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4812);
/* harmony import */ var _openpalette_color__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openpalette_color__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9022);
/* harmony import */ var contract_data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4044);
/* harmony import */ var csscolorparser_ts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1572);
/* harmony import */ var csscolorparser_ts__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(csscolorparser_ts__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1801);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5781);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8531);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9772);
/* harmony import */ var _assets_slim_gwei_abi_json__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6828);
/* harmony import */ var _components_mint_BackgroundFill__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7415);
/* harmony import */ var _components_mint_ColorPicker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3458);
/* harmony import */ var _components_mint_MintingCard__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7296);
/* harmony import */ var _components_mint_MintingCardDetails__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5288);
/* harmony import */ var _hooks_useUrlConfigReducer__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4270);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_9__, _components_mint_ColorPicker__WEBPACK_IMPORTED_MODULE_16__, _components_mint_MintingCard__WEBPACK_IMPORTED_MODULE_17__, _components_mint_MintingCardDetails__WEBPACK_IMPORTED_MODULE_18__, state__WEBPACK_IMPORTED_MODULE_12__]);
([designsystem__WEBPACK_IMPORTED_MODULE_9__, _components_mint_ColorPicker__WEBPACK_IMPORTED_MODULE_16__, _components_mint_MintingCard__WEBPACK_IMPORTED_MODULE_17__, _components_mint_MintingCardDetails__WEBPACK_IMPORTED_MODULE_18__, state__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}























 // If this is a delegated contract, we need to add in the delegated
// ABI to be able to call those functions. This primitive check for
// `implementation` could be improved, but is probably fine for now
//
// Currently it seems ether.actor doesn't support calling the delegated
// functions, so this will only work if there's a connected wallet

function addDelegatedImplementation(abi) {
  const isDelegatedContract = abi.find(item => item.name === 'implementation');
  return isDelegatedContract ? [...abi, ..._assets_slim_gwei_abi_json__WEBPACK_IMPORTED_MODULE_14__] : abi;
}

function Mint({
  isAddressLocked,
  isCreatorLocked,
  abi: serverAbi
}) {
  var _useWeb3Data, _useChainId;

  const {
    connect
  } = (0,contexts__WEBPACK_IMPORTED_MODULE_6__/* .useWeb3API */ .ry)();
  const address = (0,contexts__WEBPACK_IMPORTED_MODULE_6__/* .useAddress */ .SF)();
  const provider = (_useWeb3Data = (0,contexts__WEBPACK_IMPORTED_MODULE_6__/* .useWeb3Data */ .Rf)()) === null || _useWeb3Data === void 0 ? void 0 : _useWeb3Data.provider;
  const chainId = (_useChainId = (0,contexts__WEBPACK_IMPORTED_MODULE_6__/* .useChainId */ .xx)()) !== null && _useChainId !== void 0 ? _useChainId : _openpalette_contract__WEBPACK_IMPORTED_MODULE_3__.CHAIN_ID.MAINNET;
  const [style, dispatch] = (0,_hooks_useUrlConfigReducer__WEBPACK_IMPORTED_MODULE_19__/* .useUrlConfigReducer */ .VX)({
    reducer: state__WEBPACK_IMPORTED_MODULE_12__/* .mintStyleReducer */ .JY,
    createInitialState: state__WEBPACK_IMPORTED_MODULE_12__/* .createInitialMintStyle */ .VT
  });
  const {
    0: showStyleEditor,
    1: setShowStyleEditor
  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
  const etherActorAbi = (0,hooks__WEBPACK_IMPORTED_MODULE_10__/* .useFetch */ .ib)(style.contractAddress ? `${(0,web3_utils__WEBPACK_IMPORTED_MODULE_13__/* .getEtherActorBaseURL */ .Ui)(style.chainId || chainId)}/${style.contractAddress}.json` : undefined);
  (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(() => {
    if (!serverAbi && etherActorAbi.type !== 'success') return; // If there's already a chainId, don't overwrite

    if (style.chainId) return; // Note that this also updates the url in the case where we have a serverAbi
    // but no style.chainId. It will default to mainnet.

    dispatch({
      type: 'setChainId',
      value: chainId
    });
  }, [serverAbi, etherActorAbi, style.chainId, chainId, dispatch]);
  (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(() => {
    if (isCreatorLocked || !address) return;
    dispatch({
      type: 'setCreatorAddress',
      value: address
    });
  }, [isCreatorLocked, address, dispatch]);
  const abi = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(() => {
    if (serverAbi) {
      return new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__.Interface(addDelegatedImplementation(serverAbi));
    }

    if (etherActorAbi.type !== 'success') return;
    return new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__.Interface(addDelegatedImplementation(etherActorAbi.value.abi));
  }, [etherActorAbi, serverAbi]);
  const contract = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(() => {
    if (!abi) return;
    return new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_1__.Contract(style.contractAddress, abi, provider);
  }, [style.contractAddress, abi, provider]);
  const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_11__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(() => {
    var _inputRef$current;

    (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 ? void 0 : _inputRef$current.focus();
  }, []);
  const parsedBackground = (0,csscolorparser_ts__WEBPACK_IMPORTED_MODULE_8__.parseCSSColor)(style.background);
  const parsedCardBackground = (0,csscolorparser_ts__WEBPACK_IMPORTED_MODULE_8__.parseCSSColor)(style.cardBackground);
  const actualBackground = parsedCardBackground && parsedCardBackground[3] > 0 ? parsedCardBackground : parsedBackground;
  const invertForeground = actualBackground ? (0,_openpalette_color__WEBPACK_IMPORTED_MODULE_2__.getLuminance)({
    r: actualBackground[0] / 255,
    g: actualBackground[1] / 255,
    b: actualBackground[2] / 255
  }) > 0.5 : false;
  const nameFunction = abi ? abi.functions['name()'] : undefined;
  const nameResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_7__/* .useReadOnlyContractData */ .IH)({
    fragment: nameFunction,
    contract,
    chainId: style.chainId
  }); // TODO: When abi is fetched and we know contract address is OK, put
  // chainname in config and use that to fetch from server. Show error if
  // user's wallet is connected to the wrong network

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
    flex: '1 1 auto',
    position: "relative",
    children: [!abi && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_BackgroundFill__WEBPACK_IMPORTED_MODULE_15__/* .BackgroundFill */ .o, {
      background: style.background
    }), !serverAbi && etherActorAbi.type !== 'success' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
      flex: "1",
      alignItems: "center",
      justifyContent: "center",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
        width: 450,
        gap: 20,
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Heading2 */ .XJ, {
            textAlign: "center",
            children: "Contract Address"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .SpacerVertical */ .Nw, {
            size: 20
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Root */ .UP.fC, {
              id: "input-contract-address",
              flex: "1",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Input */ .UP.II, {
                ref: inputRef,
                disabled: isAddressLocked,
                value: style.contractAddress,
                placeholder: 'Enter Contract Address',
                type: "text",
                style: {
                  textAlign: 'center',
                  padding: '8px 8px',
                  fontSize: '16px',
                  fontFamily: 'monospace'
                },
                onChange: value => {
                  dispatch({
                    type: 'setContractAddress',
                    value
                  });
                }
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .SpacerVertical */ .Nw, {
            size: 10
          }), style.contractAddress && etherActorAbi.type === 'pending' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.Fragment, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Body */ .uT, {
              textAlign: "center",
              fontFamily: "monospace",
              className: "flickerAnimation",
              children: "Loading..."
            })
          }), etherActorAbi.type === 'failure' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Body */ .uT, {
              textAlign: "center",
              color: "red",
              fontFamily: "monospace",
              children: etherActorAbi.value.message
            }), !provider && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.Fragment, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .SpacerVertical */ .Nw, {
                size: 10
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Blockquote */ .V6, {
                children: "If this contract is on a network other than Ethereum mainnet, please connect your wallet first."
              })]
            })]
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Divider */ .iz, {
          variant: "light"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
            alignItems: "center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Heading3 */ .aC, {
              children: "Connected Wallet"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .SpacerHorizontal */ .lC, {}), provider ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .ConnectionDisplay */ .Vn, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_MintingCardDetails__WEBPACK_IMPORTED_MODULE_18__/* .SimplePrimaryButton */ .XQ, {
              onClick: connect,
              children: "Connect wallet"
            })]
          })
        })]
      })
    }), abi && style.chainId && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
      flex: "1 1 auto",
      position: "relative",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_BackgroundFill__WEBPACK_IMPORTED_MODULE_15__/* .BackgroundFill */ .o, {
        background: style.background
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
        flex: "2",
        padding: 40,
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        breakpoints: {
          [600]: {
            padding: 20
          }
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
          position: "relative",
          gap: 20,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_MintingCard__WEBPACK_IMPORTED_MODULE_17__/* .MintingCard */ .b, {
            dispatch: dispatch,
            editing: showStyleEditor,
            intrinsicName: nameResult,
            title: style.title,
            description: style.description || undefined,
            abi: abi,
            contract: contract,
            background: style.cardBackground,
            invertForeground: invertForeground,
            coverAsset: style.coverAsset,
            contractChainId: style.chainId,
            dataSources: style.dataSources
          }), (!isAddressLocked || style.creatorAddress === address) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
            position: "absolute",
            left: 'calc(100% + 20px)',
            top: 0,
            alignItems: "flex-start",
            gap: 20,
            breakpoints: {
              [800]: {
                position: 'unset'
              }
            },
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
              background: "#222",
              borderRadius: 4,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .Button */ .zx, {
                onClick: () => setShowStyleEditor(!showStyleEditor),
                children: [showStyleEditor ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4__.CheckIcon, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4__.Pencil1Icon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .SpacerHorizontal */ .lC, {
                  size: 8,
                  inline: true
                }), showStyleEditor ? 'Confirm' : 'Edit']
              })
            }), showStyleEditor && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
              minWidth: 300,
              gap: 8,
              background: "#222",
              borderRadius: 4,
              padding: "4px 6px",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .FormRow */ .p7, {
                variant: "small",
                title: "Background",
                tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
                  gap: 20,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                    children: "This field supports any CSS background value. You can use solid colors, gradients, images, multiple backgrounds, and more."
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                    children: ["Example gradient:", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("code", {
                      style: {
                        background: '#222',
                        padding: '2px 4px',
                        borderRadius: '2px'
                      },
                      children: "linear-gradient(pink, black)"
                    })]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                    children: ["Example Image:", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("code", {
                      style: {
                        background: '#222',
                        padding: '2px 4px',
                        borderRadius: '2px'
                      },
                      children: "center/cover url(\"https://picsum.photos/id/237/500/500\")"
                    })]
                  })]
                }),
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
                  flex: "1",
                  gap: 6,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_ColorPicker__WEBPACK_IMPORTED_MODULE_16__/* .ColorPicker */ .z, {
                    color: style.background,
                    onChange: value => {
                      dispatch({
                        type: 'setBackground',
                        value
                      });
                    }
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Root */ .UP.fC, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Input */ .UP.II, {
                      value: style.background,
                      onChange: value => {
                        dispatch({
                          type: 'setBackground',
                          value
                        });
                      }
                    })
                  })]
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .FormRow */ .p7, {
                variant: "small",
                title: "Card Color",
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
                  flex: "1",
                  gap: 6,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_ColorPicker__WEBPACK_IMPORTED_MODULE_16__/* .ColorPicker */ .z, {
                    color: style.cardBackground,
                    onChange: value => {
                      dispatch({
                        type: 'setCardBackground',
                        value
                      });
                    }
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Root */ .UP.fC, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Input */ .UP.II, {
                      value: style.cardBackground,
                      onChange: value => {
                        dispatch({
                          type: 'setCardBackground',
                          value
                        });
                      }
                    })
                  })]
                })
              })]
            }), showStyleEditor && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .VStack */ .gC, {
              minWidth: 300,
              gap: 8,
              background: "#222",
              borderRadius: 4,
              padding: "4px 6px",
              alignSelf: "start",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Heading3 */ .aC, {
                children: "How it works"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                children: "The configuration for this page is stored in your browser's URL (address bar). When you're done editing, you can share the URL and collectors can mint with it."
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                children: ["We recommend using a URL shortener like", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("a", {
                  href: "https://bitly.com/",
                  target: "_blank",
                  rel: "noreferrer",
                  children: "bitly \u2192"
                }), ", both so the URL looks nicer, and so you can make updates to it after sharing."]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Small */ .x4, {
                children: "You can edit your page if you connect with the same wallet. If you make edits, you'll need to re-share the new URL and/or update any shortened URL links."
              })]
            })]
          })]
        })
      })]
    }), abi && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
      position: "relative",
      padding: '20px 40px',
      gap: 20,
      breakpoints: {
        [1000]: {
          flexDirection: 'column',
          padding: '20px',
          order: 0
        }
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_mint_BackgroundFill__WEBPACK_IMPORTED_MODULE_15__/* .BackgroundFill */ .o, {
        background: style.cardBackground || style.background
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
        flex: "1",
        alignItems: "center",
        gap: 20,
        filter: invertForeground ? 'invert()' : undefined,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Heading3 */ .aC, {
          children: "NFT Contract Address"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
          alignSelf: "stretch",
          gap: 10,
          flex: "1",
          maxWidth: 470,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Root */ .UP.fC, {
            id: "input-multi-mint",
            flex: "1",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .InputField.Input */ .UP.II, {
              value: style.contractAddress // disabled
              ,
              type: "text",
              style: {
                textAlign: 'center',
                padding: '8px 8px',
                fontSize: '16px',
                fontFamily: 'monospace'
              },
              onChange: value => {}
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_9__/* .Button */ .zx, {
            as: "a",
            href: (0,web3_utils__WEBPACK_IMPORTED_MODULE_13__/* .getEtherscanAddressUrl */ .YU)(chainId, style.contractAddress),
            target: '_blank',
            rel: 'noreferrer',
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_4__.ExternalLinkIcon, {})
          })]
        })]
      }), address && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(components__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .Ug, {
        alignItems: "center",
        gap: 20,
        filter: invertForeground ? 'invert()' : undefined,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .Heading3 */ .aC, {
          children: "Wallet"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(components__WEBPACK_IMPORTED_MODULE_5__/* .ConnectionDisplay */ .Vn, {})]
      })]
    })]
  });
}
async function getServerSideProps(context) {
  const parsedConfig = (0,_hooks_useUrlConfigReducer__WEBPACK_IMPORTED_MODULE_19__/* .decodeConfigParameter */ .dB)(context.query.config);
  let abi;

  try {
    if (parsedConfig.contractAddress) {
      var _parsedConfig$chainId;

      const response = await fetch(`${(0,web3_utils__WEBPACK_IMPORTED_MODULE_13__/* .getEtherActorBaseURL */ .Ui)((_parsedConfig$chainId = parsedConfig.chainId) !== null && _parsedConfig$chainId !== void 0 ? _parsedConfig$chainId : _openpalette_contract__WEBPACK_IMPORTED_MODULE_3__.CHAIN_ID.MAINNET)}/${parsedConfig.contractAddress}.json`);
      const data = await response.json();
      abi = data.abi;
    }
  } catch {//
  }

  return {
    props: _objectSpread({
      isAddressLocked: !!parsedConfig.contractAddress,
      isCreatorLocked: !!parsedConfig.creatorAddress
    }, abi && {
      abi
    })
  };
}
});

/***/ }),

/***/ 3831:
/***/ ((module) => {

module.exports = require("@dnd-kit/core");

/***/ }),

/***/ 8196:
/***/ ((module) => {

module.exports = require("@dnd-kit/sortable");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 5757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 2792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 3138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 3427:
/***/ ((module) => {

module.exports = require("@metamask/detect-provider");

/***/ }),

/***/ 4812:
/***/ ((module) => {

module.exports = require("@openpalette/color");

/***/ }),

/***/ 4008:
/***/ ((module) => {

module.exports = require("@openpalette/contract");

/***/ }),

/***/ 290:
/***/ ((module) => {

module.exports = require("@radix-ui/primitive");

/***/ }),

/***/ 374:
/***/ ((module) => {

module.exports = require("@radix-ui/react-accordion");

/***/ }),

/***/ 9693:
/***/ ((module) => {

module.exports = require("@radix-ui/react-aspect-ratio");

/***/ }),

/***/ 7093:
/***/ ((module) => {

module.exports = require("@radix-ui/react-checkbox");

/***/ }),

/***/ 5344:
/***/ ((module) => {

module.exports = require("@radix-ui/react-compose-refs");

/***/ }),

/***/ 5766:
/***/ ((module) => {

module.exports = require("@radix-ui/react-context-menu");

/***/ }),

/***/ 3363:
/***/ ((module) => {

module.exports = require("@radix-ui/react-dialog");

/***/ }),

/***/ 8532:
/***/ ((module) => {

module.exports = require("@radix-ui/react-dropdown-menu");

/***/ }),

/***/ 599:
/***/ ((module) => {

module.exports = require("@radix-ui/react-hover-card");

/***/ }),

/***/ 2132:
/***/ ((module) => {

module.exports = require("@radix-ui/react-icons");

/***/ }),

/***/ 8456:
/***/ ((module) => {

module.exports = require("@radix-ui/react-popover");

/***/ }),

/***/ 8375:
/***/ ((module) => {

module.exports = require("@radix-ui/react-progress");

/***/ }),

/***/ 5213:
/***/ ((module) => {

module.exports = require("@radix-ui/react-scroll-area");

/***/ }),

/***/ 8034:
/***/ ((module) => {

module.exports = require("@radix-ui/react-slider");

/***/ }),

/***/ 999:
/***/ ((module) => {

module.exports = require("@radix-ui/react-tooltip");

/***/ }),

/***/ 424:
/***/ ((module) => {

module.exports = require("car-file");

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ }),

/***/ 1572:
/***/ ((module) => {

module.exports = require("csscolorparser-ts");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 3922:
/***/ ((module) => {

module.exports = require("imfs");

/***/ }),

/***/ 7133:
/***/ ((module) => {

module.exports = require("immer");

/***/ }),

/***/ 4053:
/***/ ((module) => {

module.exports = require("language-tools");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3920:
/***/ ((module) => {

module.exports = require("prettier");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 4607:
/***/ ((module) => {

module.exports = require("prism-react-renderer/prism");

/***/ }),

/***/ 4196:
/***/ ((module) => {

module.exports = require("prism-react-renderer/themes/vsDark");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6325:
/***/ ((module) => {

module.exports = require("react-virtualized");

/***/ }),

/***/ 551:
/***/ ((module) => {

module.exports = require("react-window");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 4940:
/***/ ((module) => {

module.exports = require("tree-visit");

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = import("fflate");;

/***/ }),

/***/ 9559:
/***/ ((module) => {

module.exports = import("react-colorful");;

/***/ }),

/***/ 7597:
/***/ ((module) => {

module.exports = import("w3c-keyname");;

/***/ }),

/***/ 6828:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"__burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"__exists","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"__isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"__isApprovedOrOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"__mint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"__owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"uriBase","type":"string"},{"internalType":"string","name":"uriExtension","type":"string"}],"name":"__setBaseURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"__tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"advancedConfig","outputs":[{"internalType":"uint16","name":"royaltyBps","type":"uint16"},{"internalType":"string","name":"uriBase","type":"string"},{"internalType":"string","name":"uriExtension","type":"string"},{"internalType":"bool","name":"hasTransferHook","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"deployedBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"string","name":"_name","type":"string"},{"internalType":"string","name":"_symbol","type":"string"},{"components":[{"internalType":"uint16","name":"royaltyBps","type":"uint16"},{"internalType":"string","name":"uriBase","type":"string"},{"internalType":"string","name":"uriExtension","type":"string"},{"internalType":"bool","name":"hasTransferHook","type":"bool"}],"internalType":"struct ConfigSettings","name":"settings","type":"tuple"}],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"_salePrice","type":"uint256"}],"name":"royaltyInfo","outputs":[{"internalType":"address","name":"receiver","type":"address"},{"internalType":"uint256","name":"royaltyAmount","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}]');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [945,97,615,621,898,44,288,770], () => (__webpack_exec__(7427)));
module.exports = __webpack_exports__;

})();
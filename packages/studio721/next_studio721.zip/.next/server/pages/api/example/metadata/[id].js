"use strict";
(() => {
var exports = {};
exports.id = 489;
exports.ids = [489];
exports.modules = {

/***/ 3582:
/***/ ((module) => {

module.exports = require("cors");

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3582);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cors__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3822);
/* harmony import */ var _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1816);


 // Initialize the cors middleware

const cors = (0,utils__WEBPACK_IMPORTED_MODULE_1__.initMiddleware)( // You can read more about the available options here: https://github.com/expressjs/cors#configuration-options
cors__WEBPACK_IMPORTED_MODULE_0___default()({
  // Only allow requests with GET, POST and OPTIONS
  methods: ['GET', 'POST', 'OPTIONS']
}));
async function handler(req, res) {
  const {
    id
  } = req.query;
  await cors(req, res);
  const item = _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__/* .picsumItems */ .d[Number(id) % _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__/* .picsumItems.length */ .d.length];
  res.status(200).json({
    name: `Token #${id}`,
    description: `An example nonfungible token. Photo by ${item.author} from https://picsum.photos.`,
    image: `https://picsum.photos/id/${item.id}/510/510`,
    external_url: item.url,
    animation_url: item.download_url,
    attributes: [{
      trait_type: 'Width',
      value: item.width
    }, {
      trait_type: 'Height',
      value: item.height
    }]
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [822,816], () => (__webpack_exec__(3588)));
module.exports = __webpack_exports__;

})();
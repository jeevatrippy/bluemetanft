"use strict";
(() => {
var exports = {};
exports.id = 394;
exports.ids = [394];
exports.modules = {

/***/ 3582:
/***/ ((module) => {

module.exports = require("cors");

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3582);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cors__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3822);
/* harmony import */ var _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1816);


 // import fetch from 'cross-fetch';

const cors = (0,utils__WEBPACK_IMPORTED_MODULE_1__.initMiddleware)(cors__WEBPACK_IMPORTED_MODULE_0___default()({
  methods: ['GET', 'POST', 'OPTIONS']
}));
async function handler(req, res) {
  const {
    id
  } = req.query;
  await cors(req, res);
  const item = _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__/* .picsumItems */ .d[Number(id) % _utils_exampleImages__WEBPACK_IMPORTED_MODULE_2__/* .picsumItems.length */ .d.length];
  const url = `https://picsum.photos/id/${item.id}/510/510`;
  res.redirect(url); // try {
  //   const response = await fetch(url as string);
  //   if (response.status >= 400) {
  //     res.status(response.status).send(response.statusText);
  //     return;
  //   }
  //   const data = await response.arrayBuffer();
  //   response.headers.forEach((value, key) => {
  //     res.setHeader(key, value);
  //   });
  //   res.status(200).send(Buffer.from(data));
  // } catch (error) {
  //   res.status(500).send((error as Error).message);
  // }
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [822,816], () => (__webpack_exec__(5078)));
module.exports = __webpack_exports__;

})();
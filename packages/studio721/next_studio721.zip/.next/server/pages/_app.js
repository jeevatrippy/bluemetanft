"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7928:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9022);
/* harmony import */ var designsystem_src_contexts_DesignSystemConfiguration__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2555);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5781);
/* harmony import */ var keymap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6682);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9228);
/* harmony import */ var _assets_studio721_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6089);
/* harmony import */ var _components_docs_Docs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2118);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([keymap__WEBPACK_IMPORTED_MODULE_5__]);
keymap__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

















const docsUrlPrefix = '/guide';
const LogoImage = styled_components__WEBPACK_IMPORTED_MODULE_8___default().img.withConfig({
  displayName: "_app__LogoImage",
  componentId: "sc-t8j05j-0"
})({
  width: 'auto',
  height: '20px'
});
function App({
  Component,
  pageProps
}) {
  const urlHashParameters = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useUrlHashParameters */ .Qw)();
  const environmentParameters = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => ({
    showDebugInfo: (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .castHashParameter */ .d0)(urlHashParameters.showDebugInfo, 'boolean'),
    mockData: (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .castHashParameter */ .d0)(urlHashParameters.mockData, 'boolean')
  }), [urlHashParameters.mockData, urlHashParameters.showDebugInfo]);
  const {
    asPath: url
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
  const showHeader = !url.startsWith('/mint');
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(contexts__WEBPACK_IMPORTED_MODULE_2__/* .EnvironmentParametersProvider */ .eS, {
    value: environmentParameters,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(contexts__WEBPACK_IMPORTED_MODULE_2__/* .Web3ContextProvider */ .vP, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(designsystem_src_contexts_DesignSystemConfiguration__WEBPACK_IMPORTED_MODULE_3__/* .DesignSystemConfigurationProvider */ .P, {
        theme: theme__WEBPACK_IMPORTED_MODULE_9__/* .theme */ .r,
        platform: (0,keymap__WEBPACK_IMPORTED_MODULE_5__/* .getCurrentPlatform */ .zT)(typeof navigator !== 'undefined' ? navigator : undefined),
        children: [showHeader && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
            as: "header",
            height: "60px",
            justifyContent: "center",
            breakpoints: {
              [600]: {
                justifyContent: 'start'
              }
            },
            position: "fixed",
            zIndex: 20000,
            background: "#222",
            left: 0,
            right: 0,
            borderBottom: '1px solid rgba(0,0,0,0.4)',
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
              flex: "1 1 auto",
              overflowX: "auto",
              overflowY: "hidden",
              paddingHorizontal: 40,
              breakpoints: {
                [600]: {
                  paddingHorizontal: 20
                }
              },
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
                gap: 60,
                breakpoints: {
                  [600]: {
                    gap: 30
                  }
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "/",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(LogoImage, {
                    src: _assets_studio721_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "/guide",
                  children: "Guide"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "/artkit",
                  children: "Artkit"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "/contract",
                  children: "Contract"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "/mint",
                  children: "Mint"
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
                size: 60
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
                gap: 50,
                breakpoints: {
                  [600]: {
                    gap: 30
                  }
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "https://github.com/noya-app/studio721",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.GitHubLogoIcon, {
                    width: 22,
                    height: 22
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "https://twitter.com/dvnabbott",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .TwitterLogoIcon */ .S3, {
                    width: 22,
                    height: 22
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .NavLink */ .OL, {
                  href: "https://discord.gg/HWFNayQaDc",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .DiscordLogoIcon */ .ds, {
                    width: 25,
                    height: 25
                  })
                })]
              })]
            })
          })
        }), url.startsWith(docsUrlPrefix) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .VStack */ .gC, {
          id: "guidebook-container",
          flex: "1",
          margin: '60px 0 0 0',
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_docs_Docs__WEBPACK_IMPORTED_MODULE_10__/* .Docs */ .WI, {
            urlPrefix: docsUrlPrefix,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(Component, _objectSpread({}, pageProps))
          })
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(Component, _objectSpread({}, pageProps))]
      })
    })
  });
}
});

/***/ }),

/***/ 7425:
/***/ ((module) => {

module.exports = require("@mdx-js/react");

/***/ }),

/***/ 3427:
/***/ ((module) => {

module.exports = require("@metamask/detect-provider");

/***/ }),

/***/ 4008:
/***/ ((module) => {

module.exports = require("@openpalette/contract");

/***/ }),

/***/ 7093:
/***/ ((module) => {

module.exports = require("@radix-ui/react-checkbox");

/***/ }),

/***/ 3363:
/***/ ((module) => {

module.exports = require("@radix-ui/react-dialog");

/***/ }),

/***/ 599:
/***/ ((module) => {

module.exports = require("@radix-ui/react-hover-card");

/***/ }),

/***/ 2132:
/***/ ((module) => {

module.exports = require("@radix-ui/react-icons");

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 8395:
/***/ ((module) => {

module.exports = require("flexsearch");

/***/ }),

/***/ 3922:
/***/ ((module) => {

module.exports = require("imfs");

/***/ }),

/***/ 7133:
/***/ ((module) => {

module.exports = require("immer");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("javascript-playgrounds");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 4607:
/***/ ((module) => {

module.exports = require("prism-react-renderer/prism");

/***/ }),

/***/ 4196:
/***/ ((module) => {

module.exports = require("prism-react-renderer/themes/vsDark");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5787:
/***/ ((module) => {

module.exports = require("react-guidebook");

/***/ }),

/***/ 551:
/***/ ((module) => {

module.exports = require("react-window");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 7597:
/***/ ((module) => {

module.exports = import("w3c-keyname");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [945,97,615,621,254,710], () => (__webpack_exec__(7928)));
module.exports = __webpack_exports__;

})();
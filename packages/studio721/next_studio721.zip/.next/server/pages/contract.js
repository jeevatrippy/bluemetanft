"use strict";
(() => {
var exports = {};
exports.id = 610;
exports.ids = [610];
exports.modules = {

/***/ 9186:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ AllowlistSection)
/* harmony export */ });
/* unused harmony export DestinationRow */
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__]);
designsystem__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const DestinationRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function DestinationRow({
  id,
  address,
  amount,
  disabled,
  addressDisabled,
  onClickCross,
  onChangeAddress,
  onChangeAmount
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
    alignItems: "center",
    flex: "1 1 0px",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "DragHandleDots2Icon",
      color: disabled || addressDisabled ? 'transparent' : undefined
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `${id}-amount`,
      flex: "1 1 0px",
      labelSize: 12,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.NumberInput */ .UP.Y2, {
        autoComplete: "no",
        disabled: disabled,
        value: amount,
        onSubmit: onChangeAmount,
        onChangeInternalValue: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(value => {
          const numberValue = Number(value);
          if (!Number.isInteger(numberValue) || numberValue < 0 || numberValue > 100) return;
          onChangeAmount(numberValue);
        }, [onChangeAmount]),
        onNudge: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(delta => {
          onChangeAmount(Math.max(0, Math.min(100, amount + delta)));
        }, [amount, onChangeAmount])
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 10
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `${id}-address`,
      flex: "3 3 0px",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        disabled: disabled || addressDisabled,
        value: address,
        onChange: onChangeAddress
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "Cross2Icon",
      color: addressDisabled || disabled ? 'transparent' : undefined,
      onClick: onClickCross
    })]
  });
});
const AllowlistSection = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function AllowlistSection({
  allowedForOwner,
  destinations,
  disabled,
  dispatch
}) {
  const handleMoveItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((sourceIndex, destinationIndex) => {
    dispatch({
      type: 'moveAllowlistDestination',
      sourceIndex,
      destinationIndex
    });
  }, [dispatch]);
  const handleRenderItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(({
    item,
    index
  }) => {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(DestinationRow, {
      id: `allowlist-destination-${index}`,
      address: item.address,
      amount: item.amount,
      disabled: disabled,
      onChangeAmount: amount => {
        if (amount === item.amount) return;
        dispatch({
          type: 'setAllowlistDestinationAmount',
          index,
          amount
        });
      },
      onChangeAddress: address => {
        if (address === item.address) return;
        dispatch({
          type: 'setAllowlistDestinationAddress',
          index,
          address
        });
      },
      onClickCross: () => {
        dispatch({
          type: 'removeAllowlistDestination',
          index
        });
      }
    }, index);
  }, [disabled, dispatch]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormSection */ .hj, {
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: ["Allowlist", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .InfoHoverCard */ .No, {
        top: "1px",
        children: "Addresses allowed to mint, and how many they can mint, before the sale starts."
      })]
    }),
    right: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
      disabled: disabled,
      onClick: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
        dispatch({
          type: 'addAllowlistDestination'
        });
      }, [dispatch]),
      children: ["Add Address", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
        inline: true,
        size: 4
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.PlusIcon, {})]
    }),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
      gap: 3,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "1 1 0px",
        minWidth: 0,
        padding: '0 0 0 21px',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Amount"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "3 3 0px",
        minWidth: 0,
        padding: '0 0 0 0',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Allowed Address"
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(DestinationRow, {
      id: `allowlist-destination-owner`,
      address: 'Contract Owner',
      amount: allowedForOwner,
      disabled: disabled,
      addressDisabled: true,
      onChangeAmount: amount => {
        if (amount === allowedForOwner) return;
        dispatch({
          type: 'setAmountAllowedForOwner',
          amount
        });
      },
      onChangeAddress: address => {},
      onClickCross: () => {}
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .ArrayController */ .vU, {
      id: 'allowlist-destination-controller',
      sortable: true,
      items: destinations,
      onMoveItem: handleMoveItem,
      renderItem: handleRenderItem
    })]
  });
});
});

/***/ }),

/***/ 5120:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ Console)
/* harmony export */ });
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9615);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6221);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






function Console({
  elements
}) {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    var _ref$current;

    (_ref$current = ref.current) === null || _ref$current === void 0 ? void 0 : _ref$current.scrollTo({
      top: 99999
    });
  }, [elements]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .VStack */ .gC, {
    ref: ref,
    overflowY: "auto",
    flex: "1 1 0px",
    padding: 20,
    background: "rgba(255,255,255,0.06)",
    children: (0,utils__WEBPACK_IMPORTED_MODULE_2__.withSeparatorElements)(elements, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .SpacerVertical */ .Nw, {
        size: 20
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Divider */ .iz, {
        variant: "light"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .SpacerVertical */ .Nw, {
        size: 20
      })]
    }))
  });
}

/***/ }),

/***/ 9401:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ ContractConsole)
/* harmony export */ });
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9022);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8531);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6221);
/* harmony import */ var solidity_compiler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3988);
/* harmony import */ var _utils_download__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1201);
/* harmony import */ var _Console__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5120);
/* harmony import */ var files__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2417);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9772);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_download__WEBPACK_IMPORTED_MODULE_6__, files__WEBPACK_IMPORTED_MODULE_8__, state__WEBPACK_IMPORTED_MODULE_3__]);
([_utils_download__WEBPACK_IMPORTED_MODULE_6__, files__WEBPACK_IMPORTED_MODULE_8__, state__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const ContractConsole = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function ContractConsole({
  compiler,
  deployment,
  verification
}) {
  const chainId = (0,contexts__WEBPACK_IMPORTED_MODULE_1__/* .useChainId */ .xx)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_Console__WEBPACK_IMPORTED_MODULE_7__/* .Console */ .M, {
    elements: [compiler.type === 'downloading' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      loading: true,
      children: "Downloading @openzeppelin contracts..."
    }), compiler.type === 'ready' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      loading: true,
      children: "Compiling..."
    }), compiler.type === 'error' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      children: ["Compiler errors:", '\n\n', compiler.errors.map(e => e.formattedMessage).join('\n\n')]
    }), compiler.type === 'done' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      children: [Object.keys(compiler.contracts).map(name => name.replace('@openzeppelin/contracts', `@openzeppelin/contracts@${state__WEBPACK_IMPORTED_MODULE_3__/* .OPEN_ZEPPELIN_VERSION */ .be}`).replace('gwei-slim-nft-contracts', `gwei-slim-nft-contracts@${state__WEBPACK_IMPORTED_MODULE_3__/* .GWEI_SLIM_VERSION */ .uF}`)).sort().join('\n'), '\n\n', "Optional downloads:", '\n', "-", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
        style: {
          fontSize: 'inherit'
        },
        onClick: async () => {
          const files = Object.fromEntries(Object.entries(compiler.files).map(([name, string]) => [name, utils__WEBPACK_IMPORTED_MODULE_4__.UTF16.toUTF8(string)]));
          const zip = await files__WEBPACK_IMPORTED_MODULE_8__/* .Zip.zip */ .sZ.zip(files);
          await (0,_utils_download__WEBPACK_IMPORTED_MODULE_6__/* .saveFile */ .y)(`contract.zip`, 'application/zip', '.zip', zip);
        },
        children: "solidity files"
      }), ' ', '\n', "-", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
        style: {
          fontSize: 'inherit'
        },
        onClick: async () => {
          const input = JSON.stringify((0,solidity_compiler__WEBPACK_IMPORTED_MODULE_5__/* .createCompilerInput */ .p)(compiler.files));
          await (0,_utils_download__WEBPACK_IMPORTED_MODULE_6__/* .saveFile */ .y)(`input.json`, 'application/json', '.json', utils__WEBPACK_IMPORTED_MODULE_4__.UTF16.toUTF8(input));
        },
        children: "compiler input"
      }), '\n', "-", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
        style: {
          fontSize: 'inherit'
        },
        onClick: async () => {
          const output = JSON.stringify(compiler.contracts[compiler.sourceName][compiler.contractName], null, 2);
          await (0,_utils_download__WEBPACK_IMPORTED_MODULE_6__/* .saveFile */ .y)(`output.json`, 'application/json', '.json', utils__WEBPACK_IMPORTED_MODULE_4__.UTF16.toUTF8(output));
        },
        children: "compiler output"
      }), '\n', "-", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
        style: {
          fontSize: 'inherit'
        },
        onClick: async () => {
          const output = JSON.stringify(compiler.contracts[compiler.sourceName][compiler.contractName].abi, null, 2);
          await (0,_utils_download__WEBPACK_IMPORTED_MODULE_6__/* .saveFile */ .y)(`abi.json`, 'application/json', '.json', utils__WEBPACK_IMPORTED_MODULE_4__.UTF16.toUTF8(output));
        },
        children: "ABI"
      }), '\n\n', "\uD83D\uDEE0 Compiled successfully"]
    }), deployment.type === 'deploying' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      loading: true,
      children: "Deploying..."
    }), chainId && deployment.type === 'deployed' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Regular */ .FE, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("a", {
          href: (0,web3_utils__WEBPACK_IMPORTED_MODULE_9__/* .getEtherscanAddressUrl */ .YU)(chainId, deployment.address),
          target: "_blank",
          rel: "noreferrer",
          children: [(0,web3_utils__WEBPACK_IMPORTED_MODULE_9__/* .getBlockExplorerName */ .bf)(chainId), " \u2192"]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
        children: ["\uD83D\uDE80 Deployed at: ", deployment.address]
      })]
    }), verification.type === 'notStarted' && verification.previousError && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      children: [verification.previousError.message, '\n\n', "Wait a few seconds and try again"]
    }), verification.type === 'verifying' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      loading: true,
      children: "Verifying..."
    }), verification.type === 'verified' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .Code */ .EK, {
      children: "\u2705 Verified"
    })]
  });
});
});

/***/ }),

/***/ 8902:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ MintingSection)
/* harmony export */ });
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8531);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6221);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9772);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__, state__WEBPACK_IMPORTED_MODULE_4__]);
([designsystem__WEBPACK_IMPORTED_MODULE_2__, state__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}













function isConfigEqual(config, partial) {
  const projection = Object.fromEntries(Object.entries(partial).map(([key]) => [key, config[key]]));
  return (0,utils__WEBPACK_IMPORTED_MODULE_5__.isDeepEqual)(projection, partial);
}

const AccessTokenInputField = ({
  disabled,
  requireAccessToken,
  dispatch,
  chainName
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
    indent: 1,
    title: `${(0,utils__WEBPACK_IMPORTED_MODULE_5__.upperFirst)(chainName)} address`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `input-access-token-${chainName}-address`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        style: {
          fontFamily: 'monospace'
        },
        disabled: disabled,
        value: requireAccessToken[chainName],
        onChange: value => {
          dispatch({
            type: 'setAccessToken',
            value: _objectSpread(_objectSpread({}, requireAccessToken !== null && requireAccessToken !== void 0 ? requireAccessToken : {
              mainnet: '',
              rinkeby: '',
              ropsten: '',
              goerli: '',
              polygon: '',
              mumbai: ''
            }), {}, {
              [chainName]: value
            })
          });
        }
      })
    })
  });
};

const ApprovalProxyInputField = ({
  disabled,
  approvalProxyAddress,
  dispatch,
  chainName
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
    indent: 1,
    title: `${(0,utils__WEBPACK_IMPORTED_MODULE_5__.upperFirst)(chainName)} address`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `input-approval-proxy-${chainName}-address`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        style: {
          fontFamily: 'monospace'
        },
        disabled: disabled,
        value: approvalProxyAddress[chainName],
        onChange: value => {
          dispatch({
            type: 'setApprovalProxyAddress',
            value: _objectSpread(_objectSpread({}, approvalProxyAddress !== null && approvalProxyAddress !== void 0 ? approvalProxyAddress : {
              mainnet: '',
              rinkeby: '',
              ropsten: '',
              goerli: '',
              polygon: '',
              mumbai: ''
            }), {}, {
              [chainName]: value
            })
          });
        }
      })
    })
  });
};

const chainNames = ['mainnet', 'rinkeby', 'ropsten', 'polygon', 'mumbai'];
const MintingSection = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function MintingSection({
  config,
  disabled,
  dispatch
}) {
  var _config$multimint, _config$limitPerWalle, _ref, _config$customMaxToke;

  const presetValue = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    if (isConfigEqual(config, (0,state__WEBPACK_IMPORTED_MODULE_4__/* .createDefaultConfig */ .P_)())) {
      return 'default';
    } else if (isConfigEqual(config, (0,state__WEBPACK_IMPORTED_MODULE_4__/* .createOpenPaletteConfig */ .J9)())) {
      return 'openPalette';
    } else {
      return 'none';
    }
  }, [config]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormSection */ .hj, {
    title: "Minting Options",
    right: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        width: 180,
        alignItems: "center",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Preset"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
          size: 10
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Select */ .Ph, {
          id: "input-preset",
          disabled: disabled,
          value: presetValue,
          options: [...(presetValue === 'none' ? ['none'] : []), 'default', 'openPalette'],
          getTitle: id => (0,utils__WEBPACK_IMPORTED_MODULE_5__.upperFirst)(id),
          onChange: id => {
            switch (id) {
              case 'default':
                dispatch({
                  type: 'setConfig',
                  config: (0,state__WEBPACK_IMPORTED_MODULE_4__/* .createDefaultConfig */ .P_)()
                });
                break;

              case 'openPalette':
                dispatch({
                  type: 'setConfig',
                  config: (0,state__WEBPACK_IMPORTED_MODULE_4__/* .createOpenPaletteConfig */ .J9)()
                });
                break;
            }
          }
        })]
      })
    }),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Reduce deployment costs",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["This option reduces the costs of deploying a contract using a technique called ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("em", {
          children: "delegation"
        }), ". Typically costs are reduced by around 65%.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("br", {}), "Most NFT contracts contain a lot of the same code; we can therefore reuse (or delegate to) the code that's already been deployed to the blockchain, rather than deploying a separate copy each time. Deploying less code means lower costs.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("br", {}), "The deployed code that we're reusing was created by", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .TwitterChip */ .S4, {
          hasMargin: false,
          value: "@isiain"
        }), " and is available on GitHub", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .LinkChip */ .lE, {
          openInNewTab: true,
          href: "https://github.com/iainnash/gwei-slim-erc721",
          children: "GitHub"
        }), "."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.usesDelegatedContract,
        onCheckedChange: value => {
          dispatch({
            type: 'setUsesDelegatedContract',
            value
          });
        }
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Multimint",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["You may optionally allow minting multiple NFTs at once.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This is a great way to save people time and transaction fees (gas), though it may lead to your NFTs being owned by a smaller number of people."]
      }),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.multimint !== undefined,
        onCheckedChange: value => {
          dispatch({
            type: 'setMultiMint',
            value: value ? 20 : undefined
          });
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
        id: "input-multi-mint",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.NumberInput */ .UP.Y2, {
          disabled: disabled || config.multimint === undefined,
          value: (_config$multimint = config.multimint) !== null && _config$multimint !== void 0 ? _config$multimint : 20,
          onSubmit: value => {
            const numberValue = Number(value);
            if (!Number.isInteger(numberValue) || numberValue <= 0) return;
            dispatch({
              type: 'setMultiMint',
              value: numberValue
            });
          }
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Minting limit per wallet",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["This limits the amount of NFTs any wallet/address can mint.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This can help prevent one wallet (potentially a bot) from minting a large amount of the supply. However, it's only a preventative measure that adds some friction; somebody can still split their Ether into several wallets and mint from each.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "If you add addresses via the allowlist, any addresses listed will be able to mint ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("em", {
          children: "the greater"
        }), " of their allowed amount and this limit after the sale starts."]
      }),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.limitPerWallet !== undefined,
        onCheckedChange: value => {
          dispatch({
            type: 'setMintingLimitPerWallet',
            value: value ? 5 : undefined
          });
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
        id: "input-limit-per-wallet",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.NumberInput */ .UP.Y2, {
          disabled: disabled || config.limitPerWallet === undefined,
          value: (_config$limitPerWalle = config.limitPerWallet) !== null && _config$limitPerWalle !== void 0 ? _config$limitPerWalle : 5,
          onSubmit: value => {
            const numberValue = Number(value);
            if (!Number.isInteger(numberValue) || numberValue <= 0) return;
            dispatch({
              type: 'setMintingLimitPerWallet',
              value: numberValue
            });
          }
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Mint specific ids",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["Should the minter be required to specify the id of the NFTs they want to mint?", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "If this isn", "'", "t checked, NFT ids will auto-increment."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.usesIdParameter,
        onCheckedChange: value => {
          dispatch({
            type: 'setUsesIdParameter',
            value
          });
        }
      })
    }), config.usesIdParameter && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      indent: 1,
      title: "Maximum token id",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["The maximum token id is this number minus one.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This should be greater than or equal to the supply."]
      }),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.customMaxTokenId !== undefined,
        onCheckedChange: value => {
          var _config$supply;

          dispatch({
            type: 'setCustomMaxTokenId',
            value: value ? (_config$supply = config.supply) !== null && _config$supply !== void 0 ? _config$supply : 2000 : undefined
          });
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
        id: "input-max-token-id",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.NumberInput */ .UP.Y2, {
          disabled: disabled || config.customMaxTokenId === undefined,
          value: (_ref = (_config$customMaxToke = config.customMaxTokenId) !== null && _config$customMaxToke !== void 0 ? _config$customMaxToke : config.supply) !== null && _ref !== void 0 ? _ref : 2000,
          onChange: value => {
            const numberValue = Number(value);
            if (!Number.isInteger(numberValue) || numberValue <= 0) return;
            dispatch({
              type: 'setCustomMaxTokenId',
              value: numberValue
            });
          }
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Require access token",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["Another ERC721 (NFT) contract can be used to gate access to minting.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "The ID from the ", '"', "access token", '"', " will be used for the minted token."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: !!config.requireAccessToken,
        onCheckedChange: value => {
          dispatch({
            type: 'setAccessToken',
            value: value ? {
              mainnet: (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.getContractAddress)(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.MAINNET),
              rinkeby: (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.getContractAddress)(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.RINKEBY),
              ropsten: '',
              goerli: '',
              polygon: '',
              mumbai: ''
            } : undefined
          });
        }
      })
    }), config.requireAccessToken && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
        indent: 1,
        title: "Add function to disable",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
          children: ["Exposes a function ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
            children: "setAccessTokenIsActive"
          }), " to enable/disable the access token.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "This can be useful if the access token is used for a \"presale\", but after that, minting is open to all."]
        }),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.toggleAccessToken,
          onCheckedChange: value => {
            dispatch({
              type: 'setToggleAccessToken',
              value
            });
          }
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
        indent: 1,
        title: "Add function to change",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
          children: ["Exposes a function ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
            children: "setAccessTokenAddress"
          }), " to change the access token address.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "This can be useful if the original access token contract has a bug and you need to switch to a new access token."]
        }),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.mutableAccessToken,
          onCheckedChange: value => {
            dispatch({
              type: 'setMutableAccessToken',
              value
            });
          }
        })
      }), chainNames.map(chainName => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(AccessTokenInputField, {
        disabled: disabled,
        chainName: chainName,
        dispatch: dispatch,
        requireAccessToken: config.requireAccessToken
      }))]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Only the owner can mint",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["Only the contract owner is allowed to call the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
          children: "mint"
        }), ' ', "function.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This is useful if you want to mint the NFTs yourself, and then list them for sale or transfer afterward.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "Initially, you are the contract owner. However, you can call", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
          children: "transferOwnership"
        }), " to choose a different owner."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.onlyOwnerCanMint,
        onCheckedChange: value => {
          dispatch({
            type: 'setOnlyOwnerCanMint',
            value
          });
        }
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Enumerable",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["Use the ERC721Enumerable extension.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This extension provides an API for looking up the list of NFTs owned by an address. This is primarily useful if you want to build related projects that use the NFTs.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "The downside is that it increases transaction fees (gas) when minting and transfering the NFTs. From some quick testing, this seems to increase fees by around 50%.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This option isn't currently supported when using the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("em", {
          children: "reduced deployment costs"
        }), " option.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .Blockquote */ .V6, {
          style: {
            fontSize: 'inherit'
          },
          children: ["Due to rising gas costs, many developers choose not to use this extension anymore. You can typically provide the same \"list of NFTs\" functionality on your website using an indexing service such as", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .LinkChip */ .lE, {
            openInNewTab: true,
            style: {
              whiteSpace: 'pre'
            },
            href: "https://thegraph.com",
            children: "The Graph"
          }), ", though it's more work and relies on off-chain data."]
        })]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled || config.usesDelegatedContract,
        checked: config.enumerable,
        onCheckedChange: value => {
          dispatch({
            type: 'setEnumerable',
            value
          });
        }
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Minting starts active",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["This NFT contract has a function ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
          children: "setSaleIsActive"
        }), ", which you can call to activate and deactivate the sale. If you check this box, the sale will be activated as soon as you deploy the contract."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.activateAutomatically,
        onCheckedChange: value => {
          dispatch({
            type: 'setActivateAutomatically',
            value
          });
        }
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Approval Proxy",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["This is a technique used by OpenSea to enable users to list their NFTs without paying transaction fees (\"gasless listing\"). Read more in the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .LinkChip */ .lE, {
          openInNewTab: true,
          href: "https://docs.opensea.io/docs/1-structuring-your-smart-contract",
          children: "OpenSea documentation"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "The default addresses come from their", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .LinkChip */ .lE, {
          openInNewTab: true,
          href: "https://github.com/ProjectOpenSea/opensea-creatures/blob/1c9ee693b3c69467bdc5d025cc667ab1d1c4c873/migrations/2_deploy_contracts.js#L28",
          children: ["Example Code", ' ']
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This option isn't currently supported when using the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("em", {
          children: "reduced deployment costs"
        }), " option."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled || config.usesDelegatedContract,
        checked: !!config.approvalProxyAddress,
        onCheckedChange: value => {
          dispatch({
            type: 'setApprovalProxyAddress',
            value: value ? {
              mainnet: (0,web3_utils__WEBPACK_IMPORTED_MODULE_6__/* .getProxyAddress */ .nq)(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.MAINNET),
              rinkeby: (0,web3_utils__WEBPACK_IMPORTED_MODULE_6__/* .getProxyAddress */ .nq)(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.RINKEBY),
              ropsten: '',
              goerli: '',
              polygon: '',
              mumbai: ''
            } : undefined
          });
        }
      })
    }), config.approvalProxyAddress && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: chainNames.map(chainName => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ApprovalProxyInputField, {
        disabled: disabled,
        chainName: chainName,
        dispatch: dispatch,
        approvalProxyAddress: config.approvalProxyAddress
      }))
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Set token URIs individually",
      tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
        children: ["This lets you set a unique URI for each token, overriding the default ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("em", {
          children: "Token URI"
        }), " used for the entire collection.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This is useful when you don't create the artwork for your entire collection in advance, but rather mint a few tokens at a time.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "Call the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("code", {
          children: "setTokenURI"
        }), " function to set a URI for a specific token."]
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Checkbox */ .XZ, {
        variant: "dark",
        disabled: disabled,
        checked: config.usesUriStorage,
        onCheckedChange: value => {
          dispatch({
            type: 'setUsesUriStorage',
            value
          });
        }
      })
    })]
  });
});
});

/***/ }),

/***/ 7564:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ ParametersSection)
/* harmony export */ });
/* unused harmony export ParameterRow */
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__]);
designsystem__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const ParameterRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function ParameterRow({
  id,
  name,
  type,
  disabled,
  onClickCross,
  onChangeName,
  onChangeType
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
    alignItems: "center",
    flex: "1 1 0px",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "DragHandleDots2Icon"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `${id}-name`,
      flex: "1 1 0px",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        disabled: disabled,
        value: name,
        onChange: onChangeName
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 10
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Select */ .Ph, {
      id: `${id}-type`,
      disabled: disabled,
      value: type,
      options: ['uint256', 'string', 'address'],
      onChange: onChangeType
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "Cross2Icon",
      onClick: onClickCross
    })]
  });
});
const ParametersSection = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function ParametersSection({
  parameters,
  disabled,
  dispatch
}) {
  const handleMoveItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((sourceIndex, destinationIndex) => {
    dispatch({
      type: 'moveTokenParameter',
      sourceIndex,
      destinationIndex
    });
  }, [dispatch]);
  const handleRenderItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(({
    item,
    index
  }) => {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ParameterRow, {
      id: `token-parameter-${index}`,
      type: item.type,
      name: item.name,
      disabled: disabled,
      onChangeName: name => {
        dispatch({
          type: 'setTokenParameterName',
          index,
          name
        });
      },
      onChangeType: tokenType => {
        dispatch({
          type: 'setTokenParameterType',
          index,
          tokenType
        });
      },
      onClickCross: () => {
        dispatch({
          type: 'removeTokenParameter',
          index
        });
      }
    }, index);
  }, [disabled, dispatch]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormSection */ .hj, {
    showContent: parameters.length > 0,
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: ["Token Parameters", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .InfoHoverCard */ .No, {
        top: "1px",
        children: ["Tokens may be minted with arbitrary parameters. These parameters are then accessible as query parameters of the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("code", {
          children: "tokenURI"
        }), ".", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "Note that for string parameters, it's your responsibility to url-encode them when minting; the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("code", {
          children: "tokenURI"
        }), " function does not url-encode parameters."]
      })]
    }),
    right: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
      disabled: disabled,
      onClick: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
        dispatch({
          type: 'addTokenParameter'
        });
      }, [dispatch]),
      children: ["Add Parameter", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
        inline: true,
        size: 4
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.PlusIcon, {})]
    }),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "1 1 0px",
        minWidth: 0,
        padding: '0 0 0 21px',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Name"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "1 1 0px",
        minWidth: 0,
        padding: '0 21px 0 0',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Type"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
        size: 21
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .ArrayController */ .vU, {
      id: 'token-parameter-controller',
      sortable: true,
      items: parameters,
      onMoveItem: handleMoveItem,
      renderItem: handleRenderItem
    })]
  });
});
});

/***/ }),

/***/ 4570:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ PayoutSection)
/* harmony export */ });
/* unused harmony export DestinationRow */
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__]);
designsystem__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const DestinationRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function DestinationRow({
  id,
  address,
  amount,
  disabled,
  onClickCross,
  onChangeAddress,
  onChangeAmount
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
    alignItems: "center",
    flex: "1 1 0px",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "DragHandleDots2Icon",
      color: disabled ? 'transparent' : undefined
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `${id}-amount`,
      flex: "1 1 0px",
      labelSize: 12,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.NumberInput */ .UP.Y2, {
        disabled: disabled,
        value: amount,
        onSubmit: onChangeAmount,
        onChangeInternalValue: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(value => {
          const numberValue = Number(value);
          if (!Number.isInteger(numberValue) || numberValue < 0 || numberValue > 100) return;
          onChangeAmount(numberValue);
        }, [onChangeAmount]),
        onNudge: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(delta => {
          const newValue = amount + delta;
          if (newValue < 0 || newValue > 100) return;
          onChangeAmount(amount + delta);
        }, [amount, onChangeAmount])
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Label */ .UP.__, {
        children: "%"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 10
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: `${id}-address`,
      flex: "3 3 0px",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        disabled: disabled,
        value: address,
        onChange: onChangeAddress
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
      size: 6
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .hU, {
      iconName: "Cross2Icon",
      color: disabled ? 'transparent' : undefined,
      onClick: onClickCross
    })]
  });
});
const PayoutSection = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(function PayoutSection({
  destinations,
  disabled,
  dispatch
}) {
  const handleMoveItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((sourceIndex, destinationIndex) => {
    dispatch({
      type: 'movePayoutDestination',
      sourceIndex,
      destinationIndex
    });
  }, [dispatch]);
  const handleRenderItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(({
    item,
    index
  }) => {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(DestinationRow, {
      id: `payout-destination-${index}`,
      address: item.address,
      amount: item.amount,
      disabled: disabled,
      onChangeAmount: amount => {
        if (amount === item.amount) return;
        dispatch({
          type: 'setPayoutDestinationAmount',
          index,
          amount
        });
      },
      onChangeAddress: address => {
        if (address === item.address) return;
        dispatch({
          type: 'setPayoutDestinationAddress',
          index,
          address
        });
      },
      onClickCross: () => {
        dispatch({
          type: 'removePayoutDestination',
          index
        });
      }
    }, index);
  }, [disabled, dispatch]);
  const total = destinations.map(item => item.amount).reduce((result, item) => result + item, 0);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .FormSection */ .hj, {
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: ["Payout", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .InfoHoverCard */ .No, {
        top: "1px",
        children: "Ether payed to the contract may be split and withdrawn to multiple addresses. This is only applicable if you set a price for your NFT."
      })]
    }),
    right: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
      disabled: disabled,
      onClick: (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
        dispatch({
          type: 'addPayoutDestination'
        });
      }, [dispatch]),
      children: ["Add Recipient", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerHorizontal */ .lC, {
        inline: true,
        size: 4
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.PlusIcon, {})]
    }),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
      gap: 3,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "1 1 0px",
        minWidth: 0,
        padding: '0 0 0 21px',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Share"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
        flex: "3 3 0px",
        minWidth: 0,
        padding: '0 0 0 0',
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .Small */ .x4, {
          children: "Recipient Address"
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(DestinationRow, {
      id: `payout-destination-owner`,
      address: 'Contract Owner',
      amount: total > 100 ? 0 : 100 - total,
      disabled: true,
      onChangeAmount: amount => {},
      onChangeAddress: address => {},
      onClickCross: () => {}
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .ArrayController */ .vU, {
      id: 'payout-destination-controller',
      sortable: true,
      items: destinations,
      onMoveItem: handleMoveItem,
      renderItem: handleRenderItem
    })]
  });
});
});

/***/ }),

/***/ 7345:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ VerificationSection)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__]);
designsystem__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const VerificationSection = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function VerificationSection({
  etherscanApiKey,
  dispatch
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormSection */ .hj, {
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
      children: ["Contract Verification", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .InfoHoverCard */ .No, {
        top: "1px",
        children: ["Verifying your contract lets other people read the source code and interact with the contract API on Etherscan.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "This is highly recommended so that people can choose whether or not they trust and want to use a contract.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .SpacerVertical */ .Nw, {
          size: 20
        }), "You", "'", "ll need to create an account on Etherscan, but the default plan is free and sufficient for most usage.", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .LinkChip */ .lE, {
          href: "https://etherscan.io/apis",
          openInNewTab: true,
          children: "Etherscan API portal"
        })]
      })]
    }),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components__WEBPACK_IMPORTED_MODULE_1__/* .FormRow */ .p7, {
      title: "Etherscan API Key",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
        id: "input-etherscan-api-key",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
          type: "password",
          value: etherscanApiKey,
          onChange: value => {
            dispatch({
              type: 'setEtherscanApiKey',
              value
            });
          }
        })
      })
    })
  });
});
});

/***/ }),

/***/ 1678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ NFTStudio),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9022);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5781);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prism_react_renderer_themes_vsDark__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4196);
/* harmony import */ var prism_react_renderer_themes_vsDark__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prism_react_renderer_themes_vsDark__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var solidity_codegen__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(656);
/* harmony import */ var solidity_compiler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3988);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8531);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9772);
/* harmony import */ var _components_contract_AllowlistSection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9186);
/* harmony import */ var _components_contract_ContractConsole__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9401);
/* harmony import */ var _components_contract_MintingSection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8902);
/* harmony import */ var _components_contract_ParametersSection__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7564);
/* harmony import */ var _components_contract_PayoutSection__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4570);
/* harmony import */ var _components_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7770);
/* harmony import */ var _components_contract_VerificationSection__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7345);
/* harmony import */ var _utils_deploy__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6508);
/* harmony import */ var _utils_socialConfig__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2060);
/* harmony import */ var _utils_verify__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1563);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_contract_ContractConsole__WEBPACK_IMPORTED_MODULE_14__, _components_contract_VerificationSection__WEBPACK_IMPORTED_MODULE_19__, _components_contract_AllowlistSection__WEBPACK_IMPORTED_MODULE_13__, _components_contract_PayoutSection__WEBPACK_IMPORTED_MODULE_17__, _components_contract_ParametersSection__WEBPACK_IMPORTED_MODULE_16__, _components_contract_MintingSection__WEBPACK_IMPORTED_MODULE_15__, _components_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_18__, state__WEBPACK_IMPORTED_MODULE_11__]);
([_components_contract_ContractConsole__WEBPACK_IMPORTED_MODULE_14__, _components_contract_VerificationSection__WEBPACK_IMPORTED_MODULE_19__, _components_contract_AllowlistSection__WEBPACK_IMPORTED_MODULE_13__, _components_contract_PayoutSection__WEBPACK_IMPORTED_MODULE_17__, _components_contract_ParametersSection__WEBPACK_IMPORTED_MODULE_16__, _components_contract_MintingSection__WEBPACK_IMPORTED_MODULE_15__, _components_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_18__, state__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}



























const SCHEMA_VERSION_KEY = 'schemaVersion';

try {
  (prism_react_renderer_themes_vsDark__WEBPACK_IMPORTED_MODULE_7___default().plain.backgroundColor) = 'black';
} catch {//
}

const erc721DelegatedAddress = {
  mainnet: '0x43955024b1985e2b933a59021500ae5f55b04091',
  rinkeby: '0x86c67a16c16bf784bdfe7d4b7575db664d191f88',
  ropsten: '',
  goerli: '',
  polygon: '',
  mumbai: ''
};

function useCompiler() {
  const requestId = (0,react__WEBPACK_IMPORTED_MODULE_8__.useRef)(0);
  const worker = (0,react__WEBPACK_IMPORTED_MODULE_8__.useRef)();
  (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(() => {
    worker.current = new Worker(new URL(/* worker import */ __webpack_require__.p + __webpack_require__.u(96), __webpack_require__.b));
  }, [worker]);
  return {
    compile: files => {
      return new Promise(resolve => {
        var _worker$current2, _worker$current3;

        const request = {
          id: requestId.current++,
          type: 'compile',
          request: {
            input: (0,solidity_compiler__WEBPACK_IMPORTED_MODULE_10__/* .createCompilerInput */ .p)(files)
          }
        };

        function handler(e) {
          var _worker$current;

          const data = e.data;
          if (!(data.id === request.id && data.type === request.type)) return;
          (_worker$current = worker.current) === null || _worker$current === void 0 ? void 0 : _worker$current.removeEventListener('message', handler);
          resolve(data.response.output);
        }

        (_worker$current2 = worker.current) === null || _worker$current2 === void 0 ? void 0 : _worker$current2.addEventListener('message', handler);
        (_worker$current3 = worker.current) === null || _worker$current3 === void 0 ? void 0 : _worker$current3.postMessage(request);
      });
    }
  };
}

function NFTStudio() {
  var _useWeb3Data;

  (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .usePrismExtensions */ .nv)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
  const initialConfig = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(() => {
    if (typeof router.query.config !== 'string') return {};
    const config = router.query.config ? JSON.parse(decodeURIComponent(router.query.config)) : {};
    delete config[SCHEMA_VERSION_KEY];
    return config;
  }, [router.query.config]);
  const {
    0: state,
    1: dispatch
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useReducer)(state__WEBPACK_IMPORTED_MODULE_11__/* .reducer */ .I6, (0,state__WEBPACK_IMPORTED_MODULE_11__/* .createInitialState */ .PA)(initialConfig));
  const configJSON = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(() => {
    const clone = _objectSpread({}, state.config);

    Object.entries((0,state__WEBPACK_IMPORTED_MODULE_11__/* .createInitialState */ .PA)({}).config).forEach(([key, value]) => {
      if (JSON.stringify(clone[key]) === JSON.stringify(value)) {
        delete clone[key];
      }
    });
    return JSON.stringify(_objectSpread(_objectSpread({}, clone), {}, {
      [SCHEMA_VERSION_KEY]: '1.0.0'
    }));
  }, [state.config]);
  (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(() => {
    const config = `config=${encodeURIComponent(configJSON)}`;
    if (router.asPath.includes(config)) return;
    router.replace({
      query: config
    }, undefined, {
      scroll: false,
      shallow: true
    });
  }, [configJSON, router]);
  const compiler = useCompiler();
  const provider = (_useWeb3Data = (0,contexts__WEBPACK_IMPORTED_MODULE_3__/* .useWeb3Data */ .Rf)()) === null || _useWeb3Data === void 0 ? void 0 : _useWeb3Data.provider;
  const chainId = (0,contexts__WEBPACK_IMPORTED_MODULE_3__/* .useChainId */ .xx)();
  const handleCompile = (0,react__WEBPACK_IMPORTED_MODULE_8__.useCallback)(() => {
    async function main() {
      const contractName = (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .getValidContractName */ .th)(state.config.tokenName);
      const sourceName = contractName + '.sol';
      const source = (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .generateContractSource */ .fX)(state.config);
      dispatch({
        type: 'downloadFiles'
      });
      const files = await (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .downloadDependenciesForSource */ .Dv)(fetch, sourceName, source, {
        '@openzeppelin/contracts': state__WEBPACK_IMPORTED_MODULE_11__/* .OPEN_ZEPPELIN_VERSION */ .be,
        'gwei-slim-nft-contracts': state__WEBPACK_IMPORTED_MODULE_11__/* .GWEI_SLIM_VERSION */ .uF
      });
      dispatch({
        type: 'setCompilerReady',
        value: files
      });
      const output = await compiler.compile(files);
      dispatch({
        type: 'setCompilerDone',
        value: output,
        sourceName,
        contractName
      });
    }

    main();
  }, [compiler, state.config]);
  const handleDeploy = (0,react__WEBPACK_IMPORTED_MODULE_8__.useCallback)(() => {
    async function main() {
      if (state.compiler.type !== 'done' || !provider || !chainId) return;
      const {
        sourceName,
        contractName,
        contracts
      } = state.compiler;
      const mainContract = contracts[sourceName][contractName];
      const {
        abi,
        evm: {
          bytecode
        }
      } = mainContract;
      dispatch({
        type: 'setDeploying'
      });
      let deploymentAddress;
      const chainName = (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.getChainName)(chainId);

      try {
        var _erc721DelegatedAddre;

        if (state.config.usesDelegatedContract && !(chainId === _openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.CHAIN_ID.MAINNET || chainId === _openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.CHAIN_ID.RINKEBY)) {
          alert("You can't use the 'Reduce deployment costs' option on this network! Mainnet and Rinkeby only for now.");
          throw new Error("Can't use delegated contracts on this network");
        }

        deploymentAddress = await (0,_utils_deploy__WEBPACK_IMPORTED_MODULE_20__/* .deployContract */ .P)(provider.getSigner(), abi, bytecode, [...(state.config.usesDelegatedContract ? [(_erc721DelegatedAddre = erc721DelegatedAddress[chainName]) !== null && _erc721DelegatedAddre !== void 0 ? _erc721DelegatedAddre : undefined] : []), (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .getBaseURI */ .Lw)(state.config.tokenURI), ...(state.config.requireAccessToken ? [state.config.requireAccessToken[chainName]] : []), ...(state.config.approvalProxyAddress ? [state.config.approvalProxyAddress[chainName]] : [])]);
      } catch (e) {
        console.warn('deploy failure', e);
        dispatch({
          type: 'deployFailure'
        });
        return;
      }

      dispatch({
        type: 'setDeploymentAddress',
        value: deploymentAddress
      });
    }

    main();
  }, [state.compiler, state.config.usesDelegatedContract, state.config.tokenURI, state.config.requireAccessToken, state.config.approvalProxyAddress, provider, chainId]);
  const handleVerify = (0,react__WEBPACK_IMPORTED_MODULE_8__.useCallback)(() => {
    async function main() {
      var _erc721DelegatedAddre2;

      if (state.compiler.type !== 'done' || state.deployment.type !== 'deployed' || !chainId) return;
      const {
        contracts,
        contractName,
        sourceName
      } = state.compiler;
      const contractInterface = new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__.Interface(contracts[sourceName][contractName].abi);
      const chainName = (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.getChainName)(chainId);
      const deployArguments = contractInterface.encodeDeploy([...(state.config.usesDelegatedContract ? [(_erc721DelegatedAddre2 = erc721DelegatedAddress[chainName]) !== null && _erc721DelegatedAddre2 !== void 0 ? _erc721DelegatedAddre2 : undefined] : []), (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .getBaseURI */ .Lw)(state.config.tokenURI), ...(state.config.requireAccessToken ? [state.config.requireAccessToken[chainName]] : []), ...(state.config.approvalProxyAddress ? [state.config.approvalProxyAddress[chainName]] : [])]).replace('0x', '');
      const verifyRequest = (0,_utils_verify__WEBPACK_IMPORTED_MODULE_23__/* .toVerifyRequest */ .uK)({
        apiKey: state.apiKeys.etherscan,
        compilerVersion: 'v0.8.9+commit.e5eed63a',
        constructorArguments: deployArguments,
        contractAddress: state.deployment.address,
        contractName: state.compiler.contractName,
        sourceCode: JSON.stringify((0,solidity_compiler__WEBPACK_IMPORTED_MODULE_10__/* .createCompilerInput */ .p)(state.compiler.files)),
        sourceName: state.compiler.contractName + '.sol'
      });
      dispatch({
        type: 'setVerifying'
      }); // console.log('req', verifyRequest);

      const verificationResult = await (0,_utils_verify__WEBPACK_IMPORTED_MODULE_23__/* .verifyContract */ .WF)((0,web3_utils__WEBPACK_IMPORTED_MODULE_12__/* .getEtherscanApiUrl */ .y5)(chainId), verifyRequest);

      if (verificationResult instanceof Error) {
        dispatch({
          type: 'setVerificationFailed',
          error: verificationResult
        });
        return;
      } // console.log('res', verificationResult);


      const checkStatusRequest = (0,_utils_verify__WEBPACK_IMPORTED_MODULE_23__/* .toCheckStatusRequest */ .mE)({
        apiKey: state.apiKeys.etherscan,
        guid: verificationResult.result
      });
      const checkStatusResult = await (0,_utils_verify__WEBPACK_IMPORTED_MODULE_23__/* .checkVerificationStatus */ .CW)((0,web3_utils__WEBPACK_IMPORTED_MODULE_12__/* .getEtherscanApiUrl */ .y5)(chainId), checkStatusRequest);

      if (checkStatusResult instanceof Error) {
        console.warn('Failed to verify', checkStatusResult);
        dispatch({
          type: 'setVerificationFailed',
          error: checkStatusResult
        });
      } else {
        dispatch({
          type: 'setVerified'
        });
      }
    }

    main();
  }, [chainId, state.apiKeys.etherscan, state.compiler, state.config.approvalProxyAddress, state.config.tokenURI, state.config.requireAccessToken, state.config.usesDelegatedContract, state.deployment]);
  const hasStartedDeploying = state.deployment.type !== 'notStarted';
  (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(() => {
    localStorage.setItem('etherscanApiKey', state.apiKeys.etherscan);
  }, [state.apiKeys.etherscan]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx("title", {
        children: "Studio 721 Contract"
      }), (0,components__WEBPACK_IMPORTED_MODULE_2__/* .getHeadTags */ .Bm)({
        pageTitle: 'Studio 721 Contract',
        pageDescription: 'The free, all-in-one tool for configuring, deploying, and verifying NFT smart contracts.',
        config: _utils_socialConfig__WEBPACK_IMPORTED_MODULE_21__/* .socialConfig */ .R
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx("link", {
        rel: "icon",
        href: "/favicon.ico"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
      margin: '60px 0 0 0',
      flex: '1 1 0%',
      breakpoints: {
        [800]: {
          flexDirection: 'column'
        }
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
        flex: "1 1 0px",
        breakpoints: {
          [800]: {
            flex: '0 0 auto'
          }
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
          overflowY: "auto",
          flex: "1 1 0px",
          gap: 40,
          padding: '20px 40px',
          breakpoints: {
            [800]: {
              overflowY: 'initial'
            }
          },
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
            gap: 10,
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .Regular */ .FE, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx("strong", {
                children: "Studio 721"
              }), " is a free tool for configuring, compiling, deploying, and verifying custom", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
                openInNewTab: true,
                href: "https://docs.openzeppelin.com/contracts/2.x/api/token/erc721",
                style: {
                  whiteSpace: 'pre'
                },
                children: "ERC 721"
              }), ' ', "NFT smart contracts. Studio 721 doesn", "'", "t host your assets or metadata; use your favorite hosting service and link it to your NFT via ", '"', "Token URI", '"', ". Not sure where to start? There's a", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
                href: "/guide/studio/contract",
                children: "video walkthrough!"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .Regular */ .FE, {
              children: ["Created by ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .TwitterChip */ .S4, {
                value: "@dvnabbott"
              })]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_TokenPreview__WEBPACK_IMPORTED_MODULE_18__/* .TokenPreview */ .a0, {
            config: state.config,
            disabled: hasStartedDeploying,
            dispatch: dispatch
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_MintingSection__WEBPACK_IMPORTED_MODULE_15__/* .MintingSection */ .y, {
            config: state.config,
            disabled: hasStartedDeploying,
            dispatch: dispatch
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_ParametersSection__WEBPACK_IMPORTED_MODULE_16__/* .ParametersSection */ .D, {
            disabled: hasStartedDeploying,
            dispatch: dispatch,
            parameters: state.config.tokenParameters
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_PayoutSection__WEBPACK_IMPORTED_MODULE_17__/* .PayoutSection */ .f, {
            disabled: hasStartedDeploying,
            dispatch: dispatch,
            destinations: state.config.payoutDestinations
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_AllowlistSection__WEBPACK_IMPORTED_MODULE_13__/* .AllowlistSection */ .m, {
            allowedForOwner: state.config.amountAllowedForOwner,
            disabled: hasStartedDeploying,
            dispatch: dispatch,
            destinations: state.config.allowlistDestinations
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_VerificationSection__WEBPACK_IMPORTED_MODULE_19__/* .VerificationSection */ .c, {
            etherscanApiKey: state.apiKeys.etherscan,
            dispatch: dispatch
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 10
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
        flex: "1 1 0%",
        background: "black",
        breakpoints: {
          [800]: {
            flex: '0 0 auto'
          }
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
          overflowY: "auto",
          flex: "2 2 0px",
          breakpoints: {
            [800]: {
              minHeight: 400
            }
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
            flex: "1 1 0px",
            padding: 20,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .CodeHighlight */ .P4, {
              code: (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_9__/* .generateContractSource */ .fX)(state.config),
              language: 'solidity'
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Divider */ .iz, {
          variant: "light"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
          overflowY: "auto",
          flex: "1 1 0px",
          breakpoints: {
            [800]: {
              minHeight: 400
            }
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(_components_contract_ContractConsole__WEBPACK_IMPORTED_MODULE_14__/* .ContractConsole */ .Y, {
            compiler: state.compiler,
            deployment: state.deployment,
            verification: state.verification
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Divider */ .iz, {
          variant: "light"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
          gap: 20,
          padding: 20,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
            gap: 20,
            flexWrap: "wrap",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
              disabled: state.compiler.type === 'done',
              onClick: handleCompile,
              children: "Compile"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
              disabled: !provider || state.compiler.type !== 'done' || state.deployment.type !== 'notStarted',
              onClick: handleDeploy,
              children: chainId ? `Deploy on ${(0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.getChainName)(chainId)}` : 'Deploy' + (state.compiler.type === 'done' && !provider ? ' (connect wallet to deploy)' : '')
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
              disabled: state.deployment.type !== 'deployed' || state.verification.type !== 'notStarted' || !state.apiKeys.etherscan,
              onClick: handleVerify,
              children: ["Verify", ' ', !state.apiKeys.etherscan && state.deployment.type === 'deployed' ? '(need API key)' : '']
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
              alignItems: "center",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_22__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .ConnectButton */ .NL, {})
            })]
          })
        })]
      })]
    })]
  });
} // Next router only picks up parameters if we render server-side

async function getServerSideProps(context) {
  return {
    props: {}
  };
}
});

/***/ }),

/***/ 6508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ deployContract)
/* harmony export */ });
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_1__);


async function deployContract(signer, contractAbi, contractByteCode, constructorArguments) {
  const factory = new ethers__WEBPACK_IMPORTED_MODULE_1__.ContractFactory(contractAbi, contractByteCode, signer);
  const contract = await factory.deploy(...constructorArguments);
  await contract.deployed();
  return (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.createAddress)(contract.address);
}

/***/ }),

/***/ 1201:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ saveFile)
/* harmony export */ });
/* harmony import */ var browser_fs_access__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(168);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([browser_fs_access__WEBPACK_IMPORTED_MODULE_0__]);
browser_fs_access__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

async function saveFile(name, type, extension, data) {
  const file = new File([data], name, {
    type
  });
  await (0,browser_fs_access__WEBPACK_IMPORTED_MODULE_0__.fileSave)(file, {
    fileName: file.name,
    extensions: [extension]
  }, undefined, false);
}
});

/***/ }),

/***/ 2060:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ socialConfig)
/* harmony export */ });
const socialConfig = {
  title: 'Studio 721',
  location: {
    host: 'www.721.so'
  },
  author: {
    twitter: 'dvnabbott'
  },
  favicons: [{
    type: 'image/x-icon',
    path: '/favicon.ico'
  }],
  previewImage: {
    type: 'image/png',
    width: '1200',
    height: '630',
    alt: 'Studio 721',
    path: '/studio-721-preview-card.png'
  }
};

/***/ }),

/***/ 1563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uK": () => (/* binding */ toVerifyRequest),
/* harmony export */   "mE": () => (/* binding */ toCheckStatusRequest),
/* harmony export */   "WF": () => (/* binding */ verifyContract),
/* harmony export */   "CW": () => (/* binding */ checkVerificationStatus)
/* harmony export */ });
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
} // Mostly adapted from:
// https://github.com/nomiclabs/hardhat/tree/master/packages/hardhat-etherscan (MIT)


function toVerifyRequest(params) {
  return {
    apikey: params.apiKey,
    module: 'contract',
    action: 'verifysourcecode',
    contractaddress: params.contractAddress,
    sourceCode: params.sourceCode,
    codeformat: 'solidity-standard-json-input',
    contractname: `${params.sourceName}:${params.contractName}`,
    compilerversion: params.compilerVersion,
    constructorArguements: params.constructorArguments
  };
}
function toCheckStatusRequest(params) {
  return {
    apikey: params.apiKey,
    module: 'contract',
    action: 'checkverifystatus',
    guid: params.guid
  };
} //////

async function verifyContract(etherscanApiUrl, req) {
  const parameters = new URLSearchParams(_objectSpread({}, req));
  const requestDetails = {
    method: 'post',
    body: parameters
  };
  let response;

  try {
    response = await fetch(etherscanApiUrl, requestDetails);
  } catch (error) {
    console.error('Failed to validate');
    return error;
  }

  if (!response.ok) {
    const responseText = await response.text();
    return new Error(`Error: HTTP request failed. ${responseText}`);
  }

  const json = await response.json();

  if (json.status === '0') {
    return new Error(`Error: ${json.result}`);
  }

  return json;
}
async function checkVerificationStatus(etherscanApiUrl, req) {
  console.log('checking');
  const parameters = new URLSearchParams(_objectSpread({}, req));
  const urlWithQuery = new URL(etherscanApiUrl);
  urlWithQuery.search = parameters.toString();

  try {
    const response = await fetch(urlWithQuery.toString());

    if (!response.ok) {
      const responseText = await response.text();
      const message = `Error: HTTP request failed. ${responseText}`;
      return new Error(message);
    }

    const json = await response.json();

    if (json.result === 'Pending in queue') {
      return new Promise((resolve, reject) => {
        setTimeout(async () => {
          const result = await checkVerificationStatus(etherscanApiUrl, req);

          if (result instanceof Error) {
            reject(result);
          } else {
            resolve();
          }
        }, 1200);
      });
    }

    if (json.result !== 'Pass - Verified' && json.result !== 'Already Verified') {
      return new Error('Failed to verify: ' + json.result);
    }

    console.log('result', json);
  } catch (error) {
    return error;
  }
}

/***/ }),

/***/ 8392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export downloadCompiler */
/* harmony import */ var cross_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9031);
/* harmony import */ var cross_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cross_fetch__WEBPACK_IMPORTED_MODULE_0__);


function isWebWorker(value) {
  return typeof value.importScripts === 'function';
}

const URL = 'https://www.721.so/solc/soljson-v0.8.9+commit.e5eed63a.js';
/**
 * Download and evaluate the compiler script
 *
 * @returns The emscripten-compiled solc API
 */

async function downloadCompiler() {
  const self = globalThis;

  if (isWebWorker(self)) {
    self.importScripts(URL);
    return self.Module;
  } else {
    const result = await fetch(URL);
    const text = await result.text(); // eslint-disable-next-line no-eval

    const solc = eval(text + '\n;Module;');
    return solc;
  }
}

/***/ }),

/***/ 3988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* reexport safe */ _input__WEBPACK_IMPORTED_MODULE_1__.p)
/* harmony export */ });
/* unused harmony export getCompiler */
/* harmony import */ var _download__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8392);
/* harmony import */ var _input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6117);




async function getCompiler() {
  const solc = await downloadCompiler();
  return wrapCompilerModule(solc);
}

/***/ }),

/***/ 6117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ createCompilerInput)
/* harmony export */ });
function createCompilerInput(files) {
  return {
    language: 'Solidity',
    sources: Object.fromEntries(Object.entries(files).map(([name, content]) => [name, {
      content
    }])),
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      },
      outputSelection: {
        '*': {
          '*': ['*']
        }
      }
    }
  };
}

/***/ }),

/***/ 3831:
/***/ ((module) => {

module.exports = require("@dnd-kit/core");

/***/ }),

/***/ 8196:
/***/ ((module) => {

module.exports = require("@dnd-kit/sortable");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 5757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 2792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 3138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 3427:
/***/ ((module) => {

module.exports = require("@metamask/detect-provider");

/***/ }),

/***/ 4008:
/***/ ((module) => {

module.exports = require("@openpalette/contract");

/***/ }),

/***/ 290:
/***/ ((module) => {

module.exports = require("@radix-ui/primitive");

/***/ }),

/***/ 374:
/***/ ((module) => {

module.exports = require("@radix-ui/react-accordion");

/***/ }),

/***/ 9693:
/***/ ((module) => {

module.exports = require("@radix-ui/react-aspect-ratio");

/***/ }),

/***/ 7093:
/***/ ((module) => {

module.exports = require("@radix-ui/react-checkbox");

/***/ }),

/***/ 5344:
/***/ ((module) => {

module.exports = require("@radix-ui/react-compose-refs");

/***/ }),

/***/ 5766:
/***/ ((module) => {

module.exports = require("@radix-ui/react-context-menu");

/***/ }),

/***/ 3363:
/***/ ((module) => {

module.exports = require("@radix-ui/react-dialog");

/***/ }),

/***/ 8532:
/***/ ((module) => {

module.exports = require("@radix-ui/react-dropdown-menu");

/***/ }),

/***/ 599:
/***/ ((module) => {

module.exports = require("@radix-ui/react-hover-card");

/***/ }),

/***/ 2132:
/***/ ((module) => {

module.exports = require("@radix-ui/react-icons");

/***/ }),

/***/ 8456:
/***/ ((module) => {

module.exports = require("@radix-ui/react-popover");

/***/ }),

/***/ 8375:
/***/ ((module) => {

module.exports = require("@radix-ui/react-progress");

/***/ }),

/***/ 5213:
/***/ ((module) => {

module.exports = require("@radix-ui/react-scroll-area");

/***/ }),

/***/ 8034:
/***/ ((module) => {

module.exports = require("@radix-ui/react-slider");

/***/ }),

/***/ 999:
/***/ ((module) => {

module.exports = require("@radix-ui/react-tooltip");

/***/ }),

/***/ 424:
/***/ ((module) => {

module.exports = require("car-file");

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 3922:
/***/ ((module) => {

module.exports = require("imfs");

/***/ }),

/***/ 7133:
/***/ ((module) => {

module.exports = require("immer");

/***/ }),

/***/ 4053:
/***/ ((module) => {

module.exports = require("language-tools");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3920:
/***/ ((module) => {

module.exports = require("prettier");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 4607:
/***/ ((module) => {

module.exports = require("prism-react-renderer/prism");

/***/ }),

/***/ 4196:
/***/ ((module) => {

module.exports = require("prism-react-renderer/themes/vsDark");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6325:
/***/ ((module) => {

module.exports = require("react-virtualized");

/***/ }),

/***/ 551:
/***/ ((module) => {

module.exports = require("react-window");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 4940:
/***/ ((module) => {

module.exports = require("tree-visit");

/***/ }),

/***/ 168:
/***/ ((module) => {

module.exports = import("browser-fs-access");;

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = import("fflate");;

/***/ }),

/***/ 7597:
/***/ ((module) => {

module.exports = import("w3c-keyname");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [945,97,615,621,898,44,770], () => (__webpack_exec__(1678)));
module.exports = __webpack_exports__;

})();
"use strict";
exports.id = 621;
exports.ids = [621];
exports.modules = {

/***/ 2555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ DesignSystemConfigurationProvider),
/* harmony export */   "o": () => (/* binding */ useDesignSystemConfiguration)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const DesignSystemConfigurationContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
const DesignSystemConfigurationProvider = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function DesignSystemConfigurationProvider({
  children,
  theme,
  platform
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(DesignSystemConfigurationContext.Provider, {
    value: (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
      platform
    }), [platform]),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
      theme: theme,
      children: children
    })
  });
});
function useDesignSystemConfiguration() {
  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(DesignSystemConfigurationContext);

  if (!value) {
    throw new Error('Missing DesignSystemConfigurationProvider');
  }

  return value;
}

/***/ }),

/***/ 9995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useKeyboardShortcuts)
/* harmony export */ });
/* unused harmony export IGNORE_GLOBAL_KEYBOARD_SHORTCUTS_CLASS */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _keyMap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(758);
/* harmony import */ var _platform__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2947);
/* harmony import */ var _shortcuts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4307);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_keyMap__WEBPACK_IMPORTED_MODULE_1__, _shortcuts__WEBPACK_IMPORTED_MODULE_2__]);
([_keyMap__WEBPACK_IMPORTED_MODULE_1__, _shortcuts__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




const IGNORE_GLOBAL_KEYBOARD_SHORTCUTS_CLASS = 'ignore-global-events';
const placeholder = {
  addEventListener() {},

  removeEventListener() {}

};
function useKeyboardShortcuts(shortcuts, options = {}) {
  var _options$eventName;

  const eventName = (_options$eventName = options.eventName) !== null && _options$eventName !== void 0 ? _options$eventName : 'keydown';
  const eventRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => options.eventListener !== undefined ? options.eventListener : typeof document !== 'undefined' ? document : placeholder, [options === null || options === void 0 ? void 0 : options.eventListener]);
  const platformName = (0,_platform__WEBPACK_IMPORTED_MODULE_3__/* .getCurrentPlatform */ .z)(typeof navigator !== 'undefined' ? navigator : undefined);
  const keyMap = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,_keyMap__WEBPACK_IMPORTED_MODULE_1__/* .createKeyMap */ .I)(shortcuts, platformName), [platformName, shortcuts]);
  const keyMapRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(keyMap);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    keyMapRef.current = keyMap;
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const handler = event => {
      if ((event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) && !event.target.classList.contains(IGNORE_GLOBAL_KEYBOARD_SHORTCUTS_CLASS)) return;
      const eventShortcutNames = (0,_shortcuts__WEBPACK_IMPORTED_MODULE_2__/* .getEventShortcutNames */ .V)(event, platformName);
      const matchingName = eventShortcutNames.find(name => name in keyMapRef.current);
      if (!matchingName) return;
      const command = keyMapRef.current[matchingName];
      const result = command();

      if (result !== _keyMap__WEBPACK_IMPORTED_MODULE_1__/* .FALLTHROUGH */ .j) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };

    const listenerElement = eventRef;
    listenerElement === null || listenerElement === void 0 ? void 0 : listenerElement.addEventListener(eventName, handler);
    return () => {
      listenerElement === null || listenerElement === void 0 ? void 0 : listenerElement.removeEventListener(eventName, handler);
    };
  }, [eventName, eventRef, platformName]);
}
});

/***/ }),

/***/ 6682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "aL": () => (/* reexport safe */ _hooks__WEBPACK_IMPORTED_MODULE_0__.a),
/* harmony export */   "zT": () => (/* reexport safe */ _platform__WEBPACK_IMPORTED_MODULE_1__.z),
/* harmony export */   "bS": () => (/* reexport safe */ _names__WEBPACK_IMPORTED_MODULE_2__.bS)
/* harmony export */ });
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9995);
/* harmony import */ var _platform__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2947);
/* harmony import */ var _names__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4662);
/* harmony import */ var _keyMap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(758);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_keyMap__WEBPACK_IMPORTED_MODULE_3__, _hooks__WEBPACK_IMPORTED_MODULE_0__]);
([_keyMap__WEBPACK_IMPORTED_MODULE_3__, _hooks__WEBPACK_IMPORTED_MODULE_0__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




});

/***/ }),

/***/ 758:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ FALLTHROUGH),
/* harmony export */   "I": () => (/* binding */ createKeyMap)
/* harmony export */ });
/* harmony import */ var _shortcuts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4307);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_shortcuts__WEBPACK_IMPORTED_MODULE_0__]);
_shortcuts__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

const FALLTHROUGH = 'fallthrough';
function createKeyMap(shortcuts, platformName) {
  const shortcutsArray = Array.isArray(shortcuts) ? shortcuts : Object.entries(shortcuts);
  return Object.fromEntries(shortcutsArray.flatMap(([key, command]) => {
    const platformShortcutName = (0,_shortcuts__WEBPACK_IMPORTED_MODULE_0__/* .getPlatformShortcutName */ .b)(typeof key === 'string' ? {
      key
    } : key, platformName);
    return platformShortcutName ? [[platformShortcutName, command]] : [];
  }));
}
});

/***/ }),

/***/ 4662:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EV": () => (/* binding */ normalizeKeyName),
/* harmony export */   "bS": () => (/* binding */ getShortcutDisplayParts),
/* harmony export */   "x6": () => (/* binding */ prependModifiers)
/* harmony export */ });
/* unused harmony export parseKeyName */
function parseKeyName(name, platform) {
  const parts = name.split(/-(?!$)/);
  let result = parts[parts.length - 1];
  if (result === 'Space') result = ' ';
  let alt = false;
  let ctrl = false;
  let shift = false;
  let meta = false;

  for (let i = 0; i < parts.length - 1; ++i) {
    const mod = parts[i];
    if (/^(cmd|meta|m)$/i.test(mod)) meta = true;else if (/^a(lt)?$/i.test(mod)) alt = true;else if (/^(c|ctrl|control)$/i.test(mod)) ctrl = true;else if (/^s(hift)?$/i.test(mod)) shift = true;else if (/^mod$/i.test(mod)) {
      if (platform === 'mac') meta = true;else ctrl = true;
    } else throw new Error('Unrecognized modifier name: ' + mod);
  }

  return {
    key: result,
    modifiers: {
      altKey: alt,
      ctrlKey: ctrl,
      shiftKey: shift,
      metaKey: meta
    }
  };
}
function normalizeKeyName(name, platform) {
  const parsed = parseKeyName(name, platform);
  let result = parsed.key;
  if (parsed.modifiers.altKey) result = 'Alt-' + result;
  if (parsed.modifiers.ctrlKey) result = 'Ctrl-' + result;
  if (parsed.modifiers.metaKey) result = 'Meta-' + result;
  if (parsed.modifiers.shiftKey) result = 'Shift-' + result;
  return result;
}
const modifierDisplayName = {
  altKey: 'Alt',
  ctrlKey: 'Ctrl',
  metaKey: '⊞',
  shiftKey: 'Shift'
};
const macModiferDisplayName = {
  altKey: '⌥',
  ctrlKey: '^',
  metaKey: '⌘',
  shiftKey: '⇧'
};

function getModifierDisplayName(name, platform) {
  return platform === 'mac' ? macModiferDisplayName[name] : modifierDisplayName[name];
}

function getShortcutDisplayParts(name, platform) {
  const {
    key,
    modifiers
  } = parseKeyName(name, platform);
  return {
    separator: platform === 'mac' ? undefined : '-',
    keys: [modifiers.altKey && getModifierDisplayName('altKey', platform), modifiers.ctrlKey && getModifierDisplayName('ctrlKey', platform), modifiers.shiftKey && getModifierDisplayName('shiftKey', platform), modifiers.metaKey && getModifierDisplayName('metaKey', platform), key.toUpperCase()].filter(x => !!x)
  };
}
function prependModifiers(name, event, useShift) {
  if (event.altKey) name = 'Alt-' + name;
  if (event.ctrlKey) name = 'Ctrl-' + name;
  if (event.metaKey) name = 'Meta-' + name;
  if (useShift !== false && event.shiftKey) name = 'Shift-' + name;
  return name;
}

/***/ }),

/***/ 2947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ getCurrentPlatform)
/* harmony export */ });
const getCurrentPlatform = navigator => typeof navigator === 'undefined' ? 'key' : /Mac/.test(navigator.platform) ? 'mac' : /Win/.test(navigator.platform) ? 'win' : /Linux|X11/.test(navigator.platform) ? 'linux' : 'key';

/***/ }),

/***/ 4307:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getPlatformShortcutName),
/* harmony export */   "V": () => (/* binding */ getEventShortcutNames)
/* harmony export */ });
/* harmony import */ var w3c_keyname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7597);
/* harmony import */ var _names__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4662);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([w3c_keyname__WEBPACK_IMPORTED_MODULE_0__]);
w3c_keyname__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


function getPlatformShortcutName(shortcut, platformName) {
  const platformKey = shortcut[platformName] || shortcut.key;
  return platformKey ? (0,_names__WEBPACK_IMPORTED_MODULE_1__/* .normalizeKeyName */ .EV)(platformKey, platformName) : undefined;
}
const modifierKeyNames = new Set(['Alt', 'Control', 'Meta', 'Shift']);
function getEventShortcutNames(event, platformName) {
  const eventKeyName = (0,w3c_keyname__WEBPACK_IMPORTED_MODULE_0__.keyName)(event);
  const isChar = eventKeyName.length === 1 && eventKeyName !== ' ';
  const eventModifiers = {
    altKey: event.altKey,
    shiftKey: event.shiftKey,
    ctrlKey: event.ctrlKey,
    metaKey: event.metaKey
  };
  const eventShortcutName = (0,_names__WEBPACK_IMPORTED_MODULE_1__/* .normalizeKeyName */ .EV)(modifierKeyNames.has(eventKeyName) ? eventKeyName : (0,_names__WEBPACK_IMPORTED_MODULE_1__/* .prependModifiers */ .x6)(eventKeyName, eventModifiers, !isChar), platformName);
  const shortcutNames = [eventShortcutName];
  const baseKeyName = w3c_keyname__WEBPACK_IMPORTED_MODULE_0__.base[event.keyCode];

  if (isChar) {
    let alternateShortcutName;

    if ( // Holding these keys may change the key that gets entered,
    // e.g. pressing "Alt" + "a" will enter "å". However, we can look
    // at the basename to get the actual key pressed.
    (event.shiftKey || event.altKey || event.metaKey) && baseKeyName && baseKeyName !== eventShortcutName) {
      alternateShortcutName = (0,_names__WEBPACK_IMPORTED_MODULE_1__/* .normalizeKeyName */ .EV)((0,_names__WEBPACK_IMPORTED_MODULE_1__/* .prependModifiers */ .x6)(baseKeyName, eventModifiers, true), platformName);
    } else if (event.shiftKey) {
      // At this point, we've previously added a shortcut like "@",
      // but we also want to add "Shift+@" for a more convenient API
      alternateShortcutName = (0,_names__WEBPACK_IMPORTED_MODULE_1__/* .normalizeKeyName */ .EV)((0,_names__WEBPACK_IMPORTED_MODULE_1__/* .prependModifiers */ .x6)(eventShortcutName, eventModifiers, true), platformName);
    }

    if (alternateShortcutName && !shortcutNames.includes(alternateShortcutName)) {
      shortcutNames.push(alternateShortcutName);
    }
  }

  return shortcutNames;
}
});

/***/ })

};
;
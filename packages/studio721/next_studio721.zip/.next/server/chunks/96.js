/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 8392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ downloadCompiler)
/* harmony export */ });
/* harmony import */ var cross_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9031);
/* harmony import */ var cross_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cross_fetch__WEBPACK_IMPORTED_MODULE_0__);


function isWebWorker(value) {
  return typeof value.importScripts === 'function';
}

const URL = 'https://www.721.so/solc/soljson-v0.8.9+commit.e5eed63a.js';
/**
 * Download and evaluate the compiler script
 *
 * @returns The emscripten-compiled solc API
 */

async function downloadCompiler() {
  const self = globalThis;

  if (isWebWorker(self)) {
    self.importScripts(URL);
    return self.Module;
  } else {
    const result = await cross_fetch__WEBPACK_IMPORTED_MODULE_0___default()(URL);
    const text = await result.text(); // eslint-disable-next-line no-eval

    const solc = eval(text + '\n;Module;');
    return solc;
  }
}

/***/ }),

/***/ 9031:
/***/ ((module) => {

module.exports = require("cross-fetch");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete __webpack_module_cache__[moduleId];
/******/ 		}
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {

// EXTERNAL MODULE: ../solidity-compiler/src/download.ts
var download = __webpack_require__(8392);
;// CONCATENATED MODULE: ../solidity-compiler/src/wrap.ts
/**
 * Wrap the relevant solc API methods so they're easier to use
 *
 * @param solc
 * @returns
 */
function wrapCompilerModule(solc) {
  const version = solc.cwrap('solidity_version', 'string', [])();
  const solidityCompile = solc.cwrap('solidity_compile', 'string', ['string', 'number', 'number']);
  return {
    version,

    compile(input) {
      return JSON.parse(solidityCompile(JSON.stringify(input)));
    }

  };
}
;// CONCATENATED MODULE: ../solidity-compiler/src/index.ts




async function getCompiler() {
  const solc = await (0,download/* downloadCompiler */.H)();
  return wrapCompilerModule(solc);
}
;// CONCATENATED MODULE: ./src/worker.ts

const compilerPromise = getCompiler(); // eslint-disable-next-line no-restricted-globals

addEventListener('message', async event => {
  const request = event.data;

  switch (request.type) {
    case 'compile':
      {
        const compiler = await compilerPromise;
        const output = compiler.compile(request.request.input);
        const response = {
          id: request.id,
          type: request.type,
          response: {
            output
          }
        };
        postMessage(response);
      }
  }
});
})();

module.exports = __webpack_exports__;
/******/ })()
;
"use strict";
exports.id = 288;
exports.ids = [288];
exports.modules = {

/***/ 5288:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XQ": () => (/* binding */ SimplePrimaryButton),
/* harmony export */   "BR": () => (/* binding */ getMintingParameters),
/* harmony export */   "zv": () => (/* binding */ MintingCardDetails)
/* harmony export */ });
/* unused harmony export getUnsupportedMintingParameters */
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9022);
/* harmony import */ var contract_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4044);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1801);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5781);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8531);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6221);
/* harmony import */ var web3_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9772);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state__WEBPACK_IMPORTED_MODULE_9__, designsystem__WEBPACK_IMPORTED_MODULE_6__]);
([state__WEBPACK_IMPORTED_MODULE_9__, designsystem__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

















const SimplePrimaryButton = styled_components__WEBPACK_IMPORTED_MODULE_10___default().button.withConfig({
  displayName: "MintingCardDetails__SimplePrimaryButton",
  componentId: "sc-v53ahd-0"
})({
  appearance: 'none',
  padding: '12px 16px',
  borderRadius: '4px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontWeight: 600,
  fontSize: '1rem',
  cursor: 'pointer',
  userSelect: 'none',
  background: 'white'
});
function getMintingParameters(mint, parameterMapping) {
  const inputNames = mint.inputs.map(input => input.name);
  const supportedInputs = inputNames.filter(name => Object.values(parameterMapping).includes(name));
  if (inputNames.length !== supportedInputs.length) return undefined;
  return supportedInputs;
}
function getUnsupportedMintingParameters(mint, parameterMapping) {
  const inputNames = mint.inputs.map(input => input.name);
  const unsupportedInputs = inputNames.filter(name => !Object.values(parameterMapping).includes(name));
  return unsupportedInputs;
}

function useMintingData({
  contract,
  abi,
  chainId,
  dataSources
}) {
  const mintFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.mint), {}, {
    name: dataSources.mint.name
  }));
  const mintParameters = mintFunction ? getMintingParameters(mintFunction, dataSources.mint.parameters) : undefined;
  const unsupportedMintParameters = mintFunction ? getUnsupportedMintingParameters(mintFunction, dataSources.mint.parameters) : [];
  const saleIsActiveFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.saleIsActive), {}, {
    name: dataSources.saleIsActive.name
  }));
  const saleIsActiveResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .useReadOnlyContractData */ .IH)({
    fragment: saleIsActiveFunction,
    contract,
    chainId
  });
  const maxSupplyFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.price), {}, {
    name: dataSources.MAX_SUPPLY.name
  }));
  const maxSupplyResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .useReadOnlyContractData */ .IH)({
    fragment: maxSupplyFunction,
    contract,
    chainId
  });
  const totalSupplyFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.price), {}, {
    name: dataSources.totalSupply.name
  }));
  const totalSupplyResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .useReadOnlyContractData */ .IH)({
    fragment: totalSupplyFunction,
    contract,
    chainId
  });
  const priceFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.price), {}, {
    name: dataSources.price.name
  }));
  const priceResult = (0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .useReadOnlyContractData */ .IH)({
    fragment: priceFunction,
    contract,
    chainId
  });
  const multimintFunction = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getFirstFunctionFragment)(abi, _objectSpread(_objectSpread({}, fragmentFilters.price), {}, {
    name: dataSources.MAX_MULTIMINT.name
  }));
  const multimintResult = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .mapPromiseState */ .PV)((0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .useReadOnlyContractData */ .IH)({
    fragment: multimintFunction,
    contract,
    chainId
  }), value => value.toNumber());
  const totalSupplyNumber = totalSupplyResult.type === 'success' ? totalSupplyResult.value : undefined;
  const maxSupplyNumber = maxSupplyResult.type === 'success' ? maxSupplyResult.value : undefined;
  const remainingSupplyResult = totalSupplyNumber instanceof _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber && maxSupplyNumber instanceof _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber ? {
    type: 'success',
    value: maxSupplyNumber.sub(totalSupplyNumber)
  } : {
    type: 'pending'
  };
  return {
    saleIsActiveResult,
    maxSupplyResult,
    totalSupplyResult,
    remainingSupplyResult,
    priceResult,
    multimintResult,
    hasPrice: !!priceFunction,
    hasMaxSupply: !!maxSupplyFunction,
    hasMultiMint: !!multimintFunction,
    mintParameters,
    unsupportedMintParameters,
    mintFunction
  };
}

function ItemMetadataRow({
  title,
  children,
  color = 'white',
  labelColor,
  labelOpacity
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
    flex: "1",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .__, {
      color: labelColor,
      opacity: labelOpacity,
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .SpacerHorizontal */ .lC, {
      size: 10
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .__, {
      color: color,
      children: children
    })]
  });
}

function LinkedDataPopover({
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Popover */ .J2, {
    width: 400,
    trigger: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Button */ .zx, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_2__.Link1Icon, {})
    }),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
      padding: 10,
      gap: 10,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormSection */ .hj, {
        title: "Data Source",
        children: children
      })
    })
  });
}

function union(array1, array2) {
  return [...new Set([...array1, ...array2])];
}

const fragmentFilters = {
  price: {
    inputs: 0,
    outputs: ['uint256'],
    stateMutability: 'view'
  },
  saleIsActive: {
    inputs: 0,
    outputs: ['bool'],
    stateMutability: 'view'
  },
  mint: {
    stateMutability: ['payable', 'nonpayable']
  }
};
function MintingCardDetails({
  editing,
  title,
  intrinsicName,
  description,
  contract,
  abi,
  invertForeground,
  coverAsset,
  contractChainId,
  dataSources,
  dispatch,
  onClickMint
}) {
  const theme = (0,styled_components__WEBPACK_IMPORTED_MODULE_10__.useTheme)();
  const {
    connect
  } = (0,contexts__WEBPACK_IMPORTED_MODULE_4__/* .useWeb3API */ .ry)();
  const chainId = (0,contexts__WEBPACK_IMPORTED_MODULE_4__/* .useChainId */ .xx)();
  const {
    saleIsActiveResult,
    maxSupplyResult,
    remainingSupplyResult,
    priceResult,
    hasPrice,
    hasMaxSupply,
    hasMultiMint,
    multimintResult,
    mintParameters,
    unsupportedMintParameters,
    mintFunction
  } = useMintingData({
    contract,
    abi,
    chainId: contractChainId,
    dataSources
  });
  const widthNumber = Number(coverAsset.size.width);
  const heightNumber = Number(coverAsset.size.height);

  const assetStyle = _objectSpread({
    filter: invertForeground ? 'invert()' : undefined,
    alignSelf: 'center',
    width: coverAsset.size.width && !isNaN(widthNumber) ? `${widthNumber}px` : coverAsset.size.width,
    height: coverAsset.size.height && !isNaN(heightNumber) ? `${heightNumber}px` : coverAsset.size.height,
    maxWidth: '100%'
  }, coverAsset.type !== 'webpage' && {
    objectFit: 'cover',
    objectPosition: 'center'
  });

  const wrongNetwork = chainId && contractChainId !== chainId;
  const intrinsicNameString = intrinsicName.type === 'success' ? intrinsicName.value : '';
  const {
    0: mintAmount,
    1: setMintAmount
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)('1');
  const possibleMintFunctionFragments = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getAllFunctionFragments)(abi, fragmentFilters.mint);
  const possibleMintFunctionNames = possibleMintFunctionFragments.map(fragment => fragment.name);
  const possibleMintFunctionNameOptions = union(possibleMintFunctionNames, [dataSources.mint.name, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.mint */ .l2.mint]);
  const possibleMintParameterNameOptions = mintFunction ? union(mintFunction.inputs.map(input => input.name), [dataSources.mint.parameters.count, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_PARAMETER_NAME.mint.count */ .pG.mint.count]) : [];
  const possiblePriceFunctionFragments = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getAllFunctionFragments)(abi, fragmentFilters.price);
  const possiblePriceFunctionNames = possiblePriceFunctionFragments.map(fragment => fragment.name);
  const priceFunctionNameOptions = union(possiblePriceFunctionNames, [dataSources.price.name, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.PRICE */ .l2.PRICE]);
  const totalSupplyFunctionNameOptions = union(possiblePriceFunctionNames, [dataSources.totalSupply.name, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.totalSupply */ .l2.totalSupply]);
  const maxSupplyFunctionNameOptions = union(possiblePriceFunctionNames, [dataSources.MAX_SUPPLY.name, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.MAX_SUPPLY */ .l2.MAX_SUPPLY]);
  const maxMultimintFunctionNameOptions = union(possiblePriceFunctionNames, [dataSources.MAX_MULTIMINT.name, state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.MAX_MULTIMINT */ .l2.MAX_MULTIMINT]);
  const possibleSaleIsActiveFunctionFragments = (0,utils__WEBPACK_IMPORTED_MODULE_11__.getAllFunctionFragments)(abi, fragmentFilters.saleIsActive);
  const possibleSaleIsActiveFunctionNames = possibleSaleIsActiveFunctionFragments.map(fragment => fragment.name);
  const saleIsActiveFunctionNameOptions = union(possibleSaleIsActiveFunctionNames, [state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.saleIsActive */ .l2.saleIsActive, dataSources.saleIsActive.name]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
      gap: 3,
      children: [!(0,web3_utils__WEBPACK_IMPORTED_MODULE_12__/* .isMainnetOrPolygon */ ._4)(contractChainId) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
        background: theme.colors.inputBackground,
        alignSelf: "flex-start",
        padding: "2px 4px",
        borderRadius: 4,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .__, {
          color: "white",
          children: ["This is a ", (0,_openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.getChainName)(contractChainId), " testnet contract"]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Heading1 */ .nL, {
        position: "relative",
        children: !title && intrinsicName.type !== 'success' && !editing ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("span", {
          className: "flickerAnimation",
          children: "Contract Loading..."
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .EditableTextArea */ .$2, {
          editing: editing,
          value: editing ? title !== undefined ? title : intrinsicNameString : title || intrinsicNameString,
          placeholder: intrinsicNameString || 'Title',
          onChange: value => {
            dispatch({
              type: 'setTitle',
              value
            });
          }
        })
      }), (description || editing) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Body */ .uT, {
        position: "relative",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .EditableTextArea */ .$2, {
          editing: editing,
          placeholder: "Description",
          value: description !== null && description !== void 0 ? description : '',
          onChange: value => {
            dispatch({
              type: 'setDescription',
              value
            });
          }
        })
      })]
    }), (coverAsset.type !== 'none' || editing) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, _objectSpread(_objectSpread({
      gap: 10,
      position: "relative"
    }, editing && {
      outline: '1px solid rgba(255,255,255,0.2)'
    }), {}, {
      children: [coverAsset.type === 'image' && coverAsset.url && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("img", {
        src: coverAsset.url,
        style: assetStyle,
        alt: "Token preview"
      }), coverAsset.type === 'video' && coverAsset.url && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("video", {
        src: coverAsset.url,
        loop: true,
        controls: true,
        preload: "auto",
        style: assetStyle,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("source", {
          src: coverAsset.url
        })
      }), coverAsset.type === 'webpage' && coverAsset.url && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("iframe", {
        title: "Interactive token",
        src: coverAsset.url,
        style: assetStyle
      }), editing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
        gap: 8,
        paddingVertical: 2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
          variant: "small",
          title: "Cover Asset",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
            id: "input-preset",
            value: coverAsset.type,
            options: ['none', 'image', 'video', 'webpage'],
            getTitle: id => (0,utils__WEBPACK_IMPORTED_MODULE_11__.upperFirst)(id),
            onChange: id => {
              dispatch({
                type: 'setCoverAssetType',
                value: id
              });
            }
          })
        }), coverAsset.type !== 'none' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
          variant: "small",
          title: "Asset URL",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Root */ .UP.fC, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Input */ .UP.II, {
              value: coverAsset.url,
              placeholder: 'https://...',
              onChange: value => {
                dispatch({
                  type: 'setCoverAssetUrl',
                  value
                });
              }
            })
          })
        }), coverAsset.type !== 'none' && coverAsset.url && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
          variant: "small",
          title: "Preferred Size",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
            flex: "1",
            gap: 8,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
              width: 70,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Root */ .UP.fC, {
                flex: "1",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Input */ .UP.II, {
                  value: coverAsset.size.width,
                  placeholder: '500',
                  onChange: value => {
                    dispatch({
                      type: 'setCoverAssetWidth',
                      value
                    });
                  }
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Label */ .UP.__, {
                  children: "W"
                })]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
              width: 70,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Root */ .UP.fC, {
                flex: "1",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Input */ .UP.II, {
                  value: coverAsset.size.height,
                  placeholder: '500',
                  onChange: value => {
                    dispatch({
                      type: 'setCoverAssetHeight',
                      value
                    });
                  }
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .InputField.Label */ .UP.__, {
                  children: "H"
                })]
              })
            })]
          })
        })]
      })]
    })), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
      gap: 4,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
        background: theme.colors.inputBackground,
        padding: 6,
        borderRadius: 4,
        display: "block",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
          flex: "1",
          children: [editing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(LinkedDataPopover, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
                variant: "small",
                title: "Price",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                  id: "input-preset",
                  value: dataSources.price.name,
                  options: priceFunctionNameOptions,
                  getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.PRICE */ .l2.PRICE ? `${name} (default)` : name,
                  onChange: id => {
                    dispatch({
                      type: 'setPriceFunctionName',
                      value: id
                    });
                  }
                })
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .SpacerHorizontal */ .lC, {
              size: 10
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ItemMetadataRow, {
            labelColor: theme.colors.text,
            labelOpacity: 0.8,
            title: "Price",
            children: !hasPrice ? 'Free' : priceResult.type === 'pending' ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("span", {
              className: "flickerAnimation",
              children: "Loading"
            }) : priceResult.type === 'success' ? (0,contract_data__WEBPACK_IMPORTED_MODULE_5__/* .priceToString */ .w9)(chainId || _openpalette_contract__WEBPACK_IMPORTED_MODULE_1__.CHAIN_ID.MAINNET, priceResult.value) : '?'
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
        background: theme.colors.inputBackground,
        padding: 6,
        borderRadius: 4,
        display: "block",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
          flex: "1",
          children: [editing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(LinkedDataPopover, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
                variant: "small",
                title: "Current # minted",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                  id: "input-preset",
                  value: dataSources.totalSupply.name,
                  options: totalSupplyFunctionNameOptions,
                  getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.totalSupply */ .l2.totalSupply ? `${name} (default)` : name,
                  onChange: id => {
                    dispatch({
                      type: 'setTotalSupplyFunctionName',
                      value: id
                    });
                  }
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
                variant: "small",
                title: "Max possible",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                  id: "input-preset",
                  value: dataSources.MAX_SUPPLY.name,
                  options: maxSupplyFunctionNameOptions,
                  getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.MAX_SUPPLY */ .l2.MAX_SUPPLY ? `${name} (default)` : name,
                  onChange: id => {
                    dispatch({
                      type: 'setMaxSupplyFunctionName',
                      value: id
                    });
                  }
                })
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .SpacerHorizontal */ .lC, {
              size: 10
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ItemMetadataRow, {
            labelColor: theme.colors.text,
            labelOpacity: 0.8,
            title: "Remaining",
            children: !hasMaxSupply ? 'Unlimited' : remainingSupplyResult.type === 'pending' || maxSupplyResult.type === 'pending' ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("span", {
              className: "flickerAnimation",
              children: "Loading"
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
              children: [remainingSupplyResult.type === 'success' ? remainingSupplyResult.value.toString() : '?', ' / ', maxSupplyResult.type === 'success' ? maxSupplyResult.value.toString() : '?']
            })
          })]
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
      gap: 20,
      children: [hasMultiMint && multimintResult.type === 'success' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .VStack */ .gC, {
        gap: 4,
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .Small */ .x4, {
          textAlign: "center",
          children: ["Amount to mint (", multimintResult.value, " max)"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Stepper */ .vF, {
          min: 1,
          max: multimintResult.value,
          inputValue: mintAmount,
          onChange: setMintAmount
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
        children: [editing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(LinkedDataPopover, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
              variant: "small",
              title: "Mint function",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                id: "input-preset",
                value: dataSources.mint.name,
                options: possibleMintFunctionNameOptions,
                getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.mint */ .l2.mint ? `${name} (default)` : name,
                onChange: id => {
                  dispatch({
                    type: 'setMintFunctionName',
                    value: id
                  });
                }
              })
            }), mintFunction && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
              variant: "small",
              title: "Quantity",
              indent: 1,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                id: "input-preset",
                value: dataSources.mint.parameters.count,
                options: possibleMintParameterNameOptions,
                getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_PARAMETER_NAME.mint.count */ .pG.mint.count ? `${name} (default)` : name,
                onChange: id => {
                  dispatch({
                    type: 'setMintCountParameterName',
                    value: id
                  });
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Divider */ .iz, {
              variant: "light"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
              variant: "small",
              title: "Sale is active",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .Checkbox */ .XZ, {
                variant: "dark",
                checked: !dataSources.saleIsActive.disabled,
                onCheckedChange: value => {
                  dispatch({
                    type: 'setSaleIsActiveEnabled',
                    value
                  });
                }
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                id: "input-preset",
                value: dataSources.saleIsActive.name,
                disabled: dataSources.saleIsActive.disabled,
                options: saleIsActiveFunctionNameOptions,
                getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.saleIsActive */ .l2.saleIsActive ? `${name} (default)` : name,
                onChange: id => {
                  dispatch({
                    type: 'setSaleIsActiveFunctionName',
                    value: id
                  });
                }
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .FormRow */ .p7, {
              variant: "small",
              title: "Multimint max",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_6__/* .Select */ .Ph, {
                id: "input-preset",
                value: dataSources.MAX_MULTIMINT.name,
                options: maxMultimintFunctionNameOptions,
                getTitle: name => name === state__WEBPACK_IMPORTED_MODULE_9__/* .DEFAULT_FUNCTION_NAME.MAX_MULTIMINT */ .l2.MAX_MULTIMINT ? `${name} (default)` : name,
                onChange: id => {
                  dispatch({
                    type: 'setMaxMultimintFunctionName',
                    value: id
                  });
                }
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .SpacerHorizontal */ .lC, {
            size: 10
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(SimplePrimaryButton, {
          style: {
            flex: 1
          },
          onClick: () => {
            if (!(contract !== null && contract !== void 0 && contract.provider)) {
              connect();
              return;
            }

            if (hasPrice && priceResult.type !== 'success') {
              console.warn(`Fetching price failed, can't mint`);
              return;
            }

            onClickMint({
              countInputValue: mintAmount,
              price: hasPrice && priceResult.type === 'success' ? priceResult.value : undefined,
              parameterMapping: dataSources.mint.parameters
            });
          },
          disabled: wrongNetwork || !mintParameters || !dataSources.saleIsActive.disabled && ( // Disable only if there's already a contract provider (a connected wallet).
          // If Http/JsonRpc providers fail, people can still connect a wallet, and we
          // can fall back to the wallet to fetch again.
          contract === null || contract === void 0 ? void 0 : contract.provider) && (saleIsActiveResult.type !== 'success' || !saleIsActiveResult.value),
          children: !mintParameters ? `This contract isn't supported!` : !(contract !== null && contract !== void 0 && contract.provider) ? 'Connect wallet' : wrongNetwork ? 'Connected to wrong network!' : dataSources.saleIsActive.disabled ? 'Mint' : saleIsActiveResult.type === 'pending' || hasPrice && priceResult.type === 'pending' ? 'Loading...' : saleIsActiveResult.type === 'failure' || hasPrice && priceResult.type === 'failure' ? 'Failed to load - please reload the page' : saleIsActiveResult.value ? 'Mint' : 'Not Started'
        })]
      }), !mintParameters && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_3__/* .HStack */ .Ug, {
        background: theme.colors.inputBackground,
        alignSelf: "flex-start",
        padding: "2px 4px",
        borderRadius: 4,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(components__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .__, {
          color: "white",
          children: ["Unsupported mint parameters:", ' ', unsupportedMintParameters.join(', ')]
        })
      })]
    })]
  });
}
});

/***/ })

};
;
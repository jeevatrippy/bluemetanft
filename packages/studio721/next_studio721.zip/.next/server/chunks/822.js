exports.id = 822;
exports.ids = [822];
exports.modules = {

/***/ 7338:
/***/ (() => {



/***/ }),

/***/ 3822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "initMiddleware": () => (/* reexport */ initMiddleware)
});

// UNUSED EXPORTS: NullAddress, UTF16, copyToClipboard, decodeQueryParameters, encodeQueryParameters, fetchData, getAllFunctionFragments, getFirstFunctionFragment, getIncrementedName, getMultiValue, getSignerFromProvider, groupBy, isAbsoluteUrl, isDeepEqual, isExternalUrl, memoize, mergeBreakpoints, parseUrl, range, unique, upperFirst, withSeparatorElements

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ../utils/src/withSeparatorElements.ts


function createKey(key) {
  return `s-${key}`;
}

function withSeparatorElements(elements, separator) {
  const childrenArray = Children.toArray(elements);

  for (let i = childrenArray.length - 1; i > 0; i--) {
    let sep = typeof separator === 'function' ? separator() : /*#__PURE__*/isValidElement(separator) ? /*#__PURE__*/cloneElement(separator, {
      key: createKey(i)
    }) : separator;

    if ( /*#__PURE__*/isValidElement(sep) && sep.key == null) {
      sep = /*#__PURE__*/cloneElement(sep, {
        key: createKey(i)
      });
    }

    childrenArray.splice(i, 0, sep);
  }

  return childrenArray;
}
// EXTERNAL MODULE: ../utils/src/GuidebookConfig.ts
var GuidebookConfig = __webpack_require__(7338);
;// CONCATENATED MODULE: ../utils/src/middleware.ts
// Helper method to wait for a middleware to execute before continuing
// And to throw an error when an error happens in a middleware
function initMiddleware(middleware) {
  return (req, res) => new Promise((resolve, reject) => {
    middleware(req, res, result => {
      if (result instanceof Error) {
        return reject(result);
      }

      return resolve(result);
    });
  });
}
// EXTERNAL MODULE: external "cross-fetch"
var external_cross_fetch_ = __webpack_require__(9031);
;// CONCATENATED MODULE: ../utils/src/fetchData.ts


/**
 * Fetch from a url.
 *
 * If the response status code is >=400, throw an error.
 *
 * @param url
 */
async function fetchData(url, encoding) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}`);
  }

  switch (encoding) {
    case 'text':
      return response.text();

    case 'arrayBuffer':
      return response.arrayBuffer();

    case 'json':
      return response.json();
  }
}
;// CONCATENATED MODULE: ../utils/src/utf16.ts
function toUTF8(string) {
  const encoder = new TextEncoder();
  return encoder.encode(string);
}

function fromUTF8(encoded) {
  const decoder = new TextDecoder();
  return decoder.decode(encoded);
}

const UTF16 = {
  toUTF8,
  fromUTF8
};
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
;// CONCATENATED MODULE: ../utils/src/ethersUtils.ts

function getFirstFunctionFragment(interface_, filters) {
  const results = getAllFunctionFragments(interface_, filters);
  return results.length > 0 ? results[0] : undefined;
}
function getSignerFromProvider(provider) {
  return provider instanceof ethers.providers.Web3Provider ? provider.getSigner() : undefined;
}
function getAllFunctionFragments(interface_, filters = {}) {
  const results = interface_.fragments.filter(fragment => fragment.type === 'function');
  return applyFilters(results, [typeof filters.name === 'string' && (fragment => fragment.name === filters.name), typeof filters.inputs === 'number' && (fragment => fragment.inputs.length === filters.inputs), filters.stateMutability !== undefined && (fragment => Array.isArray(filters.stateMutability) ? filters.stateMutability.includes(fragment.stateMutability) : fragment.stateMutability === filters.stateMutability), filters.outputs !== undefined && (fragment => {
    const filter = filters.outputs;

    if (fragment.outputs && filter) {
      return fragment.outputs.length === filter.length && fragment.outputs.every((item, index) => item.type === filter[index]);
    }

    return true;
  })]);
}

function applyFilters(items, filters) {
  return filters.reduce((result, filter) => typeof filter === 'function' ? result.filter(filter) : result, items);
}
;// CONCATENATED MODULE: ../utils/src/index.ts




















/***/ })

};
;
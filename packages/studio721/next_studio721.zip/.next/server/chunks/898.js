"use strict";
exports.id = 898;
exports.ids = [898];
exports.modules = {

/***/ 6731:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ ArrayController)
/* harmony export */ });
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9615);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6221);
/* harmony import */ var _components_ListView__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2166);
/* harmony import */ var _components_Sortable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4025);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ListView__WEBPACK_IMPORTED_MODULE_4__]);
_components_ListView__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
const _excluded = ["relativeDropPosition"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const ElementRow = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ArrayController__ElementRow",
  componentId: "sc-c98y5l-0"
})({
  flex: '0 0 auto',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center'
});
const ItemContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ArrayController__ItemContainer",
  componentId: "sc-c98y5l-1"
})({
  position: 'relative'
});

function ArrayControllerComponent({
  id,
  items,
  sortable = false,
  reversed = false,
  getKey,
  onMoveItem,
  renderItem
}) {
  const keys = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => items.map((item, index) => {
    var _getKey;

    return (_getKey = getKey === null || getKey === void 0 ? void 0 : getKey(item)) !== null && _getKey !== void 0 ? _getKey : index.toString();
  }), [getKey, items]);
  const indexes = reversed ? (0,utils__WEBPACK_IMPORTED_MODULE_3__.range)(0, items.length).reverse() : (0,utils__WEBPACK_IMPORTED_MODULE_3__.range)(0, items.length);
  const handleMoveItem = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((sourceIndex, destinationIndex, position) => {
    if (reversed) {
      if (position === 'above') {
        position = 'below';
      } else if (position === 'below') {
        position = 'above';
      }
    }

    onMoveItem === null || onMoveItem === void 0 ? void 0 : onMoveItem(sourceIndex, position === 'below' ? destinationIndex + 1 : destinationIndex);
  }, [onMoveItem, reversed]);

  const renderRow = index => {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(ElementRow, {
      children: renderItem({
        item: items[index],
        index: index
      })
    }, keys[index]);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .VStack */ .gC, {
    id: id,
    flex: "0 0 auto",
    gap: 10,
    children: sortable ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_Sortable__WEBPACK_IMPORTED_MODULE_5__/* .Root */ .f, {
      keys: keys,
      renderOverlay: renderRow,
      onMoveItem: handleMoveItem,
      children: indexes.map(index => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_Sortable__WEBPACK_IMPORTED_MODULE_5__/* .Item */ .c, {
        id: keys[index],
        children: _ref => {
          let {
            relativeDropPosition
          } = _ref,
              sortableProps = _objectWithoutProperties(_ref, _excluded);

          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(ItemContainer, _objectSpread(_objectSpread({}, sortableProps), {}, {
            children: [renderRow(index), relativeDropPosition && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ListView__WEBPACK_IMPORTED_MODULE_4__/* .DragIndicatorElement */ .$5, {
              relativeDropPosition: relativeDropPosition,
              offsetLeft: 0
            })]
          }));
        }
      }, keys[index]))
    }) : indexes.map(renderRow)
  });
}

const ArrayController = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(ArrayControllerComponent);
});

/***/ }),

/***/ 5523:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports Root, Item, Trigger, Content */
/* harmony import */ var _radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(374);
/* harmony import */ var _radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
const _excluded = (/* unused pure expression or super */ null && (["children", "showsChevron"])),
      _excluded2 = (/* unused pure expression or super */ null && (["children"]));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




 // const slideDown = keyframes({
//   from: { height: 0 },
//   to: { height: 'var(--radix-accordion-content-height)' },
// });
// const slideUp = keyframes({
//   from: { height: 'var(--radix-accordion-content-height)' },
//   to: { height: 0 },
// });



const StyledAccordion = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__.Root).withConfig({
  displayName: "Accordion__StyledAccordion",
  componentId: "sc-1cdhfot-0"
})(({
  theme
}) => ({
  borderRadius: 6,
  background: theme.colors.background // background: theme.colors.inputBackground,
  // boxShadow: `0 2px 10px ${blackA.blackA4}`,

}));
const StyledItem = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__.Item).withConfig({
  displayName: "Accordion__StyledItem",
  componentId: "sc-1cdhfot-1"
})(({
  theme
}) => ({
  overflow: 'hidden',
  marginTop: 1,
  background: theme.colors.inputBackground,
  '&:first-child': {
    marginTop: 0,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4
  },
  '&:last-child': {
    borderBottomLeftRadius: 4,
    borderBottomRightRadius: 4
  },
  '&:focus-within': {
    position: 'relative',
    zIndex: 1 // boxShadow: `0 0 0 2px ${mauve.mauve12}`,

  }
}));
const StyledHeader = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__.Header).withConfig({
  displayName: "Accordion__StyledHeader",
  componentId: "sc-1cdhfot-2"
})({
  all: 'unset',
  display: 'flex'
});
const StyledTrigger = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__.Trigger).withConfig({
  displayName: "Accordion__StyledTrigger",
  componentId: "sc-1cdhfot-3"
})(({
  theme
}) => ({
  all: 'unset',
  fontFamily: 'inherit',
  backgroundColor: 'transparent',
  padding: '8px 12px',
  // height: 32,
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  fontSize: 15,
  lineHeight: 1,
  color: theme.colors.text // boxShadow: `0 1px 0 ${mauve.mauve6}`,
  // '&[data-state="closed"]': { backgroundColor: 'white' },
  // '&[data-state="open"]': { backgroundColor: 'white' },
  // '&:hover': { backgroundColor: mauve.mauve2 },

}));
const StyledContent = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_accordion__WEBPACK_IMPORTED_MODULE_0__.Content).withConfig({
  displayName: "Accordion__StyledContent",
  componentId: "sc-1cdhfot-4"
})(({
  theme
}) => ({
  overflow: 'hidden',
  fontSize: 15,
  color: theme.colors.text,
  backgroundColor: theme.colors.activeBackground // '&[data-state="open"]': {
  //   animation: `${slideDown} 300ms cubic-bezier(0.87, 0, 0.13, 1)`,
  // },
  // '&[data-state="closed"]': {
  //   animation: `${slideUp} 300ms cubic-bezier(0.87, 0, 0.13, 1)`,
  // },

}));
const StyledContentText = styled_components__WEBPACK_IMPORTED_MODULE_3___default()('div').withConfig({
  displayName: "Accordion__StyledContentText",
  componentId: "sc-1cdhfot-5"
})({
  padding: '15px 20px'
});
const StyledChevron = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__.ChevronDownIcon).withConfig({
  displayName: "Accordion__StyledChevron",
  componentId: "sc-1cdhfot-6"
})(({
  theme
}) => ({
  color: theme.colors.icon,
  // transition: 'transform 300ms cubic-bezier(0.87, 0, 0.13, 1)',
  // 'button[data-state=closed] &': { transform: 'rotate(0)' },
  'button[data-state=open] &': {
    transform: 'rotate(180deg)'
  }
})); // Exports

const Root = (/* unused pure expression or super */ null && (StyledAccordion));
const Item = (/* unused pure expression or super */ null && (StyledItem));
const Trigger = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef((_ref, forwardedRef) => {
  let {
    children,
    showsChevron = true
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/_jsx(StyledHeader, {
    children: /*#__PURE__*/_jsxs(StyledTrigger, _objectSpread(_objectSpread({}, props), {}, {
      ref: forwardedRef,
      children: [children, showsChevron && /*#__PURE__*/_jsx(StyledChevron, {
        "aria-hidden": true
      })]
    }))
  });
})));
const Content = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef((_ref2, forwardedRef) => {
  let {
    children
  } = _ref2,
      props = _objectWithoutProperties(_ref2, _excluded2);

  return /*#__PURE__*/_jsx(StyledContent, _objectSpread(_objectSpread({}, props), {}, {
    ref: forwardedRef,
    children: /*#__PURE__*/_jsx(StyledContentText, {
      children: children
    })
  }));
})));

/***/ }),

/***/ 3901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2679);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["id", "flex", "tooltip", "active", "disabled", "variant", "onClick", "children", "as"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






/* ----------------------------------------------------------------------------
 * Element
 * ------------------------------------------------------------------------- */
const ButtonElement = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
  displayName: "Button__ButtonElement",
  componentId: "sc-vzpfj8-0"
})(({
  theme,
  active,
  disabled,
  variant,
  flex
}) => _objectSpread(_objectSpread(_objectSpread({
  WebkitAppRegion: 'no-drag'
}, theme.textStyles.small), {}, {
  flex: flex !== null && flex !== void 0 ? flex : '0 0 auto',
  position: 'relative',
  border: '0',
  outline: 'none',
  minWidth: variant === 'normal' ? '31px' : undefined,
  textAlign: 'left',
  borderRadius: '4px',
  paddingTop: variant === 'none' ? '0px' : '4px',
  paddingRight: variant === 'none' ? '0px' : variant === 'thin' ? '1px' : '6px',
  paddingBottom: variant === 'none' ? '0px' : '4px',
  paddingLeft: variant === 'none' ? '0px' : variant === 'thin' ? '1px' : '6px',
  background: active ? theme.colors.primary : variant === 'none' ? 'transparent' : theme.colors.inputBackground,
  color: active ? 'white' : theme.colors.text,
  opacity: disabled ? 0.25 : 1
}, variant === 'normal' && {
  '&:focus': {
    boxShadow: `0 0 0 1px ${theme.colors.sidebar.background}, 0 0 0 3px ${theme.colors.primary}`
  }
}), {}, {
  '&:active': {
    background: theme.colors.activeBackground
  },
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  '& *': {
    pointerEvents: 'none'
  }
}));
/* ----------------------------------------------------------------------------
 * Content
 * ------------------------------------------------------------------------- */

const ButtonContent = styled_components__WEBPACK_IMPORTED_MODULE_1___default().span.withConfig({
  displayName: "Button__ButtonContent",
  componentId: "sc-vzpfj8-1"
})(({
  theme
}) => ({
  // Line height of small text - maybe figure out better way to ensure
  // icons don't have a smaller height
  minHeight: '19px',
  display: 'flex',
  alignItems: 'center',
  flex: '1',
  justifyContent: 'center'
}));
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */

const ButtonComponent = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function Button(_ref, forwardedRef) {
  let {
    id,
    flex,
    tooltip,
    active = false,
    disabled = false,
    variant = 'normal',
    onClick,
    children,
    as // Propagate any other props so this component works as a Slot

  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const buttonElement = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(ButtonElement, _objectSpread(_objectSpread({
    as: as // Erase the node type to avoid type errors, for now. Better to propagate up if possible
    ,
    ref: forwardedRef,
    id: id,
    flex: flex,
    active: active,
    disabled: disabled,
    variant: variant,
    onClick: onClick // Prevent double clicking a button from triggering any callbacks in ancestors
    ,
    onDoubleClick: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
      event.stopPropagation();
    }, [])
  }, rest), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(ButtonContent, {
      children: children
    })
  }));

  return tooltip ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    content: tooltip,
    children: buttonElement
  }) : buttonElement;
});
const Button = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ButtonComponent);

/***/ }),

/***/ 6513:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5766);
/* harmony import */ var _radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9615);
/* harmony import */ var keymap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6682);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _internal_Menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(638);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_internal_Menu__WEBPACK_IMPORTED_MODULE_6__, keymap__WEBPACK_IMPORTED_MODULE_3__]);
([_internal_Menu__WEBPACK_IMPORTED_MODULE_6__, keymap__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







/* ----------------------------------------------------------------------------
 * Separator
 * ------------------------------------------------------------------------- */




const SeparatorElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.Separator).withConfig({
  displayName: "ContextMenu__SeparatorElement",
  componentId: "sc-sex6hj-0"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.separatorStyle */ .W2.separatorStyle);
/* ----------------------------------------------------------------------------
 * Item
 * ------------------------------------------------------------------------- */

const ItemElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.Item).withConfig({
  displayName: "ContextMenu__ItemElement",
  componentId: "sc-sex6hj-1"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemStyle */ .W2.itemStyle);
const CheckboxItemElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.CheckboxItem).withConfig({
  displayName: "ContextMenu__CheckboxItemElement",
  componentId: "sc-sex6hj-2"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemStyle */ .W2.itemStyle);
const StyledItemIndicator = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.ItemIndicator).withConfig({
  displayName: "ContextMenu__StyledItemIndicator",
  componentId: "sc-sex6hj-3"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemIndicatorStyle */ .W2.itemIndicatorStyle);
const ContextMenuItem = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(function ContextMenuItem({
  value,
  children,
  onSelect,
  checked,
  disabled,
  indented,
  icon,
  items,
  shortcut
}) {
  // The pointer event within the context menu will bubble outside of the
  // context menu unless we stop it here.
  const handlePointerDown = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(event => event.stopPropagation(), []);
  const handleSelectItem = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(() => {
    if (!value) return;
    onSelect(value);
  }, [onSelect, value]);

  if (checked) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(CheckboxItemElement, {
      checked: checked,
      disabled: disabled,
      onSelect: handleSelectItem,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledItemIndicator, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__.CheckIcon, {})
      }), children]
    });
  }

  const element = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(ItemElement, {
    disabled: disabled,
    onSelect: handleSelectItem,
    onPointerDown: handlePointerDown,
    children: [indented && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
      size: _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .CHECKBOX_WIDTH */ .Im - _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .CHECKBOX_RIGHT_INSET */ .hx
    }), icon && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [icon, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 8
      })]
    }), children, shortcut && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 24
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .KeyboardShortcut */ .eM, {
        shortcut: shortcut
      })]
    }), items && items.length > 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 16
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__.ChevronRightIcon, {})]
    })]
  });

  if (items && items.length > 0) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ContextMenuRoot, {
      isNested: true,
      items: items,
      onSelect: onSelect,
      children: element
    });
  } else {
    return element;
  }
});
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */

const RootElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.Content).withConfig({
  displayName: "ContextMenu__RootElement",
  componentId: "sc-sex6hj-4"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.contentStyle */ .W2.contentStyle);

function ContextMenuRoot({
  items,
  children,
  onSelect,
  isNested,
  shouldBindKeyboardShortcuts
}) {
  const hasCheckedItem = items.some(item => item !== _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .SEPARATOR_ITEM */ .W5 && item.checked);
  const keymap = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => isNested || shouldBindKeyboardShortcuts === false ? {} : (0,_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .getKeyboardShortcutsForMenuItems */ .Gq)(items, onSelect), [isNested, items, onSelect, shouldBindKeyboardShortcuts]);
  (0,keymap__WEBPACK_IMPORTED_MODULE_3__/* .useKeyboardShortcuts */ .aL)(keymap); // We call preventDefault both to:
  // - Disable radix-ui's long-press-to-open behavior
  //   https://github.com/radix-ui/primitives/issues/748#issuecomment-869502837
  // - Mark the event as handled, so our ListView root doesn't handle it (a hack)

  const onPointerDown = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(event => {
    event.preventDefault();
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.Root, {
    children: [isNested ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.TriggerItem, {
      asChild: true,
      onPointerDown: onPointerDown,
      children: children
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_context_menu__WEBPACK_IMPORTED_MODULE_0__.Trigger, {
      asChild: true,
      onPointerDown: onPointerDown,
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(RootElement, {
      children: items.map((item, index) => {
        var _item$value, _item$checked, _item$disabled;

        return item === _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .SEPARATOR_ITEM */ .W5 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(SeparatorElement, {}, index) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ContextMenuItem, {
          value: item.value,
          indented: hasCheckedItem,
          checked: (_item$checked = item.checked) !== null && _item$checked !== void 0 ? _item$checked : false,
          disabled: (_item$disabled = item.disabled) !== null && _item$disabled !== void 0 ? _item$disabled : false,
          icon: item.icon,
          onSelect: onSelect,
          items: item.items,
          shortcut: item.shortcut,
          children: item.title
        }, (_item$value = item.value) !== null && _item$value !== void 0 ? _item$value : index);
      })
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(ContextMenuRoot));
});

/***/ }),

/***/ 3242:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8532);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9615);
/* harmony import */ var keymap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6682);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _internal_Menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(638);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_internal_Menu__WEBPACK_IMPORTED_MODULE_6__, keymap__WEBPACK_IMPORTED_MODULE_3__]);
([_internal_Menu__WEBPACK_IMPORTED_MODULE_6__, keymap__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







/* ----------------------------------------------------------------------------
 * Separator
 * ------------------------------------------------------------------------- */




const SeparatorElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.Separator).withConfig({
  displayName: "DropdownMenu__SeparatorElement",
  componentId: "sc-a1znqc-0"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.separatorStyle */ .W2.separatorStyle);
/* ----------------------------------------------------------------------------
 * Item
 * ------------------------------------------------------------------------- */

const ItemElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.Item).withConfig({
  displayName: "DropdownMenu__ItemElement",
  componentId: "sc-a1znqc-1"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemStyle */ .W2.itemStyle);
const CheckboxItemElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.CheckboxItem).withConfig({
  displayName: "DropdownMenu__CheckboxItemElement",
  componentId: "sc-a1znqc-2"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemStyle */ .W2.itemStyle);
const StyledItemIndicator = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.ItemIndicator).withConfig({
  displayName: "DropdownMenu__StyledItemIndicator",
  componentId: "sc-a1znqc-3"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.itemIndicatorStyle */ .W2.itemIndicatorStyle);
const DropdownMenuItem = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(function ContextMenuItem({
  value,
  children,
  onSelect,
  checked,
  disabled,
  indented,
  icon,
  items,
  shortcut
}) {
  const handleSelectItem = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(() => {
    if (!value) return;
    onSelect(value);
  }, [onSelect, value]);

  if (checked) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(CheckboxItemElement, {
      checked: checked,
      disabled: disabled,
      onSelect: handleSelectItem,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledItemIndicator, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__.CheckIcon, {})
      }), children]
    });
  }

  const element = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(ItemElement, {
    disabled: disabled,
    onSelect: handleSelectItem,
    children: [indented && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
      size: _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .CHECKBOX_WIDTH */ .Im - _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .CHECKBOX_RIGHT_INSET */ .hx
    }), icon && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [icon, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 8
      })]
    }), children, shortcut && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 24
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .KeyboardShortcut */ .eM, {
        shortcut: shortcut
      })]
    }), items && items.length > 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerHorizontal */ .lC, {
        size: 16
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_1__.ChevronRightIcon, {})]
    })]
  });

  if (items && items.length > 0) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(DropdownMenuRoot, {
      isNested: true,
      items: items,
      onSelect: onSelect,
      children: element
    });
  } else {
    return element;
  }
});
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */

const RootElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.Content).withConfig({
  displayName: "DropdownMenu__RootElement",
  componentId: "sc-a1znqc-4"
})(_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .styles.contentStyle */ .W2.contentStyle);

function DropdownMenuRoot({
  items,
  children,
  onSelect,
  isNested,
  shouldBindKeyboardShortcuts
}) {
  const hasCheckedItem = items.some(item => item !== _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .SEPARATOR_ITEM */ .W5 && item.checked);
  const keymap = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => isNested || shouldBindKeyboardShortcuts === false ? {} : (0,_internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .getKeyboardShortcutsForMenuItems */ .Gq)(items, onSelect), [isNested, items, onSelect, shouldBindKeyboardShortcuts]);
  (0,keymap__WEBPACK_IMPORTED_MODULE_3__/* .useKeyboardShortcuts */ .aL)(keymap);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.Root, {
    children: [isNested ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.TriggerItem, {
      asChild: true,
      children: children
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_0__.Trigger, {
      asChild: true,
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(RootElement, {
      scrollable: true,
      sideOffset: 4,
      onCloseAutoFocus: (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(event => {
        // Prevent the trigger from being focused, which interferes with
        // keyboard shortcuts going to the canvas
        event.preventDefault(); // Workaround radix-ui issue where all pointerEvents become blocked
        // until the body is clicked again

        document.body.style.pointerEvents = '';
      }, []),
      children: items.map((item, index) => {
        var _item$value, _item$checked, _item$disabled;

        return item === _internal_Menu__WEBPACK_IMPORTED_MODULE_6__/* .SEPARATOR_ITEM */ .W5 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(SeparatorElement, {}, index) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(DropdownMenuItem, {
          value: item.value,
          indented: hasCheckedItem,
          checked: (_item$checked = item.checked) !== null && _item$checked !== void 0 ? _item$checked : false,
          disabled: (_item$disabled = item.disabled) !== null && _item$disabled !== void 0 ? _item$disabled : false,
          icon: item.icon,
          onSelect: onSelect,
          items: item.items,
          shortcut: item.shortcut,
          children: item.title
        }, (_item$value = item.value) !== null && _item$value !== void 0 ? _item$value : index);
      })
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(DropdownMenuRoot));
});

/***/ }),

/***/ 3003:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ IconButton)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3901);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
const _excluded = ["selected", "iconName", "color", "size"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const IconButton = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)( /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(function IconButton(_ref, forwardedRef) {
  let {
    selected,
    iconName,
    color,
    size
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    icon: iconColor,
    iconSelected: iconSelectedColor
  } = (0,styled_components__WEBPACK_IMPORTED_MODULE_2__.useTheme)().colors;
  const Icon = _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__[iconName];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_Button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, _objectSpread(_objectSpread({
    ref: forwardedRef
  }, props), {}, {
    variant: "none",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(Icon, _objectSpread({
      color: color !== null && color !== void 0 ? color : selected ? iconSelectedColor : iconColor
    }, size && {
      width: size,
      height: size
    }))
  }));
}));

/***/ }),

/***/ 4628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "II": () => (/* binding */ Input),
  "__": () => (/* binding */ Label),
  "Y2": () => (/* binding */ NumberInput),
  "fC": () => (/* binding */ Root)
});

// UNUSED EXPORTS: DropdownMenu, InputElement

// EXTERNAL MODULE: external "@radix-ui/react-icons"
var react_icons_ = __webpack_require__(2132);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ../designsystem/src/utils/handleNudge.ts
// Given a KeyboardEvent, returns the nudge amount
function handleNudge(e) {
  let handled = false;
  let amount = 0;

  switch (e.key) {
    case 'ArrowUp':
      amount = 1;
      handled = true;
      break;

    case 'ArrowDown':
      amount = -1;
      handled = true;
      break;
  }

  if (!handled) return;

  if (e.shiftKey) {
    amount *= 10;
  } else if (e.altKey) {// amount *= 0.1;
  }

  return handled ? amount : undefined;
}
// EXTERNAL MODULE: ../designsystem/src/components/Button.tsx
var Button = __webpack_require__(3901);
// EXTERNAL MODULE: external "@radix-ui/react-compose-refs"
var react_compose_refs_ = __webpack_require__(5344);
;// CONCATENATED MODULE: ../designsystem/src/contexts/GlobalInputBlurContext.tsx


const defaultValue = (() => {
  const listeners = [];
  const value = {
    addListener(f) {
      listeners.push(f);
    },

    removeListener(f) {
      const index = listeners.indexOf(f);
      if (index === -1) return;
      listeners.splice(index, 1);
    },

    trigger() {
      listeners.forEach(f => {
        f();
      });
    }

  };
  return value;
})();

const GlobalInputBlurContext = /*#__PURE__*/(0,external_react_.createContext)(defaultValue);
const GlobalInputBlurProvider = GlobalInputBlurContext.Provider;
/**
 * Some components store their editable state internally.
 * We trigger this event before selection changes so that they can commit their
 * edits before they unmount. This is more manual but simpler than doing so during
 * the unmount phase (e.g. the return function of `useEffect`), since handlers are
 * guaranteed to be called with the current data.
 */

const useGlobalInputBlur = () => {
  return (0,external_react_.useContext)(GlobalInputBlurContext);
};
function useGlobalInputBlurListener(f) {
  const context = useGlobalInputBlur();
  (0,external_react_.useEffect)(() => {
    context.addListener(f);
    return () => {
      context.removeListener(f);
    };
  }, [context, f]);
}
function useGlobalInputBlurTrigger() {
  return useGlobalInputBlur().trigger;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ../designsystem/src/components/internal/TextInput.tsx
const _excluded = ["onKeyDown", "value", "onChange"],
      _excluded2 = ["onKeyDown", "value", "onSubmit", "onChangeInternalValue", "onBlur", "allowSubmittingWithSameValue"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const ControlledTextInput = /*#__PURE__*/(0,external_react_.forwardRef)(function ControlledTextInput(_ref, forwardedRef) {
  let {
    onKeyDown,
    value,
    onChange
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread(_objectSpread({
    ref: forwardedRef
  }, rest), {}, {
    value: value,
    onKeyDown: onKeyDown,
    onChange: (0,external_react_.useCallback)(event => onChange(event.target.value), [onChange])
  }));
});
const SubmittableTextInput = /*#__PURE__*/(0,external_react_.forwardRef)(function SubmittableTextInput(_ref2, forwardedRef) {
  let {
    onKeyDown,
    value,
    onSubmit,
    onChangeInternalValue,
    onBlur,
    allowSubmittingWithSameValue = false
  } = _ref2,
      rest = _objectWithoutProperties(_ref2, _excluded2);

  const ref = external_react_default().useRef(null);
  const latestValue = (0,external_react_.useRef)(value);
  latestValue.current = value;
  const isSubmitTriggeredByEscapeKey = (0,external_react_.useRef)(false);
  const {
    0: internalValue,
    1: _setInternalValue
  } = (0,external_react_.useState)('');
  const setInternalValue = (0,external_react_.useCallback)(internalValue => {
    _setInternalValue(internalValue);

    onChangeInternalValue === null || onChangeInternalValue === void 0 ? void 0 : onChangeInternalValue(internalValue);
  }, [onChangeInternalValue]);
  (0,external_react_.useEffect)(() => {
    setInternalValue(value);
  }, [setInternalValue, value]);
  const handleSubmit = (0,external_react_.useCallback)(() => {
    // If this submission was triggered with Escape, we attempt to submit the original value.
    // This will only actually call `onSubmit` if `allowSubmittingWithSameValue` is also true.
    const submissionValue = isSubmitTriggeredByEscapeKey.current ? value : internalValue;
    isSubmitTriggeredByEscapeKey.current = false;
    if (submissionValue === value && !allowSubmittingWithSameValue) return;
    onSubmit(submissionValue);
    setInternalValue(latestValue.current);
  }, [value, internalValue, allowSubmittingWithSameValue, onSubmit, setInternalValue]);
  useGlobalInputBlurListener((0,external_react_.useCallback)(() => {
    if (ref.current !== document.activeElement) return;
    handleSubmit();
  }, [handleSubmit]));
  const handleKeyDown = (0,external_react_.useCallback)(event => {
    if (event.key === 'Enter') {
      handleSubmit();
      event.preventDefault();
      event.stopPropagation();
    } else if (event.key === 'Escape') {
      var _ref$current;

      isSubmitTriggeredByEscapeKey.current = true;
      (_ref$current = ref.current) === null || _ref$current === void 0 ? void 0 : _ref$current.blur();
    } else {
      onKeyDown === null || onKeyDown === void 0 ? void 0 : onKeyDown(event);
    }
  }, [onKeyDown, handleSubmit]);
  const handleChange = (0,external_react_.useCallback)(event => {
    setInternalValue(event.target.value);
  }, [setInternalValue]);
  return /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread(_objectSpread({
    ref: (0,react_compose_refs_.composeRefs)(ref, forwardedRef)
  }, rest), {}, {
    value: internalValue,
    onKeyDown: handleKeyDown,
    onChange: handleChange,
    onBlur: (0,external_react_.useCallback)(() => {
      handleSubmit();
      onBlur === null || onBlur === void 0 ? void 0 : onBlur();
    }, [handleSubmit, onBlur])
  }));
});

/**
 * This component shouldn't be used directly. Instead use the InputField components.
 */
/* harmony default export */ const TextInput = (/*#__PURE__*/(0,external_react_.forwardRef)(function TextInput(props, forwardedRef) {
  const commonProps = _objectSpread({
    onPointerDown: (0,external_react_.useCallback)(event => event.stopPropagation(), []),
    onClick: (0,external_react_.useCallback)(event => event.stopPropagation(), []),
    autoComplete: 'off',
    autoCapitalize: 'off',
    autoCorrect: 'off',
    spellCheck: false,
    type: 'text',
    disabled: false
  }, props);

  if ('onChange' in commonProps) {
    return /*#__PURE__*/jsx_runtime_.jsx(ControlledTextInput, _objectSpread({
      ref: forwardedRef
    }, commonProps));
  } else {
    return /*#__PURE__*/jsx_runtime_.jsx(SubmittableTextInput, _objectSpread({
      ref: forwardedRef
    }, commonProps));
  }
}));
;// CONCATENATED MODULE: ../designsystem/src/components/InputField.tsx
function InputField_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function InputField_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { InputField_ownKeys(Object(source), true).forEach(function (key) { InputField_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { InputField_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function InputField_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // import { DropdownMenu as NoyaDropdownMenu, MenuItem } from "noya-designsystem";







const InputFieldContext = /*#__PURE__*/(0,external_react_.createContext)({
  labelPosition: 'end',
  labelSize: 6,
  hasLabel: false,
  hasDropdown: false
});
/* ----------------------------------------------------------------------------
 * Label
 * ------------------------------------------------------------------------- */

const LabelContainer = external_styled_components_default().label.withConfig({
  displayName: "InputField__LabelContainer",
  componentId: "sc-xaqxaw-0"
})(({
  theme,
  labelPosition,
  hasDropdown
}) => InputField_objectSpread({
  color: theme.colors.textMuted,
  position: 'absolute',
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
  display: 'flex',
  alignItems: 'center',
  pointerEvents: 'none',
  fontWeight: 'bold',
  fontSize: '0.8rem',
  opacity: 0.5,
  userSelect: 'none'
}, labelPosition === 'start' ? {
  justifyContent: 'flex-start',
  paddingLeft: '6px'
} : {
  justifyContent: 'flex-end',
  paddingRight: hasDropdown ? '16px' : '6px'
}));

function InputFieldLabel({
  children = false
}) {
  const {
    labelPosition,
    hasDropdown
  } = (0,external_react_.useContext)(InputFieldContext);
  return /*#__PURE__*/jsx_runtime_.jsx(LabelContainer, {
    labelPosition: labelPosition,
    hasDropdown: hasDropdown,
    children: children
  });
}
/* ----------------------------------------------------------------------------
 * Dropdown
 * ------------------------------------------------------------------------- */


const DropdownContainer = external_styled_components_default().span.withConfig({
  displayName: "InputField__DropdownContainer",
  componentId: "sc-xaqxaw-1"
})(({
  theme
}) => ({
  position: 'absolute',
  right: 0
}));

function InputFieldDropdownMenu({
  id,
  // items,
  onSelect
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(DropdownContainer, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Button/* Button */.z, {
      id: id,
      variant: "thin",
      children: /*#__PURE__*/jsx_runtime_.jsx(react_icons_.CaretDownIcon, {})
    })
  });
}
/* ----------------------------------------------------------------------------
 * Input
 * ------------------------------------------------------------------------- */


const createCrossSVGString = color => `<svg width='15' height='15' viewBox='0 0 15 15' fill='${color}' xmlns='http://www.w3.org/2000/svg'>
      <path d='M0.877075 7.49988C0.877075 3.84219 3.84222 0.877045 7.49991 0.877045C11.1576 0.877045 14.1227 3.84219 14.1227 7.49988C14.1227 11.1575 11.1576 14.1227 7.49991 14.1227C3.84222 14.1227 0.877075 11.1575 0.877075 7.49988ZM7.49991 1.82704C4.36689 1.82704 1.82708 4.36686 1.82708 7.49988C1.82708 10.6329 4.36689 13.1727 7.49991 13.1727C10.6329 13.1727 13.1727 10.6329 13.1727 7.49988C13.1727 4.36686 10.6329 1.82704 7.49991 1.82704ZM9.85358 5.14644C10.0488 5.3417 10.0488 5.65829 9.85358 5.85355L8.20713 7.49999L9.85358 9.14644C10.0488 9.3417 10.0488 9.65829 9.85358 9.85355C9.65832 10.0488 9.34173 10.0488 9.14647 9.85355L7.50002 8.2071L5.85358 9.85355C5.65832 10.0488 5.34173 10.0488 5.14647 9.85355C4.95121 9.65829 4.95121 9.3417 5.14647 9.14644L6.79292 7.49999L5.14647 5.85355C4.95121 5.65829 4.95121 5.3417 5.14647 5.14644C5.34173 4.95118 5.65832 4.95118 5.85358 5.14644L7.50002 6.79289L9.14647 5.14644C9.34173 4.95118 9.65832 4.95118 9.85358 5.14644Z' fill-rule='evenodd' clip-rule='evenodd'></path>
    </svg>`;

const ignoredProps = new Set(['labelPosition', 'labelSize', 'hasLabel', 'hasDropdown', 'textAlign', 'variant', 'onNudge']);
const InputElement = external_styled_components_default()(TextInput).withConfig({
  shouldForwardProp: prop => ignoredProps.has(prop) ? false : true,
  displayName: "InputField__InputElement",
  componentId: "sc-xaqxaw-2"
})(({
  theme,
  labelPosition,
  labelSize,
  hasDropdown,
  textAlign,
  disabled,
  hasLabel,
  variant = 'normal'
}) => InputField_objectSpread(InputField_objectSpread(InputField_objectSpread({}, theme.textStyles.small), {}, {
  color: disabled ? theme.colors.textDisabled : theme.colors.text,
  width: '0px',
  // Reset intrinsic width
  flex: '1 1 0px',
  position: 'relative',
  border: '0',
  outline: 'none',
  minWidth: '0',
  textAlign: textAlign !== null && textAlign !== void 0 ? textAlign : 'left',
  alignSelf: 'stretch',
  borderRadius: '4px',
  paddingTop: '4px',
  paddingBottom: '4px',
  paddingLeft: 6 + (hasLabel && labelPosition === 'start' ? 6 + labelSize : 0) + 'px',
  paddingRight: 6 + (hasLabel && labelPosition === 'end' ? 6 + labelSize : 0) + (hasDropdown ? 11 : 0) + 'px',
  background: disabled ? '#282828' : theme.colors.inputBackground,
  '&:focus': {
    boxShadow: `0 0 0 2px ${theme.colors.primary}`
  }
}, variant === 'bare' && {
  paddingTop: 0,
  paddingRight: 0,
  paddingBottom: 0,
  paddingLeft: 0
}), {}, {
  '&[type="search"]::-webkit-search-cancel-button': {
    appearance: 'none',
    height: '15px',
    width: '15px',
    background: `url("data:image/svg+xml;utf8,${createCrossSVGString(theme.colors.icon)}") no-repeat`
  }
}));
const InputFieldInput = /*#__PURE__*/(0,external_react_.forwardRef)(function InputFieldInput(props, forwardedRef) {
  const {
    labelPosition,
    labelSize,
    hasDropdown,
    hasLabel
  } = (0,external_react_.useContext)(InputFieldContext);
  return /*#__PURE__*/jsx_runtime_.jsx(InputElement, InputField_objectSpread({
    ref: forwardedRef,
    labelPosition: labelPosition,
    labelSize: labelSize,
    hasLabel: hasLabel,
    hasDropdown: hasDropdown
  }, props));
});
/* ----------------------------------------------------------------------------
 * NumberInput
 * ------------------------------------------------------------------------- */

function parseNumber(value) {
  return value ? Number(value) : NaN;
}

function InputFieldNumberInput(props) {
  const {
    value,
    placeholder,
    onNudge
  } = props;
  const onSubmit = 'onSubmit' in props ? props.onSubmit : undefined;
  const onChange = 'onChange' in props ? props.onChange : undefined;
  const handleSubmit = (0,external_react_.useCallback)(value => {
    const newValue = parseNumber(value);

    if (!isNaN(newValue)) {
      onSubmit === null || onSubmit === void 0 ? void 0 : onSubmit(newValue);
    }
  }, [onSubmit]);
  const handleKeyDown = (0,external_react_.useCallback)(event => {
    const amount = handleNudge(event);
    if (!amount) return;
    onNudge === null || onNudge === void 0 ? void 0 : onNudge(amount);
    event.preventDefault();
    event.stopPropagation();
  }, [onNudge]);
  const handleChange = (0,external_react_.useCallback)(value => {
    onChange === null || onChange === void 0 ? void 0 : onChange(parseNumber(value));
  }, [onChange]);
  return /*#__PURE__*/jsx_runtime_.jsx(InputFieldInput, InputField_objectSpread(InputField_objectSpread({}, props), {}, {
    value: value === undefined ? '' : String(value),
    placeholder: placeholder,
    onKeyDown: handleKeyDown
  }, 'onChange' in props ? {
    onChange: handleChange
  } : {
    onSubmit: handleSubmit
  }));
}
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */


const RootContainer = external_styled_components_default().div.withConfig({
  displayName: "InputField__RootContainer",
  componentId: "sc-xaqxaw-3"
})(({
  theme,
  flex,
  size
}) => ({
  flex: flex !== null && flex !== void 0 ? flex : '1',
  display: 'flex',
  flexDirection: 'row',
  position: 'relative',
  maxWidth: typeof size === 'number' ? `${size}px` : undefined
}));

function InputFieldRoot({
  id,
  flex,
  children,
  size,
  labelPosition = 'end',
  labelSize = 6
}) {
  const childrenArray = external_react_.Children.toArray(children);
  const hasDropdown = childrenArray.some(child => /*#__PURE__*/(0,external_react_.isValidElement)(child) && child.type === DropdownMenu);
  const hasLabel = childrenArray.some(child => /*#__PURE__*/(0,external_react_.isValidElement)(child) && child.type === Label);
  const contextValue = (0,external_react_.useMemo)(() => ({
    labelPosition,
    labelSize,
    hasDropdown,
    hasLabel
  }), [labelPosition, labelSize, hasDropdown, hasLabel]);
  return /*#__PURE__*/jsx_runtime_.jsx(InputFieldContext.Provider, {
    value: contextValue,
    children: /*#__PURE__*/jsx_runtime_.jsx(RootContainer, {
      id: id,
      size: size,
      flex: flex,
      children: children
    })
  });
}

const Input = /*#__PURE__*/(0,external_react_.memo)(InputFieldInput);
const NumberInput = /*#__PURE__*/(0,external_react_.memo)(InputFieldNumberInput);
const Label = /*#__PURE__*/(0,external_react_.memo)(InputFieldLabel);
const DropdownMenu = /*#__PURE__*/(0,external_react_.memo)(InputFieldDropdownMenu);
const Root = /*#__PURE__*/(0,external_react_.memo)(InputFieldRoot);

/***/ }),

/***/ 2166:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lV": () => (/* binding */ ListRowContext),
/* harmony export */   "$5": () => (/* binding */ DragIndicatorElement),
/* harmony export */   "Wh": () => (/* binding */ RowTitle),
/* harmony export */   "Z8": () => (/* binding */ EditableRowTitle),
/* harmony export */   "X2": () => (/* binding */ Row),
/* harmony export */   "fC": () => (/* binding */ Root)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_compose_refs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5344);
/* harmony import */ var _radix_ui_react_compose_refs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_compose_refs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6221);
/* harmony import */ var react_virtualized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6325);
/* harmony import */ var react_virtualized__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_virtualized__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(551);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1801);
/* harmony import */ var _hooks_useHover__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3798);
/* harmony import */ var _hooks_mergeEventHandlers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1712);
/* harmony import */ var _ContextMenu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6513);
/* harmony import */ var _ScrollArea__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7276);
/* harmony import */ var _Sortable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4025);
/* harmony import */ var _utils_mouseEvent__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6966);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9615);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ContextMenu__WEBPACK_IMPORTED_MODULE_9__, ___WEBPACK_IMPORTED_MODULE_6__]);
([_ContextMenu__WEBPACK_IMPORTED_MODULE_9__, ___WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
const _excluded = ["relativeDropPosition"],
      _excluded2 = ["ref"],
      _excluded3 = ["children"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


















const ListRowContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
  marginType: 'none',
  selectedPosition: 'only',
  sortable: false,
  expandable: true,
  indentation: 12,
  pressEventName: 'onClick'
});
/* ----------------------------------------------------------------------------
 * RowTitle
 * ------------------------------------------------------------------------- */

const ListViewRowTitle = styled_components__WEBPACK_IMPORTED_MODULE_5___default().span.withConfig({
  displayName: "ListView__ListViewRowTitle",
  componentId: "sc-1rrm56o-0"
})(({
  theme
}) => ({
  flex: '1 1 0',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'pre'
}));
/* ----------------------------------------------------------------------------
 * EditableRowTitle
 * ------------------------------------------------------------------------- */

function ListViewEditableRowTitle({
  value,
  onSubmitEditing,
  autoFocus
}) {
  const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const element = inputRef.current;
    if (!element || !autoFocus) return; // Calling `focus` is necessary, in addition to `select`, to ensure
    // the `onBlur` fires correctly.

    element.focus();
    setTimeout(() => {
      element.select();
    }, 0);
  }, [autoFocus]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(___WEBPACK_IMPORTED_MODULE_6__/* .InputField.Input */ .UP.II, {
    ref: inputRef,
    variant: "bare",
    value: value,
    onSubmit: onSubmitEditing,
    allowSubmittingWithSameValue: true
  });
}

function getPositionMargin(marginType) {
  return {
    top: marginType === 'top' || marginType === 'vertical' ? 8 : 0,
    bottom: marginType === 'bottom' || marginType === 'vertical' ? 8 : 0
  };
}
/* ----------------------------------------------------------------------------
 * Row
 * ------------------------------------------------------------------------- */


const RowContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ListView__RowContainer",
  componentId: "sc-1rrm56o-1"
})(({
  theme,
  marginType,
  selected,
  selectedPosition,
  disabled,
  hovered,
  isSectionHeader,
  showsActiveState
}) => {
  const margin = getPositionMargin(marginType);
  return _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, theme.textStyles.small), isSectionHeader && {
    fontWeight: 500
  }), {}, {
    flex: '0 0 auto',
    userSelect: 'none',
    cursor: 'default',
    borderRadius: '4px',
    paddingTop: '6px',
    paddingRight: '12px',
    paddingBottom: '6px',
    paddingLeft: '12px',
    marginLeft: '8px',
    marginRight: '8px',
    marginTop: `${margin.top}px`,
    marginBottom: `${margin.bottom}px`,
    color: theme.colors.textMuted
  }, isSectionHeader && {
    backgroundColor: theme.colors.listView.raisedBackground
  }), disabled && {
    color: theme.colors.textDisabled
  }), selected && {
    color: 'white',
    backgroundColor: theme.colors.primary
  }), {}, {
    display: 'flex',
    alignItems: 'center'
  }, selected && !isSectionHeader && (selectedPosition === 'middle' || selectedPosition === 'last') && {
    borderTopRightRadius: '0px',
    borderTopLeftRadius: '0px'
  }), selected && !isSectionHeader && (selectedPosition === 'middle' || selectedPosition === 'first') && {
    borderBottomRightRadius: '0px',
    borderBottomLeftRadius: '0px'
  }), {}, {
    position: 'relative'
  }, hovered && {
    boxShadow: `0 0 0 1px ${theme.colors.primary}`
  }), showsActiveState && {
    '&:active': {
      backgroundColor: selected ? theme.colors.primaryLight : theme.colors.activeBackground
    }
  });
});
const DragIndicatorElement = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ListView__DragIndicatorElement",
  componentId: "sc-1rrm56o-2"
})(({
  theme,
  relativeDropPosition,
  offsetLeft
}) => _objectSpread({
  zIndex: 1,
  position: 'absolute',
  borderRadius: '3px'
}, relativeDropPosition === 'inside' ? {
  inset: 2,
  boxShadow: `0 0 0 1px ${theme.colors.sidebar.background}, 0 0 0 3px ${theme.colors.dragOutline}`
} : {
  top: relativeDropPosition === 'above' ? -3 : undefined,
  bottom: relativeDropPosition === 'below' ? -3 : undefined,
  left: offsetLeft,
  right: 0,
  height: 6,
  background: theme.colors.primary,
  border: `2px solid white`,
  boxShadow: '0 0 2px rgba(0,0,0,0.5)'
}));
const ListViewRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function ListViewRow({
  id,
  selected = false,
  depth = 0,
  disabled = false,
  hovered = false,
  isSectionHeader = false,
  sortable: overrideSortable,
  onPress,
  onDoubleClick,
  onHoverChange,
  children,
  menuItems,
  onContextMenu,
  onSelectMenuItem
}, forwardedRef) {
  const {
    marginType,
    selectedPosition,
    sortable,
    indentation,
    pressEventName
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ListRowContext);
  const {
    hoverProps
  } = (0,_hooks_useHover__WEBPACK_IMPORTED_MODULE_7__/* .useHover */ .X)({
    onHoverChange
  });
  const handlePress = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    // We use preventDefault as a hack to mark this event as handled. We check for
    // this in the ListView.Root. We can't stopPropagation here or existing ContextMenus
    // won't close (onPointerDownOutside won't fire).
    event.preventDefault();
    if (!(0,_utils_mouseEvent__WEBPACK_IMPORTED_MODULE_14__/* .isLeftButtonClicked */ .n)(event)) return;
    onPress === null || onPress === void 0 ? void 0 : onPress(event);
  }, [onPress]);
  const handleDoubleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    event.stopPropagation();
    onDoubleClick === null || onDoubleClick === void 0 ? void 0 : onDoubleClick();
  }, [onDoubleClick]);

  const renderContent = (_ref, ref) => {
    let {
      relativeDropPosition
    } = _ref,
        renderProps = _objectWithoutProperties(_ref, _excluded);

    const element = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(RowContainer, _objectSpread(_objectSpread(_objectSpread(_objectSpread({
      ref: ref,
      onContextMenu: onContextMenu,
      isSectionHeader: isSectionHeader,
      id: id
    }, hoverProps), {}, {
      onDoubleClick: handleDoubleClick,
      marginType: marginType,
      disabled: disabled,
      hovered: hovered,
      selected: selected,
      selectedPosition: selectedPosition,
      showsActiveState: pressEventName === 'onClick',
      "aria-selected": selected
    }, renderProps), (0,_hooks_mergeEventHandlers__WEBPACK_IMPORTED_MODULE_8__/* .mergeEventHandlers */ .B)({
      onPointerDown: renderProps.onPointerDown
    }, {
      [pressEventName]: handlePress
    })), {}, {
      children: [relativeDropPosition && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(DragIndicatorElement, {
        relativeDropPosition: relativeDropPosition,
        offsetLeft: 33 + depth * indentation
      }), depth > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components__WEBPACK_IMPORTED_MODULE_12__/* .SpacerHorizontal */ .lC, {
        size: depth * indentation
      }), children]
    }));

    if (menuItems && onSelectMenuItem) {
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_ContextMenu__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        items: menuItems,
        onSelect: onSelectMenuItem,
        children: element
      });
    }

    return element;
  };

  if (sortable && id) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Sortable__WEBPACK_IMPORTED_MODULE_11__/* .Item */ .c, {
      id: id,
      disabled: overrideSortable === false,
      children: _ref2 => {
        let {
          ref: sortableRef
        } = _ref2,
            sortableProps = _objectWithoutProperties(_ref2, _excluded2);

        return renderContent(sortableProps, (0,_radix_ui_react_compose_refs__WEBPACK_IMPORTED_MODULE_1__.composeRefs)(sortableRef, forwardedRef));
      }
    });
  }

  return renderContent({}, forwardedRef);
});
/* ----------------------------------------------------------------------------
 * VirtualizedListRow
 * ------------------------------------------------------------------------- */

const RenderItemContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(() => null);
const VirtualizedListRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function VirtualizedListRow({
  index,
  style
}) {
  const renderItem = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(RenderItemContext);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
    style: style,
    children: renderItem(index)
  }, index);
});
/* ----------------------------------------------------------------------------
 * VirtualizedList
 * ------------------------------------------------------------------------- */

const VirtualizedListInner = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function VirtualizedListInner({
  size,
  scrollElement,
  items,
  getItemHeight,
  keyExtractor,
  renderItem
}, ref) {
  const listRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(ref, () => ({
    scrollToIndex(index) {
      var _listRef$current;

      (_listRef$current = listRef.current) === null || _listRef$current === void 0 ? void 0 : _listRef$current.scrollToItem(index);
    }

  }));
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    var _listRef$current2;

    (_listRef$current2 = listRef.current) === null || _listRef$current2 === void 0 ? void 0 : _listRef$current2.resetAfterIndex(0);
  }, [// When items change, we need to re-render the virtualized list,
  // since it doesn't currently support row height changes
  items]); // Internally, react-virtualized updates these properties. We always want
  // to use our custom scroll element, so we override them. It may update
  // overflowX/Y individually in addition to `overflow`, so we include all 3.

  const listStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    overflowX: 'initial',
    overflowY: 'initial',
    overflow: 'initial'
  }), []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(RenderItemContext.Provider, {
    value: renderItem,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(react_virtualized__WEBPACK_IMPORTED_MODULE_3__.WindowScroller, {
      scrollElement: scrollElement,
      style: (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
        flex: '1 1 auto'
      }), []),
      children: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(({
        registerChild,
        onChildScroll,
        scrollTop
      }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
        ref: registerChild,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(react_window__WEBPACK_IMPORTED_MODULE_4__.VariableSizeList, {
          ref: listRef // The list won't update on scroll unless we force it to by changing key
          ,
          style: listStyle,
          itemKey: keyExtractor,
          onScroll: ({
            scrollOffset
          }) => {
            onChildScroll({
              scrollTop: scrollOffset
            });
          },
          initialScrollOffset: scrollTop,
          width: size.width,
          height: size.height,
          itemCount: items.length,
          itemSize: getItemHeight,
          estimatedItemSize: 31,
          children: VirtualizedListRow
        }, scrollTop)
      }), [listStyle, keyExtractor, size.width, size.height, items.length, getItemHeight])
    })
  });
});
const VirtualizedList = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(VirtualizedListInner);
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */

const RootContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ListView__RootContainer",
  componentId: "sc-1rrm56o-3"
})(({
  theme,
  scrollable
}) => ({
  flex: scrollable ? '1 0 0' : '0 0 auto',
  display: 'flex',
  flexDirection: 'column',
  flexWrap: 'nowrap',
  color: theme.colors.textMuted
}));
const ListViewRootInner = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function ListViewRootInner({
  onPress,
  scrollable = false,
  expandable = true,
  sortable = false,
  onMoveItem,
  indentation = 12,
  acceptsDrop,
  data,
  renderItem,
  keyExtractor,
  virtualized,
  pressEventName = 'onClick'
}, forwardedRef) {
  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
    if (event.target instanceof HTMLElement && event.target.classList.contains('scroll-component')) return; // As a hack, we call preventDefault in a row if the event was handled.
    // If the event wasn't handled already, we call onPress here.

    if (!event.isDefaultPrevented()) {
      onPress === null || onPress === void 0 ? void 0 : onPress();
    }
  }, [onPress]);
  const renderChild = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(index => renderItem(data[index], index, {
    isDragging: false
  }), [data, renderItem]);
  const renderOverlay = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(index => renderItem(data[index], index, {
    isDragging: true
  }), [renderItem, data]);
  const getItemContextValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(i => {
    const current = renderChild(i);
    if (! /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(current)) return;
    const prevChild = i - 1 >= 0 && renderChild(i - 1);
    const nextChild = i + 1 < data.length && renderChild(i + 1);
    const next = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(nextChild) ? nextChild : undefined;
    const prev = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(prevChild) ? prevChild : undefined;
    const hasMarginTop = !prev;
    const hasMarginBottom = !next || current.props.isSectionHeader || next && next.props.isSectionHeader;
    let marginType;

    if (hasMarginTop && hasMarginBottom) {
      marginType = 'vertical';
    } else if (hasMarginBottom) {
      marginType = 'bottom';
    } else if (hasMarginTop) {
      marginType = 'top';
    } else {
      marginType = 'none';
    }

    let selectedPosition = 'only';

    if (current.props.selected) {
      const nextSelected = next && !next.props.isSectionHeader && next.props.selected;
      const prevSelected = prev && !prev.props.isSectionHeader && prev.props.selected;

      if (nextSelected && prevSelected) {
        selectedPosition = 'middle';
      } else if (nextSelected && !prevSelected) {
        selectedPosition = 'first';
      } else if (!nextSelected && prevSelected) {
        selectedPosition = 'last';
      }
    }

    return {
      marginType,
      selectedPosition,
      sortable,
      expandable,
      indentation,
      pressEventName
    };
  }, [renderChild, data.length, sortable, expandable, indentation, pressEventName]);
  const renderWrappedChild = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(index => {
    const contextValue = getItemContextValue(index);
    const current = renderChild(index);
    if (!contextValue || ! /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(current)) return null;
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ListRowContext.Provider, {
      value: contextValue,
      children: current
    }, current.key);
  }, [getItemContextValue, renderChild]);
  const ids = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => data.map(keyExtractor), [keyExtractor, data]);

  const withSortable = children => sortable ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Sortable__WEBPACK_IMPORTED_MODULE_11__/* .Root */ .f, {
    onMoveItem: onMoveItem,
    keys: ids,
    renderOverlay: renderOverlay,
    acceptsDrop: acceptsDrop,
    children: children
  }) : children;

  const withScrollable = children => scrollable ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_ScrollArea__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
    children: children
  }) : children(null);

  const getItemHeight = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(index => {
    const child = getItemContextValue(index);
    const margin = child !== null && child !== void 0 && child.marginType ? getPositionMargin(child.marginType) : {
      top: 0,
      bottom: 0
    };
    const height = margin.top + 31 + margin.bottom;
    return height;
  }, [getItemContextValue]);
  const getKey = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(index => keyExtractor(data[index], index), [data, keyExtractor]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(RootContainer, {
    [pressEventName]: handleClick,
    scrollable: scrollable,
    children: withScrollable(scrollElementRef => withSortable(virtualized ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(VirtualizedList, {
      ref: forwardedRef,
      scrollElement: scrollElementRef,
      items: data,
      size: virtualized,
      getItemHeight: getItemHeight,
      keyExtractor: getKey,
      renderItem: renderWrappedChild
    }) : (0,utils__WEBPACK_IMPORTED_MODULE_2__.range)(0, data.length).map(renderWrappedChild)))
  });
});
const ListViewRoot = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ListViewRootInner);
const ChildrenListViewInner = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function ChildrenListViewInner(_ref3, forwardedRef) {
  let {
    children
  } = _ref3,
      rest = _objectWithoutProperties(_ref3, _excluded3);

  const items = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => react__WEBPACK_IMPORTED_MODULE_0__.Children.toArray(children).flatMap(child => /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(child) ? [child] : []), [children]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ListViewRoot, _objectSpread(_objectSpread({
    ref: forwardedRef
  }, rest), {}, {
    data: items,
    keyExtractor: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(({
      key
    }, index) => typeof key === 'string' ? key : (key !== null && key !== void 0 ? key : index).toString(), []),
    renderItem: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(item => item, [])
  }));
});
const ChildrenListView = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ChildrenListViewInner);
const SimpleListViewInner = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function SimpleListView(props, forwardedRef) {
  if ('children' in props) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ChildrenListView, _objectSpread({
      ref: forwardedRef
    }, props));
  } else {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ListViewRoot, _objectSpread({
      ref: forwardedRef
    }, props));
  }
});
/**
 * A ListView can be created either with `children` or render props
 */

const SimpleListView = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(SimpleListViewInner);
const RowTitle = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ListViewRowTitle);
const EditableRowTitle = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ListViewEditableRowTitle);
const Row = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(ListViewRow);
const Root = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(SimpleListView);
});

/***/ }),

/***/ 8350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ Popover)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8456);
/* harmony import */ var _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const Content = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0__.Content).withConfig({
  displayName: "Popover__Content",
  componentId: "sc-ol64qp-0"
})(({
  theme,
  width = '240px'
}) => ({
  width,
  borderRadius: 4,
  fontSize: 14,
  backgroundColor: theme.colors.popover.background,
  boxShadow: '0 2px 4px rgba(0,0,0,0.2), 0 0 12px rgba(0,0,0,0.1)',
  maxHeight: '600px',
  overflow: 'hidden',
  color: theme.colors.textMuted
}));
function Popover({
  width,
  trigger,
  children
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0__.Root, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_0__.Trigger, {
      asChild: true,
      children: trigger
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Content, {
      side: "bottom",
      align: "center",
      width: width,
      children: children
    })]
  });
}

/***/ }),

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ Progress)
/* harmony export */ });
/* harmony import */ var _radix_ui_react_progress__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8375);
/* harmony import */ var _radix_ui_react_progress__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_progress__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);




const StyledProgress = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_progress__WEBPACK_IMPORTED_MODULE_0__.Root).withConfig({
  displayName: "Progress__StyledProgress",
  componentId: "sc-1pwkkm5-0"
})(({
  theme
}) => ({
  position: 'relative',
  overflow: 'hidden',
  background: theme.colors.inputBackground,
  borderRadius: '4px',
  height: 24
}));
const StyledIndicator = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_progress__WEBPACK_IMPORTED_MODULE_0__.Indicator).withConfig({
  displayName: "Progress__StyledIndicator",
  componentId: "sc-1pwkkm5-1"
})(({
  theme
}) => ({
  backgroundColor: theme.colors.primary,
  height: '100%',
  transition: 'width 50ms cubic-bezier(0.65, 0, 0.35, 1)'
}));
const Progress = ({
  value
}) => {
  const percent = Math.round(value * 100);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledProgress, {
    value: percent,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledIndicator, {
      style: {
        width: `${percent}%`
      }
    })
  });
};

/***/ }),

/***/ 7276:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ScrollArea)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5213);
/* harmony import */ var _radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const SCROLLBAR_SIZE = 10;
const StyledScrollArea = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__.Root).withConfig({
  displayName: "ScrollArea__StyledScrollArea",
  componentId: "sc-udj7ss-0"
})({
  width: '100%',
  height: '100%'
});
const StyledViewport = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__.Viewport).withConfig({
  displayName: "ScrollArea__StyledViewport",
  componentId: "sc-udj7ss-1"
})({
  width: '100%',
  height: '100%',
  // Override the `display: table` in the child, since this allows
  // elements to expand beyond the width of the viewport.
  '& > div': {
    display: 'block !important'
  }
});
const StyledScrollbar = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__.Scrollbar).withConfig({
  displayName: "ScrollArea__StyledScrollbar",
  componentId: "sc-udj7ss-2"
})({
  display: 'flex',
  padding: '3px',
  '&[data-orientation="vertical"]': {
    width: SCROLLBAR_SIZE
  }
});
const StyledThumb = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_scroll_area__WEBPACK_IMPORTED_MODULE_1__.Thumb).withConfig({
  displayName: "ScrollArea__StyledThumb",
  componentId: "sc-udj7ss-3"
})(({
  theme
}) => ({
  flex: 1,
  borderRadius: SCROLLBAR_SIZE,
  backgroundColor: theme.colors.scrollbar
}));
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ScrollArea__Container",
  componentId: "sc-udj7ss-4"
})({
  flex: '1 1 0px',
  minHeight: 0
});
function ScrollArea({
  children
}) {
  const {
    0: scrollElementRef,
    1: setScrollElementRef
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(StyledScrollArea, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledViewport, {
        ref: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(ref => setScrollElementRef(ref), []),
        children: typeof children === 'function' ? scrollElementRef ? children(scrollElementRef) : null : children
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledScrollbar, {
        orientation: "vertical",
        className: "scroll-component",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledThumb, {
          className: "scroll-component"
        })
      })]
    })
  });
}

/***/ }),

/***/ 924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ Select)
/* harmony export */ });
/* unused harmony export SelectOption */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["id", "flex", "value", "disabled"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const SelectContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
const SelectOption = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function SelectOption({
  value,
  title,
  onSelect
}) {
  const {
    addListener,
    removeListener
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(SelectContext);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!onSelect) return;
    addListener(value, onSelect);
    return () => removeListener(value);
  }, [addListener, onSelect, removeListener, value]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("option", {
    value: value,
    children: title !== null && title !== void 0 ? title : value
  });
});

const createChevronSVGString = color => `
  <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 15' fill='${color}'>
    <path d='M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z'></path>
  </svg>
`;

const SelectElement = styled_components__WEBPACK_IMPORTED_MODULE_1___default().select.withConfig({
  displayName: "Select__SelectElement",
  componentId: "sc-14s6z1y-0"
})(({
  theme,
  flex
}) => _objectSpread(_objectSpread({
  appearance: 'none'
}, theme.textStyles.small), {}, {
  color: theme.colors.text,
  width: '0px',
  // Reset intrinsic width
  flex: flex !== null && flex !== void 0 ? flex : '1 1 0px',
  position: 'relative',
  border: '0',
  outline: 'none',
  minWidth: '0',
  textAlign: 'left',
  alignSelf: 'stretch',
  borderRadius: '4px',
  paddingTop: '4px',
  paddingBottom: '4px',
  paddingLeft: '8px',
  paddingRight: '23px',
  background: [`calc(100% - 6px) / 15px url("data:image/svg+xml;utf8,${createChevronSVGString(theme.colors.icon)}") no-repeat`, theme.colors.inputBackground].join(','),
  '&:focus': {
    boxShadow: `0 0 0 2px ${theme.colors.primary}`
  }
}));

function SelectComponent(_ref) {
  let {
    id,
    flex,
    value,
    disabled
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const options = 'options' in rest ? rest.options : undefined;
  const getTitle = 'options' in rest ? rest.getTitle : undefined;
  const onChange = 'options' in rest ? rest.onChange : undefined;
  const children = 'options' in rest ? undefined : rest.children;
  const optionElements = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => options ? options.map((option, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(SelectOption, {
    value: option,
    title: getTitle === null || getTitle === void 0 ? void 0 : getTitle(option, index),
    onSelect: () => onChange === null || onChange === void 0 ? void 0 : onChange(option)
  }, option)) : children, [children, getTitle, onChange, options]);
  const listeners = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(new Map());
  const contextValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    addListener: (value, listener) => listeners.current.set(value, listener),
    removeListener: value => listeners.current.delete(value)
  }), []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(SelectContext.Provider, {
    value: contextValue,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(SelectElement, {
      id: id,
      disabled: disabled,
      flex: flex,
      value: value,
      onChange: (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(event => {
        var _listeners$current$ge;

        return (_listeners$current$ge = listeners.current.get(event.target.value)) === null || _listeners$current$ge === void 0 ? void 0 : _listeners$current$ge();
      }, [listeners]),
      children: optionElements
    })
  });
}

const Select = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(SelectComponent);

/***/ }),

/***/ 2250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export Slider */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8034);
/* harmony import */ var _radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const StyledSlider = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__.Root).withConfig({
  displayName: "Slider__StyledSlider",
  componentId: "sc-p6nnez-0"
})({
  flex: '1',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  userSelect: 'none',
  touchAction: 'none',
  height: '16px'
});
const StyledTrack = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__.Track).withConfig({
  displayName: "Slider__StyledTrack",
  componentId: "sc-p6nnez-1"
})(({
  theme
}) => ({
  backgroundColor: theme.colors.divider,
  position: 'relative',
  flexGrow: 1,
  height: '16px'
}));
const StyledRange = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__.Range).withConfig({
  displayName: "Slider__StyledRange",
  componentId: "sc-p6nnez-2"
})(({
  theme
}) => ({
  position: 'absolute',
  backgroundColor: theme.colors.primary,
  // borderRadius: '9999px',
  height: '100%'
}));
const StyledThumb = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_slider__WEBPACK_IMPORTED_MODULE_1__.Thumb).withConfig({
  displayName: "Slider__StyledThumb",
  componentId: "sc-p6nnez-3"
})(({
  theme
}) => ({
  display: 'block',
  width: '16px',
  height: '16px',
  backgroundColor: 'white',
  // borderRadius: '20px',
  '&:hover': {
    backgroundColor: '#ddd'
  },
  '&:focus': {
    outline: 'none',
    border: `2px solid ${theme.colors.primary}`,
    boxShadow: '0 0 0 2px white'
  }
}));
function Slider({
  id,
  value,
  onValueChange,
  min,
  max
}) {
  const arrayValue = useMemo(() => [Math.min(Math.max(value, min), max)], [value, min, max]);
  const handleValueChange = useCallback(arrayValue => {
    onValueChange(arrayValue[0]);
  }, [onValueChange]);
  return /*#__PURE__*/_jsxs(StyledSlider, {
    min: min,
    max: max,
    id: id,
    value: arrayValue,
    onValueChange: handleValueChange,
    children: [/*#__PURE__*/_jsx(StyledTrack, {
      children: /*#__PURE__*/_jsx(StyledRange, {})
    }), /*#__PURE__*/_jsx(StyledThumb, {})]
  });
}

/***/ }),

/***/ 4025:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ Item),
/* harmony export */   "f": () => (/* binding */ Root)
/* harmony export */ });
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3831);
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8196);
/* harmony import */ var _dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6405);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const defaultAcceptsDrop = (sourceId, destinationId, position) => {
  return position !== "inside" && sourceId !== destinationId;
};

const SortableItemContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({
  position: {
    x: 0,
    y: 0
  },
  acceptsDrop: defaultAcceptsDrop,
  setActivatorEvent: () => {}
});

function validateDropIndicator(acceptsDrop, activeId, overId, offsetTop, elementTop, elementHeight) {
  const acceptsDropInside = acceptsDrop(activeId, overId, "inside"); // If we're in the center of the element, prefer dropping inside

  if (offsetTop >= elementTop + elementHeight / 3 && offsetTop <= elementTop + elementHeight * 2 / 3 && acceptsDropInside) return "inside"; // Are we over the top or bottom half of the element?

  const indicator = offsetTop < elementTop + elementHeight / 2 ? "above" : "below"; // Drop above or below if possible, falling back to inside

  return acceptsDrop(activeId, overId, indicator) ? indicator : acceptsDropInside ? "inside" : undefined;
}
/* ----------------------------------------------------------------------------
 * Item
 * ------------------------------------------------------------------------- */


function SortableItem({
  id,
  disabled,
  children
}) {
  var _clientY;

  const {
    position,
    acceptsDrop,
    setActivatorEvent
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(SortableItemContext);
  const sortable = (0,_dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1__.useSortable)({
    id,
    disabled
  });
  const {
    active,
    activatorEvent,
    attributes,
    listeners,
    setNodeRef,
    isDragging,
    index,
    overIndex,
    over
  } = sortable;

  if (activatorEvent) {
    setActivatorEvent(activatorEvent);
  }

  const eventY = (_clientY = activatorEvent === null || activatorEvent === void 0 ? void 0 : activatorEvent.clientY) !== null && _clientY !== void 0 ? _clientY : 0;
  const offsetTop = eventY + position.y;
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(node => setNodeRef(node), [setNodeRef]);
  return children(_objectSpread(_objectSpread(_objectSpread({
    ref
  }, attributes), listeners), {}, {
    relativeDropPosition: index === overIndex && !isDragging && active && over ? validateDropIndicator(acceptsDrop, active.id, over.id, offsetTop, over.rect.offsetTop, over.rect.height) : undefined
  }));
}
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */


function SortableRoot({
  keys,
  children,
  onMoveItem,
  renderOverlay,
  acceptsDrop = defaultAcceptsDrop
}) {
  const sensors = (0,_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.useSensors)((0,_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.useSensor)(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.PointerSensor, {
    activationConstraint: {
      distance: 4
    }
  }));
  const {
    0: activeIndex,
    1: setActiveIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const activatorEvent = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
  const setActivatorEvent = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(event => {
    activatorEvent.current = event;
  }, []);
  const {
    0: position,
    1: setPosition
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
    x: 0,
    y: 0
  });
  const handleDragStart = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(event => {
    setActiveIndex(keys.indexOf(event.active.id));
  }, [keys]);
  const handleDragMove = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(event => {
    setPosition(_objectSpread({}, event.delta));
  }, []);
  const handleDragEnd = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(event => {
    const {
      active,
      over
    } = event;
    setActiveIndex(undefined);

    if (over && active.id !== over.id) {
      var _activatorEvent$curre, _activatorEvent$curre2;

      const oldIndex = keys.indexOf(active.id);
      const newIndex = keys.indexOf(over.id);
      const eventY = (_activatorEvent$curre = (_activatorEvent$curre2 = activatorEvent.current) === null || _activatorEvent$curre2 === void 0 ? void 0 : _activatorEvent$curre2.clientY) !== null && _activatorEvent$curre !== void 0 ? _activatorEvent$curre : 0;
      const offsetTop = eventY + position.y;
      const indicator = validateDropIndicator(acceptsDrop, active.id, over.id, offsetTop, over.rect.offsetTop, over.rect.height);
      if (!indicator) return;
      onMoveItem === null || onMoveItem === void 0 ? void 0 : onMoveItem(oldIndex, newIndex, indicator);
    }
  }, [acceptsDrop, keys, onMoveItem, position.y]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(SortableItemContext.Provider, {
    value: (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => ({
      acceptsDrop,
      position,
      setActivatorEvent
    }), [acceptsDrop, position, setActivatorEvent]),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.DndContext, {
      sensors: sensors,
      collisionDetection: _dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.closestCenter,
      onDragStart: handleDragStart,
      onDragMove: handleDragMove,
      onDragEnd: handleDragEnd,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1__.SortableContext, {
        items: keys,
        strategy: _dnd_kit_sortable__WEBPACK_IMPORTED_MODULE_1__.verticalListSortingStrategy,
        children: children
      }), typeof document !== "undefined" && renderOverlay && /*#__PURE__*/(0,react_dom__WEBPACK_IMPORTED_MODULE_3__.createPortal)( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_0__.DragOverlay, {
        dropAnimation: null,
        children: activeIndex !== undefined && renderOverlay(activeIndex)
      }), document.body)]
    })
  });
}

const Item = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(SortableItem);
const Root = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(SortableRoot);

/***/ }),

/***/ 6914:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ Stepper)
/* harmony export */ });
/* unused harmony export validateNumberInput */
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9615);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_2__]);
designsystem__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






function validateNumberInput(inputValue, min, max) {
  const number = Number(inputValue);
  if (!Number.isInteger(number) || number < min || number > max) return undefined;
  return number;
}
function Stepper({
  inputValue,
  onChange,
  min,
  max,
  placeholder,
  disabled
}) {
  const inputNumber = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => validateNumberInput(inputValue, min, max), [inputValue, max, min]);
  const handleClickPlus = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
    onChange(inputNumber === undefined ? '1' : String(Math.min(inputNumber + 1, max)));
  }, [inputNumber, max, onChange]);
  const handleClickMinus = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
    onChange(inputNumber === undefined ? '1' : String(Math.max(inputNumber - 1, min)));
  }, [inputNumber, min, onChange]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components__WEBPACK_IMPORTED_MODULE_1__/* .HStack */ .Ug, {
    alignItems: "center",
    flex: "1 1 0px",
    gap: 10,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
      onClick: handleClickMinus,
      disabled: disabled,
      style: {
        alignSelf: 'stretch'
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.MinusIcon, {})
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Root */ .UP.fC, {
      id: "input-multi-mint",
      flex: "1 1 0px",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .InputField.Input */ .UP.II, {
        disabled: disabled,
        value: inputValue,
        placeholder: placeholder,
        type: "text",
        style: {
          textAlign: 'center',
          padding: '8px 8px',
          fontSize: '1rem',
          lineHeight: '1',
          opacity: disabled ? 0.5 : undefined
        },
        onChange: onChange,
        onBlur: () => {
          const number = validateNumberInput(inputValue, min, max);

          if (number === undefined) {
            onChange('1');
          }
        }
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .zx, {
      onClick: handleClickPlus,
      disabled: disabled,
      style: {
        alignSelf: 'stretch'
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_0__.PlusIcon, {})
    })]
  });
}
});

/***/ }),

/***/ 121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ TextArea)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const TextArea = styled_components__WEBPACK_IMPORTED_MODULE_0___default().textarea.withConfig({
  displayName: "TextArea",
  componentId: "sc-7iojqw-0"
})(({
  theme,
  textAlign,
  disabled
}) => _objectSpread(_objectSpread({}, theme.textStyles.small), {}, {
  color: disabled ? theme.colors.textDisabled : theme.colors.text,
  width: '0px',
  // Reset intrinsic width
  flex: '1 1 0px',
  position: 'relative',
  border: '0',
  outline: 'none',
  minWidth: '0',
  textAlign: textAlign !== null && textAlign !== void 0 ? textAlign : 'left',
  alignSelf: 'stretch',
  borderRadius: '4px',
  paddingTop: '4px',
  paddingBottom: '4px',
  paddingLeft: '6px',
  paddingRight: '6px',
  background: disabled ? '#282828' : theme.colors.inputBackground,
  '&:focus': {
    boxShadow: `0 0 0 2px ${theme.colors.primary}`
  }
}));

/***/ }),

/***/ 2679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(999);
/* harmony import */ var _radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // const Arrow = styled(TooltipPrimitive.Arrow)(({ theme }) => ({
//   fill: theme.colors.popover.background,
// }));



const Content = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1__.Content).withConfig({
  displayName: "Tooltip__Content",
  componentId: "sc-1mfzuel-0"
})(({
  theme
}) => _objectSpread(_objectSpread({}, theme.textStyles.small), {}, {
  color: theme.colors.text,
  borderRadius: 3,
  padding: `${theme.sizes.spacing.small}px ${theme.sizes.spacing.medium}px`,
  backgroundColor: theme.colors.popover.background,
  boxShadow: '0 2px 4px rgba(0,0,0,0.2), 0 0 12px rgba(0,0,0,0.1)',
  border: `1px solid ${theme.colors.dividerStrong}`
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function Tooltip({
  children,
  content
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1__.Root, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_radix_ui_react_tooltip__WEBPACK_IMPORTED_MODULE_1__.Trigger, {
      asChild: true,
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Content, {
      side: "bottom",
      align: "center",
      sideOffset: 2,
      children: content
    })]
  });
}));

/***/ }),

/***/ 5777:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fC": () => (/* binding */ Root),
/* harmony export */   "Wh": () => (/* binding */ RowTitle),
/* harmony export */   "X2": () => (/* binding */ Row)
/* harmony export */ });
/* unused harmony export EditableRowTitle */
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9615);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3003);
/* harmony import */ var _ListView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2166);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListView__WEBPACK_IMPORTED_MODULE_3__]);
_ListView__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
const _excluded = ["icon", "expanded", "onClickChevron", "children"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const TreeRow = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(function TreeRow(_ref, forwardedRef) {
  let {
    icon,
    expanded,
    onClickChevron,
    children
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    expandable
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_ListView__WEBPACK_IMPORTED_MODULE_3__/* .ListRowContext */ .lV);
  const handleClickChevron = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(event => {
    event.stopPropagation();
    onClickChevron === null || onClickChevron === void 0 ? void 0 : onClickChevron({
      altKey: event.altKey
    });
  }, [onClickChevron]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_ListView__WEBPACK_IMPORTED_MODULE_3__/* .Row */ .X2, _objectSpread(_objectSpread({
    ref: forwardedRef
  }, rest), {}, {
    children: [expandable && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: [expanded === undefined ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .SpacerHorizontal */ .lC, {
        size: 15
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_IconButton__WEBPACK_IMPORTED_MODULE_2__/* .IconButton */ .h, {
        iconName: expanded ? 'ChevronDownIcon' : 'ChevronRightIcon',
        onClick: handleClickChevron,
        selected: rest.selected
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .SpacerHorizontal */ .lC, {
        size: 6
      })]
    }), icon && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: [icon, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .SpacerHorizontal */ .lC, {
        size: 10
      })]
    }), children]
  }));
});
/* ----------------------------------------------------------------------------
 * Root
 * ------------------------------------------------------------------------- */

const Root = _ListView__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .fC;
const RowTitle = _ListView__WEBPACK_IMPORTED_MODULE_3__/* .RowTitle */ .Wh;
const EditableRowTitle = _ListView__WEBPACK_IMPORTED_MODULE_3__/* .EditableRowTitle */ .Z8;
const Row = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(TreeRow);
});

/***/ }),

/***/ 638:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W5": () => (/* binding */ SEPARATOR_ITEM),
/* harmony export */   "Im": () => (/* binding */ CHECKBOX_WIDTH),
/* harmony export */   "hx": () => (/* binding */ CHECKBOX_RIGHT_INSET),
/* harmony export */   "W2": () => (/* binding */ styles),
/* harmony export */   "Gq": () => (/* binding */ getKeyboardShortcutsForMenuItems),
/* harmony export */   "eM": () => (/* binding */ KeyboardShortcut)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var keymap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6682);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6221);
/* harmony import */ var _contexts_DesignSystemConfiguration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2555);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([keymap__WEBPACK_IMPORTED_MODULE_2__]);
keymap__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const SEPARATOR_ITEM = 'separator';
const CHECKBOX_WIDTH = 15;
const CHECKBOX_RIGHT_INSET = 3;
const styles = {
  separatorStyle: ({
    theme
  }) => ({
    height: '1px',
    backgroundColor: theme.colors.divider,
    margin: '4px 8px'
  }),
  itemStyle: ({
    theme,
    disabled
  }) => _objectSpread(_objectSpread(_objectSpread({}, theme.textStyles.small), {}, {
    fontWeight: 500,
    fontSize: '0.8rem',
    flex: '0 0 auto',
    userSelect: 'none',
    cursor: 'pointer',
    borderRadius: '3px',
    padding: '4px 8px'
  }, disabled && {
    color: theme.colors.textDisabled
  }), {}, {
    '&:focus': {
      outline: 'none',
      color: 'white',
      backgroundColor: theme.colors.primary,
      '& kbd': {
        color: 'white'
      }
    },
    '&:active': {
      background: theme.colors.primaryLight
    },
    display: 'flex',
    alignItems: 'center'
  }),
  itemIndicatorStyle: {
    display: 'flex',
    alignItems: 'center',
    left: `-${CHECKBOX_WIDTH / 2}px`,
    position: 'relative',
    marginRight: `-${CHECKBOX_RIGHT_INSET}px`
  },
  contentStyle: ({
    theme,
    scrollable
  }) => _objectSpread({
    borderRadius: 4,
    backgroundColor: theme.colors.popover.background,
    color: theme.colors.text,
    boxShadow: '0 2px 4px rgba(0,0,0,0.2), 0 0 12px rgba(0,0,0,0.1)',
    padding: '4px',
    border: `1px solid ${theme.colors.divider}`
  }, scrollable && {
    height: '100%',
    maxHeight: 'calc(100vh - 80px)',
    overflow: 'hidden auto'
  })
};

function getKeyboardShortcuts(item) {
  if (item === SEPARATOR_ITEM) return [];
  if (item.items) return item.items.flatMap(getKeyboardShortcuts);
  if (item.disabled || !item.value || !item.shortcut) return [];
  return [[item.shortcut, item.value]];
}

function getKeyboardShortcutsForMenuItems(menuItems, onSelect) {
  return Object.fromEntries(menuItems.flatMap(getKeyboardShortcuts).map(([key, value]) => [key, () => onSelect(value)]));
}
const ShortcutElement = styled_components__WEBPACK_IMPORTED_MODULE_0___default().kbd.withConfig({
  displayName: "Menu__ShortcutElement",
  componentId: "sc-1jc9tui-0"
})(({
  theme,
  fixedWidth
}) => _objectSpread(_objectSpread({}, theme.textStyles.small), {}, {
  color: theme.colors.textDisabled,
  fontFamily: 'inherit'
}, fixedWidth && {
  width: '0.9rem',
  textAlign: 'center'
}));
const KeyboardShortcut = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(function KeyboardShortcut({
  shortcut
}) {
  const platform = (0,_contexts_DesignSystemConfiguration__WEBPACK_IMPORTED_MODULE_4__/* .useDesignSystemConfiguration */ .o)().platform;
  const {
    keys,
    separator
  } = (0,keymap__WEBPACK_IMPORTED_MODULE_2__/* .getShortcutDisplayParts */ .bS)(shortcut, platform);
  const keyElements = keys.map(key => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ShortcutElement, {
    fixedWidth: platform === 'mac' && key.length === 1,
    children: key
  }, key));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: separator ? (0,utils__WEBPACK_IMPORTED_MODULE_3__.withSeparatorElements)(keyElements, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ShortcutElement, {
      children: separator
    })) : keyElements
  });
});
});

/***/ }),

/***/ 1712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ mergeEventHandlers)
/* harmony export */ });
/* harmony import */ var _radix_ui_primitive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(290);
/* harmony import */ var _radix_ui_primitive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_primitive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6221);



function composeAllEventHandlers(...handlers) {
  const [first, ...rest] = handlers;
  return rest.reduce((result, handler) => (0,_radix_ui_primitive__WEBPACK_IMPORTED_MODULE_0__.composeEventHandlers)(result, handler), first);
}

function mergeEventHandlers(...handlerMaps) {
  const eventNames = (0,utils__WEBPACK_IMPORTED_MODULE_1__.unique)(handlerMaps.map(Object.keys).flat());
  return Object.fromEntries(eventNames.map(eventName => {
    const handlers = handlerMaps.flatMap(handlerMap => {
      const value = handlerMap[eventName];
      return value ? [value] : [];
    });
    return [eventName, composeAllEventHandlers(...handlers)];
  }));
}

/***/ }),

/***/ 3798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useHover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* eslint-disable */
// From: https://github.com/radix-ui/primitives/blob/main/packages/react/scroll-area/src/useHover.ts
// MIT License
// This code is a fork of `react-aria`'s `useHover` hook. The code in this file are based on code
// from both `react-aria` and `react-interactions`. Original licensing for each project can be found
// in the the root directories of each respective repository.
//
// @see https://github.com/adobe/react-spectrum/tree/452d1cb6a49f9f493757737edaf2b64014108de6/packages/%40react-aria
// @see https://github.com/facebook/react/tree/cc7c1aece46a6b69b41958d731e0fd27c94bfc6c/packages/react-interactions

// iOS fires onPointerEnter twice: once with pointerType="touch" and again with pointerType="mouse".
// We want to ignore these emulated events so they do not trigger hover behavior.
// See https://bugs.webkit.org/show_bug.cgi?id=214609.
let globalIgnoreEmulatedMouseEvents = false;
let hoverCount = 0;

function setGlobalIgnoreEmulatedMouseEvents() {
  globalIgnoreEmulatedMouseEvents = true; // Clear globalIgnoreEmulatedMouseEvents after a short timeout. iOS fires onPointerEnter with
  // pointerType="mouse" immediately after onPointerUp and before onFocus. On other devices that
  // don't have this quirk, we don't want to ignore a mouse hover sometime in the distant future
  // because a user previously touched the element.

  setTimeout(function clearGlobalIgnoreEmulatedMouseEvents() {
    globalIgnoreEmulatedMouseEvents = false;
  }, 50);
}

function handleGlobalPointerEvent(event) {
  if (event.pointerType === 'touch') {
    setGlobalIgnoreEmulatedMouseEvents();
  }
}

function setupGlobalTouchEvents() {
  if (typeof document === 'undefined') {
    return;
  }

  document.addEventListener('pointerup', handleGlobalPointerEvent);
  hoverCount++;
  return function teardownGlobalTouchEvents() {
    hoverCount--;

    if (hoverCount > 0) {
      return;
    }

    document.removeEventListener('pointerup', handleGlobalPointerEvent);
  };
}
/**
 * Handles pointer hover interactions for an element. Normalizes behavior
 * across browsers and platforms, and ignores emulated mouse events on touch devices.
 */


function useHover(props = {}) {
  const {
    onHoverStart,
    onHoverChange,
    onHoverEnd,
    isDisabled
  } = props;
  const [isHovered, setHovered] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);
  const state = react__WEBPACK_IMPORTED_MODULE_0__.useRef({
    isHovered: false,
    ignoreEmulatedMouseEvents: false
  }).current;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(setupGlobalTouchEvents, []);
  const hoverProps = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function getHoverProps() {
    function triggerHoverStart(event, pointerType) {
      if (isDisabled || pointerType === 'touch' || state.isHovered) {
        return;
      }

      state.isHovered = true;
      const target = event.target;

      if (onHoverStart) {
        onHoverStart({
          type: 'hoverstart',
          target,
          pointerType
        });
      }

      if (onHoverChange) {
        onHoverChange(true);
      }

      setHovered(true);
    }

    function triggerHoverEnd(event, pointerType) {
      if (isDisabled || pointerType === 'touch' || !state.isHovered) {
        return;
      }

      state.isHovered = false;
      const target = event.target;

      if (onHoverEnd) {
        onHoverEnd({
          type: 'hoverend',
          target,
          pointerType
        });
      }

      if (onHoverChange) {
        onHoverChange(false);
      }

      setHovered(false);
    }

    const hoverProps = {
      onPointerEnter(event) {
        if (globalIgnoreEmulatedMouseEvents && event.pointerType === 'mouse') {
          return;
        }

        triggerHoverStart(event, event.pointerType);
      },

      onPointerLeave(event) {
        triggerHoverEnd(event, event.pointerType);
      }

    };
    return hoverProps;
  }, [isDisabled, state, onHoverStart, onHoverChange, onHoverEnd]);
  return {
    hoverProps,
    isHovered
  };
}

/***/ }),

/***/ 1801:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vU": () => (/* reexport safe */ _ArrayController__WEBPACK_IMPORTED_MODULE_0__.v),
/* harmony export */   "zx": () => (/* reexport safe */ _components_Button__WEBPACK_IMPORTED_MODULE_1__.z),
/* harmony export */   "hU": () => (/* reexport safe */ _components_IconButton__WEBPACK_IMPORTED_MODULE_2__.h),
/* harmony export */   "UP": () => (/* reexport module object */ _components_InputField__WEBPACK_IMPORTED_MODULE_3__),
/* harmony export */   "LQ": () => (/* reexport module object */ _components_TreeView__WEBPACK_IMPORTED_MODULE_5__),
/* harmony export */   "Ph": () => (/* reexport safe */ _components_Select__WEBPACK_IMPORTED_MODULE_6__.P),
/* harmony export */   "Kx": () => (/* reexport safe */ _components_TextArea__WEBPACK_IMPORTED_MODULE_9__.K),
/* harmony export */   "J2": () => (/* reexport safe */ _components_Popover__WEBPACK_IMPORTED_MODULE_11__.J),
/* harmony export */   "vF": () => (/* reexport safe */ _components_Stepper__WEBPACK_IMPORTED_MODULE_12__.v),
/* harmony export */   "Y4": () => (/* reexport safe */ _utils_createdSectionedMenu__WEBPACK_IMPORTED_MODULE_13__.Y),
/* harmony export */   "h_": () => (/* reexport safe */ _components_DropdownMenu__WEBPACK_IMPORTED_MODULE_15__.Z),
/* harmony export */   "Ex": () => (/* reexport safe */ _components_Progress__WEBPACK_IMPORTED_MODULE_17__.E)
/* harmony export */ });
/* harmony import */ var _ArrayController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6731);
/* harmony import */ var _components_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3901);
/* harmony import */ var _components_IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3003);
/* harmony import */ var _components_InputField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4628);
/* harmony import */ var _components_ListView__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2166);
/* harmony import */ var _components_TreeView__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5777);
/* harmony import */ var _components_Select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(924);
/* harmony import */ var _components_Sortable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4025);
/* harmony import */ var _components_Tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2679);
/* harmony import */ var _components_TextArea__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(121);
/* harmony import */ var _components_Accordion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5523);
/* harmony import */ var _components_Popover__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8350);
/* harmony import */ var _components_Stepper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6914);
/* harmony import */ var _utils_createdSectionedMenu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2633);
/* harmony import */ var _components_ContextMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6513);
/* harmony import */ var _components_DropdownMenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3242);
/* harmony import */ var _components_Slider__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2250);
/* harmony import */ var _components_Progress__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7687);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_DropdownMenu__WEBPACK_IMPORTED_MODULE_15__, _components_ContextMenu__WEBPACK_IMPORTED_MODULE_14__, _utils_createdSectionedMenu__WEBPACK_IMPORTED_MODULE_13__, _components_Stepper__WEBPACK_IMPORTED_MODULE_12__, _components_TreeView__WEBPACK_IMPORTED_MODULE_5__, _components_ListView__WEBPACK_IMPORTED_MODULE_4__, _ArrayController__WEBPACK_IMPORTED_MODULE_0__]);
([_components_DropdownMenu__WEBPACK_IMPORTED_MODULE_15__, _components_ContextMenu__WEBPACK_IMPORTED_MODULE_14__, _utils_createdSectionedMenu__WEBPACK_IMPORTED_MODULE_13__, _components_Stepper__WEBPACK_IMPORTED_MODULE_12__, _components_TreeView__WEBPACK_IMPORTED_MODULE_5__, _components_ListView__WEBPACK_IMPORTED_MODULE_4__, _ArrayController__WEBPACK_IMPORTED_MODULE_0__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);























});

/***/ }),

/***/ 2633:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ createSectionedMenu)
/* harmony export */ });
/* harmony import */ var _components_internal_Menu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(638);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_internal_Menu__WEBPACK_IMPORTED_MODULE_0__]);
_components_internal_Menu__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


function withSeparators(elements, separator) {
  const result = [];

  for (let i = 0; i < elements.length; i++) {
    result.push(elements[i]);

    if (i !== elements.length - 1) {
      result.push(separator);
    }
  }

  return result;
}

function createSectionedMenu(...sections) {
  const nonEmptySections = sections.flatMap(section => section ? [section] : []).map(section => section.flatMap(item => item ? [item] : [])).filter(section => section.length > 0);
  return withSeparators(nonEmptySections, [_components_internal_Menu__WEBPACK_IMPORTED_MODULE_0__/* .SEPARATOR_ITEM */ .W5]).flat();
}
});

/***/ }),

/***/ 6966:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ isLeftButtonClicked)
/* harmony export */ });
/* unused harmony export isRightButtonClicked */
function isLeftButtonClicked(event) {
  return event.button === 0;
}
function isRightButtonClicked(event) {
  return event.button === 2;
}

/***/ }),

/***/ 3099:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ createCarBlob)
/* harmony export */ });
/* harmony import */ var car_file__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(424);
/* harmony import */ var car_file__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(car_file__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fileData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1726);


async function createCarBlob(files) {
  const {
    cid,
    content
  } = await (0,car_file__WEBPACK_IMPORTED_MODULE_0__.createCar)(files.flatMap(([path, file]) => {
    if (file.type === 'directory') return [];
    return [{
      path,
      content: (0,_fileData__WEBPACK_IMPORTED_MODULE_1__/* .fileDataToBytes */ .Md)(file.data)
    }];
  }));
  const blob = new Blob([content], {
    type: 'application/car'
  });
  return {
    cid,
    blob
  };
}

/***/ }),

/***/ 1726:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lo": () => (/* binding */ createFileData),
/* harmony export */   "cx": () => (/* binding */ fileDataToString),
/* harmony export */   "Md": () => (/* binding */ fileDataToBytes)
/* harmony export */ });
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6221);

function createFileData(value) {
  return typeof value === 'string' ? {
    encoding: 'string',
    value
  } : value instanceof Uint8Array ? {
    encoding: 'bytes',
    value
  } : {
    encoding: 'json',
    value
  };
}
function fileDataToString(fileData) {
  switch (fileData.encoding) {
    case 'bytes':
      return utils__WEBPACK_IMPORTED_MODULE_0__.UTF16.fromUTF8(fileData.value);

    case 'string':
      return fileData.value;

    case 'json':
      return JSON.stringify(fileData.value);
  }
}
function fileDataToBytes(fileData) {
  switch (fileData.encoding) {
    case 'bytes':
      return fileData.value;

    case 'string':
      return utils__WEBPACK_IMPORTED_MODULE_0__.UTF16.toUTF8(fileData.value);

    case 'json':
      return utils__WEBPACK_IMPORTED_MODULE_0__.UTF16.toUTF8(JSON.stringify(fileData.value));
  }
}

/***/ }),

/***/ 298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ FileSystem)
/* harmony export */ });
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3922);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(imfs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var tree_visit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4940);
/* harmony import */ var tree_visit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(tree_visit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6221);



const numberedFileRE = /^(?<number>\d+)(?<label>.*)/;
const matchNumberedFile = (0,utils__WEBPACK_IMPORTED_MODULE_2__.memoize)(string => string.match(numberedFileRE));

function getEntries(entry) {
  const [pathname, node] = entry;
  return imfs__WEBPACK_IMPORTED_MODULE_0__.Nodes.isDirectory(node) ? Object.entries(node.children).sort((a, b) => {
    const matchA = matchNumberedFile(a[0]);
    const matchB = matchNumberedFile(b[0]);

    if (matchA && matchB && matchA.groups.label === matchB.groups.label) {
      return parseInt(matchA.groups.number) - parseInt(matchB.groups.number);
    }

    return a[0].localeCompare(b[0]);
  }).map(([key, value]) => [imfs__WEBPACK_IMPORTED_MODULE_0__.path.join(pathname, key), value]) : [];
}

const FileSystem = (0,tree_visit__WEBPACK_IMPORTED_MODULE_1__.withOptions)({
  getChildren: getEntries
});

/***/ }),

/***/ 2417:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yO": () => (/* reexport safe */ _car__WEBPACK_IMPORTED_MODULE_0__.y),
/* harmony export */   "lo": () => (/* reexport safe */ _fileData__WEBPACK_IMPORTED_MODULE_1__.lo),
/* harmony export */   "Md": () => (/* reexport safe */ _fileData__WEBPACK_IMPORTED_MODULE_1__.Md),
/* harmony export */   "cx": () => (/* reexport safe */ _fileData__WEBPACK_IMPORTED_MODULE_1__.cx),
/* harmony export */   "Wd": () => (/* reexport safe */ _fileSystem__WEBPACK_IMPORTED_MODULE_2__.W),
/* harmony export */   "sZ": () => (/* reexport safe */ _zip__WEBPACK_IMPORTED_MODULE_3__.s)
/* harmony export */ });
/* harmony import */ var _car__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3099);
/* harmony import */ var _fileData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1726);
/* harmony import */ var _fileSystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(298);
/* harmony import */ var _zip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9233);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_zip__WEBPACK_IMPORTED_MODULE_3__]);
_zip__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




});

/***/ }),

/***/ 9233:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ Zip)
/* harmony export */ });
/* harmony import */ var fflate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2540);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3922);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(imfs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fileData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1726);
/* harmony import */ var _fileSystem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(298);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([fflate__WEBPACK_IMPORTED_MODULE_0__]);
fflate__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function unzip(bytes) {
  return new Promise((resolve, reject) => {
    fflate__WEBPACK_IMPORTED_MODULE_0__.unzip(bytes, (error, zip) => {
      if (error) {
        reject(error);
      } else {
        resolve(zip);
      }
    });
  });
}

function zip(zip) {
  return new Promise((resolve, reject) => {
    fflate__WEBPACK_IMPORTED_MODULE_0__.zip(zip, (error, bytes) => {
      if (error) {
        reject(error);
      } else {
        resolve(bytes);
      }
    });
  });
}

async function toVolume(zip) {
  const volume = imfs__WEBPACK_IMPORTED_MODULE_1__.Volume.create();

  for (const [filename, bytes] of Object.entries(zip)) {
    // TODO: Does fflate preserve folders?
    if (filename.endsWith('/')) {
      imfs__WEBPACK_IMPORTED_MODULE_1__.Volume.makeDirectory(volume, filename);
    } else {
      const data = (0,_fileData__WEBPACK_IMPORTED_MODULE_2__/* .createFileData */ .lo)(bytes);
      imfs__WEBPACK_IMPORTED_MODULE_1__.Volume.writeFile(volume, filename, data, {
        makeIntermediateDirectories: true
      });
    }
  }

  return volume;
}

async function fromVolume(volume) {
  const zip = {};
  _fileSystem__WEBPACK_IMPORTED_MODULE_3__/* .FileSystem.visit */ .W.visit(imfs__WEBPACK_IMPORTED_MODULE_1__.Entries.createEntry('/', volume), ([filename, node]) => {
    if (filename === '/') return;

    if (node.type === 'directory') {// TODO: Preserve directories?
    } else {
      zip[filename] = (0,_fileData__WEBPACK_IMPORTED_MODULE_2__/* .fileDataToBytes */ .Md)(node.data);
    }
  });
  return zip;
}

async function toFile(data, name) {
  const bytes = await zip(data);
  const file = new File([bytes], name, {
    type: 'application/zip'
  });
  return file;
}

async function fromFile(file) {
  const arrayBuffer = await file.arrayBuffer();
  return unzip(new Uint8Array(arrayBuffer));
} // eslint-disable-next-line @typescript-eslint/no-redeclare


const Zip = {
  zip,
  unzip,
  fromVolume,
  toVolume,
  fromFile,
  toFile
};
});

/***/ }),

/***/ 656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Dv": () => (/* reexport */ downloadDependenciesForSource),
  "fX": () => (/* reexport */ generateContractSource),
  "f7": () => (/* reexport */ generateURI),
  "Lw": () => (/* reexport */ getBaseURI),
  "th": () => (/* reexport */ getValidContractName),
  "P5": () => (/* reexport */ parseURITemplate),
  "E0": () => (/* reexport */ populateTemplate)
});

// UNUSED EXPORTS: downloadDependencies, downloadFile, fetchFile, getContractURI, isValidSolidityIdentifier, normalizeImport, parseImports, parseTemplate

// EXTERNAL MODULE: external "prettier"
var external_prettier_ = __webpack_require__(3920);
;// CONCATENATED MODULE: ../solidity-language/src/format.ts

const {
  group,
  join,
  hardline,
  softline,
  line,
  indent,
  ifBreak
} = external_prettier_.doc.builders;
function formatBlockComment(node) {
  switch (node.commentType) {
    case '/*':
      return `/** ${node.value} **/`;

    case '//':
      return group(join(hardline, node.value.split('\n').map(v => `// ${v}`)));
  }
}
function formatProgram(node) {
  const importsDoc = join(hardline, node.imports.map(formatImport));
  return join([hardline, hardline], [...(node.license ? [`// SPDX-License-Identifier: ${node.license}`] : []), ...(node.pragma ? [formatPragma(node.pragma)] : []), importsDoc, ...node.body.map(child => {
    switch (child.type) {
      case 'blockComment':
        return formatBlockComment(child);

      case 'contractDeclaration':
        return formatContract(child);

      default:
        throw new Error('Bad node type');
    }
  })]);
}
function formatVariableDeclaration(node) {
  if (node.initializer) {
    return group([group(join(line, [node.typeAnnotation, ...node.modifiers, node.name, '='])), indent([line, [formatExpression(node.initializer), ';']])]);
  } else {
    return group(join(line, [node.typeAnnotation, ...node.modifiers, [node.name, ';']]));
  }
}
function formatDeclaration(node) {
  switch (node.type) {
    case 'usingDeclaration':
      return `using ${node.alias} for ${node.forProperty};`;

    case 'blockComment':
      return formatBlockComment(node);

    case 'functionDeclaration':
      return group(join(line, [group([group([group(['function', line, [node.name, ['(', node.arguments.join(', '), ')']]]), indent([line, join(line, node.modifiers)])]), ...(node.returns ? [indent([line, 'returns ', '(', node.returns.typeAnnotation, ...(node.returns.modifiers.length > 0 ? [' ', ...node.returns.modifiers] : []), ')'])] : [])]), ['{', indent([hardline, join([hardline, hardline], node.body.map(formatStatement))]), hardline, '}']]));

    case 'constructorDeclaration':
      return group(join(line, [group([group(['constructor', group(['(', indent([softline, join([',', line], node.arguments)]), softline, ')'])]), ...(node.super ? [indent([line, formatExpression(node.super)])] : [])]), ['{', ...(node.body.length > 0 ? [indent([hardline, join([hardline, hardline], node.body.map(formatStatement))]), hardline] : []), '}']]));

    case 'structDeclaration':
      return group(join(line, [group([group(['struct', line, node.name])]), ['{', indent([hardline, join([hardline], node.body.map(item => `${item.typeAnnotation} ${item.name};`))]), hardline, '}']]));

    case 'variableDeclaration':
      return formatVariableDeclaration(node);

    case 'contractDeclaration':
      return formatContract(node);
  }
}
function formatStatement(node) {
  switch (node.type) {
    case 'blockComment':
      return formatBlockComment(node);

    case 'declarationStatement':
      return formatDeclaration(node.declaration);

    case 'expressionStatement':
      return [formatExpression(node.expression), ';'];

    case 'returnStatement':
      {
        if (!node.expression) {
          return 'return;';
        }

        return group(['return', ifBreak([' (']), group(indent([line, formatExpression(node.expression)])), ifBreak([line, ')']), ';']);
      }

    case 'forStatement':
      return ['for (', node.pre, '; ', node.update, '; ', node.post, ') ', ['{', indent([hardline, join([hardline, hardline], node.body.map(formatStatement))]), hardline, '}']];

    case 'ifStatement':
      return ['if (', formatExpression(node.condition), ') {', indent([hardline, join([hardline, hardline], node.body.map(formatStatement))]), hardline, '}', ...(node.alternate ? [' else {', indent([hardline, join([hardline, hardline], node.alternate.map(formatStatement))]), hardline, '}'] : [])];
  }
}
function formatContract(node) {
  return group([group(join(line, ['contract', node.name, ...(node.extends.length > 0 ? ['is', join([',', line], node.extends)] : [])])), line, '{', ...(node.body.length > 0 ? [indent([hardline, join([hardline, hardline], node.body.map(formatDeclaration))]), hardline] : []), '}']);
}
function formatImport(node) {
  if (node.names.length > 0) {
    return `import {${node.names.join(', ')}} from "${node.path}";`;
  }

  return `import "${node.path}";`;
}
function formatPragma(node) {
  return `pragma ${node.value};`;
}
function formatLiteral(node) {
  return node.value;
}
function formatExpression(node) {
  var _node$arguments;

  switch (node.type) {
    case 'identifier':
      return node.value;

    case 'literal':
      return formatLiteral(node.value);

    case 'assignmentExpression':
      return group([formatExpression(node.lhs), ' = ', formatExpression(node.rhs)]);

    case 'binaryExpression':
      return group([group([formatExpression(node.lhs), line, node.operator]), line, formatExpression(node.rhs)]);

    case 'memberExpression':
      return group([formatExpression(node.object), '.', formatExpression(node.member)]);

    case 'indexAccessExpression':
      return group([formatExpression(node.object), '[', formatExpression(node.index), ']']);

    case 'functionCallExpression':
      const args = (_node$arguments = node.arguments) !== null && _node$arguments !== void 0 ? _node$arguments : [];
      const hasNamedArgs = !Array.isArray(args);
      return group([formatExpression(node.callee), group([hasNamedArgs ? '({' : '(', indent([softline, join([',', line], Array.isArray(args) ? args.map(formatExpression) : Object.entries(args).map(([key, value]) => group([key, ':', line, formatExpression(value)])))]), softline, hasNamedArgs ? '})' : ')'])]);
  }
}
function print(document, options = {
  printWidth: 80,
  tabWidth: 2,
  useTabs: false
}) {
  return external_prettier_.doc.printer.printDocToString(document, options).formatted;
}
;// CONCATENATED MODULE: ../solidity-language/src/builders.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function identifierExpression(name) {
  return {
    type: 'identifier',
    value: name
  };
}
function literalExpression(value) {
  return {
    type: 'literal',
    value: {
      type: typeof value === 'string' ? 'stringLiteral' : typeof value === 'number' ? 'numberLiteral' : 'booleanLiteral',
      value: String(value)
    }
  };
}
function contractDeclaration(options) {
  var _options$extends, _options$body;

  return _objectSpread(_objectSpread({
    type: 'contractDeclaration'
  }, options), {}, {
    extends: (_options$extends = options.extends) !== null && _options$extends !== void 0 ? _options$extends : [],
    body: (_options$body = options.body) !== null && _options$body !== void 0 ? _options$body : []
  });
}
function variableDeclaration(options) {
  var _options$modifiers;

  return _objectSpread(_objectSpread({
    type: 'variableDeclaration'
  }, options), {}, {
    modifiers: (_options$modifiers = options.modifiers) !== null && _options$modifiers !== void 0 ? _options$modifiers : []
  });
}
function structDeclaration(options) {
  return _objectSpread({
    type: 'structDeclaration'
  }, options);
}
function structMemberDeclaration(options) {
  return _objectSpread({
    type: 'structMemberDeclaration'
  }, options);
}
function functionDeclaration(options) {
  var _options$arguments;

  return _objectSpread(_objectSpread({
    type: 'functionDeclaration'
  }, options), {}, {
    arguments: (_options$arguments = options.arguments) !== null && _options$arguments !== void 0 ? _options$arguments : []
  });
}
function usingDeclaration(options) {
  return _objectSpread({
    type: 'usingDeclaration'
  }, options);
}
function memberExpression(options) {
  return _objectSpread({
    type: 'memberExpression'
  }, options);
}
function indexAccessExpression(options) {
  return _objectSpread({
    type: 'indexAccessExpression'
  }, options);
}
function assignmentExpression(options) {
  return _objectSpread({
    type: 'assignmentExpression'
  }, options);
}
function binaryExpression(options) {
  return _objectSpread({
    type: 'binaryExpression'
  }, options);
}
function functionCallExpression(options) {
  var _options$arguments2;

  return _objectSpread(_objectSpread({
    type: 'functionCallExpression'
  }, options), {}, {
    arguments: (_options$arguments2 = options.arguments) !== null && _options$arguments2 !== void 0 ? _options$arguments2 : []
  });
}
function expressionStatement(options) {
  return _objectSpread({
    type: 'expressionStatement'
  }, options);
}
function declarationStatement(options) {
  return _objectSpread({
    type: 'declarationStatement'
  }, options);
}
function returnStatement(expression) {
  return {
    type: 'returnStatement',
    expression
  };
}
function forStatement(options) {
  return _objectSpread({
    type: 'forStatement'
  }, options);
}
function ifStatement(options) {
  return _objectSpread({
    type: 'ifStatement'
  }, options);
}
function blockComment(options) {
  return _objectSpread({
    type: 'blockComment',
    commentType: '//'
  }, options);
}
function program(options) {
  return _objectSpread({}, options);
}
function parseExpression(value) {
  if (value === 'true' || value === 'false') {
    return {
      type: 'literal',
      value: {
        type: 'booleanLiteral',
        value
      }
    };
  } else if (/^[0-9]/.test(value)) {
    return {
      type: 'literal',
      value: {
        type: 'numberLiteral',
        value
      }
    };
  }

  return {
    type: 'identifier',
    value
  };
}
function parseVariableDeclaration(value) {
  const tokens = value.split(' ').filter(x => !!x);
  const assignmentIndex = tokens.indexOf('=');

  if (assignmentIndex !== -1) {
    const variablePart = tokens.slice(0, assignmentIndex);
    const initializerPart = tokens.slice(assignmentIndex + 1);
    return variableDeclaration({
      typeAnnotation: variablePart[0],
      modifiers: variablePart.slice(1, assignmentIndex - 1),
      name: variablePart[variablePart.length - 1],
      initializer: parseExpression(initializerPart.join(' '))
    });
  } else {
    return variableDeclaration({
      typeAnnotation: tokens[0],
      modifiers: tokens.slice(1, -1),
      name: tokens[tokens.length - 1]
    });
  }
}
function compact(values) {
  return values.filter(value => value !== null && value !== undefined && value !== true && value !== false);
}
;// CONCATENATED MODULE: ../solidity-language/src/index.ts




;// CONCATENATED MODULE: ../solidity-codegen/src/generate/activation.ts

function generateActivation({
  initialValue,
  toggleAccessToken,
  mutableAccessToken
}) {
  return [blockComment({
    value: 'ACTIVATION',
    commentType: '/*'
  }), variableDeclaration({
    name: 'saleIsActive',
    typeAnnotation: 'bool',
    modifiers: ['public'],
    initializer: literalExpression(String(initialValue))
  }), functionDeclaration({
    name: 'setSaleIsActive',
    arguments: ['bool saleIsActive_'],
    modifiers: ['external', 'onlyOwner'],
    body: [{
      type: 'expressionStatement',
      expression: {
        type: 'assignmentExpression',
        lhs: identifierExpression('saleIsActive'),
        rhs: identifierExpression('saleIsActive_')
      }
    }]
  }), ...(toggleAccessToken ? [variableDeclaration({
    name: 'accessTokenIsActive',
    typeAnnotation: 'bool',
    modifiers: ['public'],
    initializer: literalExpression(String(true))
  }), functionDeclaration({
    name: 'setAccessTokenIsActive',
    arguments: ['bool accessTokenIsActive_'],
    modifiers: ['external', 'onlyOwner'],
    body: [{
      type: 'expressionStatement',
      expression: {
        type: 'assignmentExpression',
        lhs: identifierExpression('accessTokenIsActive'),
        rhs: identifierExpression('accessTokenIsActive_')
      }
    }]
  })] : []), ...(mutableAccessToken ? [functionDeclaration({
    name: 'setAccessTokenAddress',
    arguments: ['address accessTokenAddress_'],
    modifiers: ['external', 'onlyOwner'],
    body: [{
      type: 'expressionStatement',
      expression: {
        type: 'assignmentExpression',
        lhs: identifierExpression('accessTokenAddress'),
        rhs: identifierExpression('accessTokenAddress_')
      }
    }]
  })] : [])];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/allowlist.ts

function generateAllowlist(config) {
  const hasAllowlist = config.amountAllowedForOwner > 0 || config.allowlistDestinations.length > 0;

  if (!hasAllowlist && config.limitPerWallet === undefined) {
    return [];
  }

  return [blockComment({
    value: 'MINTING LIMITS',
    commentType: '/*'
  }), variableDeclaration({
    name: 'mintCountMap',
    modifiers: ['private'],
    typeAnnotation: 'mapping(address => uint256)'
  }), variableDeclaration({
    name: 'allowedMintCountMap',
    modifiers: ['private'],
    typeAnnotation: 'mapping(address => uint256)'
  }), ...(config.limitPerWallet !== undefined ? [parseVariableDeclaration(`uint256 public constant MINT_LIMIT_PER_WALLET = ${config.limitPerWallet}`)] : []), ...(hasAllowlist && config.limitPerWallet !== undefined ? [functionDeclaration({
    name: 'max',
    arguments: ['uint256 a', 'uint256 b'],
    modifiers: ['private pure'],
    returns: {
      modifiers: [],
      typeAnnotation: 'uint256'
    },
    body: [returnStatement(identifierExpression('a >= b ? a : b'))]
  })] : []), functionDeclaration({
    name: 'allowedMintCount',
    arguments: ['address minter'],
    modifiers: ['public', 'view'],
    returns: {
      modifiers: [],
      typeAnnotation: 'uint256'
    },
    body: [...(hasAllowlist && config.limitPerWallet !== undefined ? [ifStatement({
      condition: identifierExpression('saleIsActive'),
      body: [returnStatement(binaryExpression({
        lhs: functionCallExpression({
          callee: identifierExpression('max'),
          arguments: [identifierExpression('allowedMintCountMap[minter]'), identifierExpression('MINT_LIMIT_PER_WALLET')]
        }),
        operator: '-',
        rhs: identifierExpression('mintCountMap[minter]')
      }))]
    })] : []), ...(hasAllowlist ? [returnStatement(binaryExpression({
      lhs: identifierExpression('allowedMintCountMap[minter]'),
      operator: '-',
      rhs: identifierExpression('mintCountMap[minter]')
    }))] : [returnStatement(binaryExpression({
      lhs: identifierExpression('MINT_LIMIT_PER_WALLET'),
      operator: '-',
      rhs: identifierExpression('mintCountMap[minter]')
    }))])]
  }), functionDeclaration({
    name: 'updateMintCount',
    arguments: ['address minter', 'uint256 count'],
    modifiers: ['private'],
    body: [expressionStatement({
      expression: binaryExpression({
        lhs: identifierExpression('mintCountMap[minter]'),
        operator: '+=',
        rhs: identifierExpression('count')
      })
    })]
  })];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/imports.ts
function generateImports({
  address,
  strings,
  enumerable,
  royalties,
  delegation,
  hasAccessToken
}) {
  const paths = [...(delegation ? [{
    path: 'gwei-slim-nft-contracts/contracts/base/ERC721Base.sol',
    names: ['ConfigSettings']
  }, {
    path: 'gwei-slim-nft-contracts/contracts/base/ERC721Delegated.sol',
    names: ['ERC721Delegated']
  }, ...(hasAccessToken ? ['@openzeppelin/contracts/token/ERC721/IERC721.sol'] : [])] : ['@openzeppelin/contracts/token/ERC721/ERC721.sol', '@openzeppelin/contracts/access/Ownable.sol']), '@openzeppelin/contracts/security/ReentrancyGuard.sol', ...(enumerable ? ['@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol'] : []), ...(royalties ? ['@openzeppelin/contracts/interfaces/IERC2981.sol'] : []), '@openzeppelin/contracts/utils/Counters.sol', ...(address ? ['@openzeppelin/contracts/utils/Address.sol'] : []), ...(strings ? ['@openzeppelin/contracts/utils/Strings.sol'] : [])];
  return paths.map(pathOrImport => {
    if (typeof pathOrImport === 'string') {
      return {
        path: pathOrImport,
        names: []
      };
    } else {
      return pathOrImport;
    }
  });
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/minting.ts

function generateMinting(config, context) {
  const {
    supply,
    price,
    multimint,
    enumerable,
    customMaxTokenId,
    requireAccessToken,
    limitPerWallet,
    onlyOwnerCanMint
  } = config;
  const priceValue = Number(price !== null && price !== void 0 ? price : '0');
  const actualPrice = priceValue * 1000000000000000000;
  const hasPrice = priceValue > 0;
  const hasMultimint = (multimint !== null && multimint !== void 0 ? multimint : 1) > 1;
  const variables = compact([requireAccessToken && variableDeclaration({
    name: 'accessTokenAddress',
    typeAnnotation: 'address',
    modifiers: ['public', ...(!config.mutableAccessToken ? ['immutable'] : [])]
  }), config.supply !== null && parseVariableDeclaration(`uint256 public constant MAX_SUPPLY = ${supply}`), config.usesIdParameter && customMaxTokenId !== undefined && supply !== customMaxTokenId && parseVariableDeclaration(`uint256 public constant MAX_TOKEN_ID = ${customMaxTokenId}`), hasMultimint && parseVariableDeclaration(`uint256 public constant MAX_MULTIMINT = ${multimint !== null && multimint !== void 0 ? multimint : 1}`), hasPrice && parseVariableDeclaration(`uint256 public constant PRICE = ${actualPrice}`), !enumerable && parseVariableDeclaration(`Counters.Counter private supplyCounter`)]);
  const checkAccessToken = expressionStatement({
    expression: functionCallExpression({
      callee: identifierExpression('require'),
      arguments: [config.usesIdParameter ? binaryExpression({
        lhs: identifierExpression('accessToken.ownerOf(id)'),
        operator: '==',
        rhs: context.msgSender
      }) : binaryExpression({
        lhs: functionCallExpression({
          callee: identifierExpression('accessToken.balanceOf'),
          arguments: [context.msgSender]
        }),
        operator: '>',
        rhs: literalExpression(0)
      }), identifierExpression(`"Access token not owned"`)]
    })
  });
  const mintStatements = [...(config.usesIdParameter && hasMultimint ? [declarationStatement({
    declaration: parseVariableDeclaration('uint256 id = ids[i]')
  })] : []), ...(config.usesIdParameter && config.customMaxTokenId !== undefined ? [expressionStatement({
    expression: functionCallExpression({
      callee: identifierExpression('require'),
      arguments: [supply !== customMaxTokenId ? identifierExpression(`id < MAX_TOKEN_ID, "Invalid token id"`) : identifierExpression(`id < MAX_SUPPLY, "Invalid token id"`)]
    })
  })] : []), ...(config.requireAccessToken ? [config.toggleAccessToken ? ifStatement({
    condition: identifierExpression('accessTokenIsActive'),
    body: [checkAccessToken]
  }) : checkAccessToken] : []), ...(config.tokenParameters.length > 0 && !config.usesIdParameter ? [declarationStatement({
    declaration: variableDeclaration({
      name: 'id',
      typeAnnotation: 'uint256',
      modifiers: [],
      initializer: functionCallExpression({
        callee: identifierExpression('totalSupply')
      })
    })
  })] : []), expressionStatement({
    expression: functionCallExpression({
      callee: identifierExpression('_mint'),
      arguments: [context.msgSender, config.usesIdParameter || config.tokenParameters.length > 0 ? identifierExpression('id') : functionCallExpression({
        callee: identifierExpression('totalSupply')
      })]
    })
  }), ...(config.tokenParameters.length > 0 ? [expressionStatement({
    expression: assignmentExpression({
      lhs: identifierExpression('tokenParametersMap[id]'),
      rhs: hasMultimint ? identifierExpression('parameters[i]') : identifierExpression('parameters')
    })
  })] : []), ...(!enumerable ? [expressionStatement({
    expression: memberExpression({
      object: identifierExpression('supplyCounter'),
      member: functionCallExpression({
        callee: identifierExpression('increment')
      })
    })
  })] : [])];
  const hasAllowlist = config.amountAllowedForOwner > 0 || config.allowlistDestinations.length > 0;
  const checkAndUpdateAllowedMint = ifStatement({
    condition: binaryExpression({
      lhs: functionCallExpression({
        callee: identifierExpression('allowedMintCount'),
        arguments: [context.msgSender]
      }),
      operator: '>=',
      rhs: literalExpression(config.usesIdParameter || hasMultimint ? `count` : 1)
    }),
    body: [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('updateMintCount'),
        arguments: [context.msgSender, literalExpression(config.usesIdParameter || hasMultimint ? `count` : 1)]
      })
    })],
    alternate: [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('revert'),
        arguments: [hasAllowlist && limitPerWallet !== undefined ? literalExpression(`saleIsActive ? "Minting limit exceeded" : "Sale not active"`) : literalExpression(`"Minting limit exceeded"`)]
      })
    })]
  });
  return [blockComment({
    value: 'MINTING',
    commentType: '/*'
  }), ...variables, functionDeclaration({
    name: 'mint',
    modifiers: ['public', ...(hasPrice ? ['payable'] : []), 'nonReentrant', ...(onlyOwnerCanMint ? ['onlyOwner'] : [])],
    arguments: [...(config.usesIdParameter ? hasMultimint ? ['uint256[] calldata ids'] : ['uint256 id'] : hasMultimint ? ['uint256 count'] : []), ...(config.tokenParameters.length > 0 ? hasMultimint ? ['TokenParameters[] calldata parameters'] : ['TokenParameters calldata parameters'] : [])],
    body: [...(config.usesIdParameter && hasMultimint ? [declarationStatement({
      declaration: parseVariableDeclaration('uint256 count = ids.length')
    })] : []), ...(hasAllowlist && limitPerWallet !== undefined ? [checkAndUpdateAllowedMint] : limitPerWallet !== undefined ? [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('require'),
        arguments: [identifierExpression(`saleIsActive`), literalExpression(`"Sale not active"`)]
      })
    }), checkAndUpdateAllowedMint] : hasAllowlist ? [ifStatement({
      condition: identifierExpression('!saleIsActive'),
      body: [ifStatement({
        condition: binaryExpression({
          lhs: functionCallExpression({
            callee: identifierExpression('allowedMintCount'),
            arguments: [context.msgSender]
          }),
          operator: '>=',
          rhs: literalExpression(config.usesIdParameter || hasMultimint ? `count` : 1)
        }),
        body: [expressionStatement({
          expression: functionCallExpression({
            callee: identifierExpression('updateMintCount'),
            arguments: [context.msgSender, literalExpression(config.usesIdParameter || hasMultimint ? `count` : 1)]
          })
        })],
        alternate: [expressionStatement({
          expression: functionCallExpression({
            callee: identifierExpression('revert'),
            arguments: [literalExpression(`"Sale not active"`)]
          })
        })]
      })]
    })] : [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('require'),
        arguments: [identifierExpression(`saleIsActive`), literalExpression(`"Sale not active"`)]
      })
    })]), ...(supply !== null ? [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('require'),
        arguments: [identifierExpression(`totalSupply() ${hasMultimint ? '+ count - 1 ' : ''}< MAX_SUPPLY, "Exceeds max supply"`)]
      })
    })] : []), ...(hasMultimint ? [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('require'),
        arguments: [identifierExpression(`count <= MAX_MULTIMINT, "Mint at most ${multimint} at a time"`)]
      })
    })] : []), ...(hasPrice ? [expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('require'),
        arguments: [identifierExpression(`msg.value >= ${hasMultimint ? `PRICE * count` : `PRICE`}, "Insufficient payment, ${price} ETH per item"`)]
      })
    })] : []), ...(config.requireAccessToken ? [declarationStatement({
      declaration: parseVariableDeclaration(config.usesDelegatedContract ? 'IERC721 accessToken = IERC721(accessTokenAddress)' : 'ERC721 accessToken = ERC721(accessTokenAddress)')
    })] : []), ...(hasMultimint ? [forStatement({
      pre: 'uint256 i = 0',
      update: 'i < count',
      post: 'i++',
      body: mintStatements
    })] : mintStatements)]
  }), ...(!enumerable ? [functionDeclaration({
    name: 'totalSupply',
    modifiers: ['public', 'view'],
    arguments: [],
    returns: {
      typeAnnotation: 'uint256',
      modifiers: []
    },
    body: [{
      type: 'returnStatement',
      expression: memberExpression({
        object: identifierExpression('supplyCounter'),
        member: functionCallExpression({
          callee: identifierExpression('current')
        })
      })
    }]
  })] : [])];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/parameters.ts

function generateTokenParameters(config) {
  return [blockComment({
    value: 'TOKEN PARAMETERS',
    commentType: '/*'
  }), structDeclaration({
    name: 'TokenParameters',
    body: config.tokenParameters.map(parameter => structMemberDeclaration({
      name: parameter.name,
      typeAnnotation: parameter.type
    }))
  }), variableDeclaration({
    name: 'tokenParametersMap',
    modifiers: ['private'],
    typeAnnotation: 'mapping(uint256 => TokenParameters)'
  }), functionDeclaration({
    name: 'tokenParameters',
    arguments: ['uint256 tokenId'],
    modifiers: ['external', 'view'],
    returns: {
      modifiers: ['memory'],
      typeAnnotation: 'TokenParameters'
    },
    body: [{
      type: 'returnStatement',
      expression: {
        type: 'identifier',
        value: 'tokenParametersMap[tokenId]'
      }
    }]
  })];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/proxy.ts

function generateProxyContracts() {
  return [contractDeclaration({
    name: 'OwnableDelegateProxy'
  }), contractDeclaration({
    name: 'ProxyRegistry',
    body: [variableDeclaration({
      name: 'proxies',
      modifiers: ['public'],
      typeAnnotation: 'mapping(address => OwnableDelegateProxy)'
    })]
  })];
}
function generateProxyApprovalFunction({
  usesDelegatedContract
}) {
  return [blockComment({
    value: 'PROXY REGISTRY',
    commentType: '/*'
  }), parseVariableDeclaration('address private immutable proxyRegistryAddress'), functionDeclaration({
    name: 'isApprovedForAll',
    arguments: ['address owner', 'address operator'],
    modifiers: [...(usesDelegatedContract ? [] : ['override']), 'public', 'view'],
    returns: {
      typeAnnotation: 'bool',
      modifiers: []
    },
    body: [declarationStatement({
      declaration: variableDeclaration({
        name: 'proxyRegistry',
        typeAnnotation: 'ProxyRegistry',
        initializer: functionCallExpression({
          callee: identifierExpression('ProxyRegistry'),
          arguments: [identifierExpression('proxyRegistryAddress')]
        })
      })
    }), ifStatement({
      condition: identifierExpression('address(proxyRegistry.proxies(owner)) == operator'),
      body: [returnStatement(literalExpression('true'))]
    }), returnStatement(functionCallExpression({
      callee: usesDelegatedContract ? identifierExpression('_isApprovedForAll') : identifierExpression('super.isApprovedForAll'),
      arguments: [identifierExpression('owner'), identifierExpression('operator')]
    }))]
  })];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/royalties.ts

function generateRoyalties(config) {
  return [blockComment({
    value: 'ROYALTIES',
    commentType: '/*'
  }), functionDeclaration({
    name: 'royaltyInfo',
    arguments: ['uint256', 'uint256 salePrice'],
    modifiers: ['external', 'view', 'override'],
    returns: {
      modifiers: [],
      typeAnnotation: 'address receiver, uint256 royaltyAmount'
    },
    body: [returnStatement(identifierExpression(`(address(this), (salePrice * ${Number(config.royaltyBps) * 100}) / 10000)`))]
  }), functionDeclaration({
    name: 'supportsInterface',
    arguments: ['bytes4 interfaceId'],
    modifiers: ['public', 'view', 'virtual', 'override(ERC721, IERC165)'],
    returns: {
      modifiers: [],
      typeAnnotation: 'bool'
    },
    body: [returnStatement(binaryExpression({
      operator: '||',
      lhs: identifierExpression('interfaceId == type(IERC2981).interfaceId'),
      rhs: identifierExpression('super.supportsInterface(interfaceId)')
    }))]
  })];
}
// EXTERNAL MODULE: external "language-tools"
var external_language_tools_ = __webpack_require__(4053);
// EXTERNAL MODULE: ../utils/src/index.ts + 17 modules
var src = __webpack_require__(6221);
;// CONCATENATED MODULE: ../solidity-codegen/src/templateParser.ts


const lexer = new external_language_tools_.Lexer([(0,external_language_tools_.state)('main', [(0,external_language_tools_.rule)('open', '{', {
  discard: true,
  action: {
    type: 'push',
    value: 'variable'
  }
}), ['content', '([^{]+)']]), (0,external_language_tools_.state)('variable', [(0,external_language_tools_.rule)('close', '}', {
  discard: true,
  action: {
    type: 'pop'
  }
}), ['identifier', '([^}]+)']])]);
function parseTemplate(string) {
  const result = lexer.tokenize(string);

  for (const token of result) {
    if (token.type === 'content' && token.values.some(value => value.includes('{') || value.includes('}'))) {
      return {
        type: 'failure',
        message: "Brackets {} don't match!"
      };
    }
  }

  return {
    type: 'success',
    value: result
  };
}
function parseURITemplate(string) {
  const result = parseTemplate(string);

  if (result.type === 'success') {
    for (const token of result.value) {
      if (token.type === 'identifier' && token.values.some(value => !['tokenId', 'parameters'].includes(value))) {
        return {
          type: 'failure',
          message: `Unrecognized variable {${token.values[0]}}.`
        };
      }
    }
  }

  return result;
}
function generateURI(template, tokenId, tokenParameters) {
  const parsed = parseURITemplate(template);
  if (parsed.type === 'failure') return;
  return parsed.value.map(token => {
    switch (token.type) {
      case 'content':
        return token.values.join('');

      case 'identifier':
        {
          switch (token.values[0]) {
            case 'tokenId':
              return tokenId.toString();

            case 'parameters':
              if (tokenParameters.length === 0) return '';
              return '?' + (0,src.encodeQueryParameters)(Object.fromEntries(tokenParameters.map(p => [p.name, 0])));

            default:
              return '';
          }
        }

      default:
        throw new Error('Bad token type');
    }
  }).join('');
}
function populateTemplate(template, parameters) {
  const parsed = parseTemplate(template);
  if (parsed.type === 'failure') return;
  return parsed.value.map(token => {
    var _parameters$token$val;

    switch (token.type) {
      case 'content':
        return token.values.join('');

      case 'identifier':
        return (_parameters$token$val = parameters[token.values[0]]) !== null && _parameters$token$val !== void 0 ? _parameters$token$val : '';

      default:
        throw new Error('Bad token type');
    }
  }).join('');
}
function getBaseURI(template) {
  const parsed = parseURITemplate(template);
  if (parsed.type === 'failure' || parsed.value[0].type === 'identifier') return '';
  return parsed.value[0].values.join('');
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/uri.ts



function getURIConfig(baseURI) {
  const tokenizedURI = parseURITemplate(baseURI);
  const tokens = tokenizedURI.type === 'success' ? tokenizedURI.value : [];
  const hasBaseURI = tokens.length > 0 && tokens[0].type === 'content';
  const isDefaultConfiguration = tokens.length === 2 && tokens[0].type === 'content' && tokens[1].type === 'identifier' && tokens[1].values[0] === 'tokenId' || tokens.length === 3 && tokens[0].type === 'content' && tokens[1].type === 'identifier' && tokens[1].values[0] === 'tokenId' && tokens[2].type === 'identifier' && tokens[2].values[0] === 'parameters';
  const startsWithDefaultConfiguration = tokens.length >= 2 && tokens[0].type === 'content' && tokens[1].type === 'identifier' && tokens[1].values[0] === 'tokenId';
  const usesParameters = tokens.some(token => token.type === 'identifier' && token.values.includes('parameters'));
  return {
    tokens,
    isDefaultConfiguration,
    startsWithDefaultConfiguration,
    hasBaseURI,
    usesParameters
  };
}

function generateContractURI(uri) {
  return [parseVariableDeclaration(`string private customContractURI = ${JSON.stringify(encodeURI(uri))}`), functionDeclaration({
    name: 'setContractURI',
    arguments: ['string memory customContractURI_'],
    modifiers: ['external', 'onlyOwner'],
    body: [expressionStatement({
      expression: assignmentExpression({
        lhs: identifierExpression('customContractURI'),
        rhs: identifierExpression('customContractURI_')
      })
    })]
  }), functionDeclaration({
    name: 'contractURI',
    modifiers: ['public', 'view'],
    returns: {
      typeAnnotation: 'string',
      modifiers: ['memory']
    },
    body: [returnStatement(identifierExpression('customContractURI'))]
  })];
}

function generateURIHandling(config) {
  const {
    tokens,
    isDefaultConfiguration,
    startsWithDefaultConfiguration,
    usesParameters
  } = getURIConfig(config.tokenURI);
  const shouldReturnSimpleBaseURI = tokens.length === 1 || tokens.length === 2 && usesParameters && config.tokenParameters.length === 0;
  return [blockComment({
    value: 'URI HANDLING',
    commentType: '/*'
  }), ...(config.contractURI ? generateContractURI(config.contractURI) : []), ...(!config.usesDelegatedContract ? [parseVariableDeclaration('string private customBaseURI')] : []), ...(config.usesUriStorage ? [variableDeclaration({
    name: 'tokenURIMap',
    modifiers: ['private'],
    typeAnnotation: 'mapping(uint256 => string)'
  }), functionDeclaration({
    name: 'setTokenURI',
    arguments: ['uint256 tokenId', 'string memory tokenURI_'],
    modifiers: ['external', 'onlyOwner'],
    body: [{
      type: 'expressionStatement',
      expression: {
        type: 'assignmentExpression',
        lhs: {
          type: 'identifier',
          value: 'tokenURIMap[tokenId]'
        },
        rhs: {
          type: 'identifier',
          value: 'tokenURI_'
        }
      }
    }]
  })] : []), functionDeclaration({
    name: 'setBaseURI',
    arguments: ['string memory customBaseURI_'],
    modifiers: ['external', 'onlyOwner'],
    body: [config.usesDelegatedContract ? expressionStatement({
      expression: functionCallExpression({
        callee: identifierExpression('_setBaseURI'),
        arguments: [identifierExpression('customBaseURI_'), literalExpression('""')]
      })
    }) : expressionStatement({
      expression: assignmentExpression({
        lhs: identifierExpression('customBaseURI'),
        rhs: identifierExpression('customBaseURI_')
      })
    })]
  }), ...(!config.usesDelegatedContract ? [functionDeclaration({
    name: '_baseURI',
    arguments: [],
    modifiers: ['internal', 'view', 'virtual', ...(config.usesDelegatedContract ? [] : ['override'])],
    returns: {
      typeAnnotation: 'string',
      modifiers: ['memory']
    },
    body: [{
      type: 'returnStatement',
      expression: {
        type: 'identifier',
        value: 'customBaseURI'
      }
    }]
  })] : []), ...(!isDefaultConfiguration || usesParameters && config.tokenParameters.length > 0 || config.usesUriStorage ? [functionDeclaration({
    name: 'tokenURI',
    arguments: // We need to include the parameter, even when we don't use it,
    // so that the function has the right signature
    shouldReturnSimpleBaseURI && !config.usesUriStorage ? ['uint256'] : ['uint256 tokenId'],
    modifiers: ['public', 'view', ...(config.usesDelegatedContract ? [] : ['override'])],
    returns: {
      typeAnnotation: 'string',
      modifiers: ['memory']
    },
    body: [...(config.usesUriStorage ? [declarationStatement({
      declaration: parseVariableDeclaration('string memory tokenURI_ = tokenURIMap[tokenId]')
    }), ifStatement({
      condition: identifierExpression('bytes(tokenURI_).length > 0'),
      body: [returnStatement(identifierExpression('tokenURI_'))]
    })] : []), ...(usesParameters && config.tokenParameters.length > 0 ? [declarationStatement({
      declaration: variableDeclaration({
        name: 'parameters',
        modifiers: ['memory'],
        typeAnnotation: 'TokenParameters',
        initializer: identifierExpression('tokenParametersMap[tokenId]')
      })
    })] : []), {
      type: 'returnStatement',
      expression: shouldReturnSimpleBaseURI ? functionCallExpression({
        callee: identifierExpression('_baseURI')
      }) : functionCallExpression({
        callee: identifierExpression('string'),
        arguments: [functionCallExpression({
          callee: identifierExpression('abi.encodePacked'),
          arguments: [...tokens.flatMap((token, index) => {
            if (startsWithDefaultConfiguration) {
              if (index === 0) {
                return [identifierExpression(config.usesDelegatedContract ? '_tokenURI(tokenId)' : 'super.tokenURI(tokenId)')];
              } else if (index === 1) {
                return [];
              }
            }

            switch (token.type) {
              case 'content':
                return [identifierExpression(JSON.stringify(token.values.join('')))];

              case 'identifier':
                {
                  const values = token.values[0];

                  switch (values) {
                    case 'tokenId':
                      return [identifierExpression('tokenId')];

                    case 'parameters':
                      if (config.tokenParameters.length === 0) return [];
                      return [identifierExpression('"?"'), ...intersperse(config.tokenParameters.flatMap(parameter => [identifierExpression(`"${parameter.name}="`), identifierExpression(parameter.type === 'string' || parameter.type === 'address' ? `parameters.${parameter.name}` : `parameters.${parameter.name}.toString()`)]), identifierExpression('"&"'), 2)];

                    default:
                      return [identifierExpression(JSON.stringify(token.values.join('')))];
                  }
                }

              default:
                throw new Error('Invalid');
            }
          })]
        })]
      })
    }]
  })] : [])];
}
function intersperse(elements, separator, stride = 1) {
  return elements.flatMap((element, i) => i === 0 || i % stride !== 0 ? [element] : [separator, element]);
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generate/withdrawing.ts

function generateWithdrawing({
  payoutDestinations
}, context) {
  payoutDestinations = payoutDestinations.filter(d => d.amount > 0);
  const total = payoutDestinations.map(item => item.amount).reduce((result, item) => result + item, 0);
  const destinations = [...(total < 100 ? [{
    expression: context.owner,
    amount: 100 - total
  }] : []), ...payoutDestinations.map((destination, index) => {
    return {
      expression: identifierExpression(`payoutAddress${index + 1}`),
      amount: destination.amount
    };
  })];
  return [blockComment({
    value: 'PAYOUT',
    commentType: '/*'
  }), ...payoutDestinations.map((destination, index) => parseVariableDeclaration(`address private constant payoutAddress${index + 1} = ${destination.address}`)), {
    type: 'functionDeclaration',
    name: 'withdraw',
    arguments: [],
    modifiers: ['public', 'nonReentrant'],
    body: [{
      type: 'declarationStatement',
      declaration: {
        type: 'variableDeclaration',
        typeAnnotation: 'uint256',
        name: 'balance',
        modifiers: [],
        initializer: {
          type: 'memberExpression',
          object: {
            type: 'functionCallExpression',
            callee: identifierExpression('address'),
            arguments: [identifierExpression('this')]
          },
          member: identifierExpression('balance')
        }
      }
    }, ...destinations.map(destination => {
      return expressionStatement({
        expression: {
          type: 'memberExpression',
          object: identifierExpression('Address'),
          member: functionCallExpression({
            callee: identifierExpression('sendValue'),
            arguments: [functionCallExpression({
              callee: identifierExpression('payable'),
              arguments: [destination.expression]
            }), destination.amount !== 100 ? binaryExpression({
              lhs: identifierExpression('balance'),
              operator: '*',
              rhs: binaryExpression({
                lhs: literalExpression(destination.amount),
                operator: '/',
                rhs: literalExpression(100)
              })
            }) : identifierExpression('balance')]
          })
        }
      });
    })]
  }];
}
;// CONCATENATED MODULE: ../solidity-codegen/src/generateContract.ts










const SOLIDITY_IDENTIFIER_RE = /^[a-zA-Z$_][a-zA-Z0-9$_]*$/;
function isValidSolidityIdentifier(name) {
  return SOLIDITY_IDENTIFIER_RE.test(name);
}
function getValidContractName(name) {
  let nameWithValidChars = name.replace(/[^a-zA-Z0-9$_]/g, '');

  while (nameWithValidChars.length > 1 && /[^a-zA-Z$_]/.test(nameWithValidChars[0])) {
    nameWithValidChars = nameWithValidChars.slice(1);
  }

  if (!isValidSolidityIdentifier(nameWithValidChars)) {
    return 'Contract';
  }

  return nameWithValidChars;
}
function generateContractSource(config) {
  const {
    tokenName,
    shortName,
    price
  } = config;
  const priceValue = Number(price);
  const hasPrice = priceValue > 0;
  const validRoyaltyBps = config.royaltyBps && config.royaltyBps !== '0' ? config.royaltyBps : undefined;
  const hasWithdraw = hasPrice || validRoyaltyBps ? true : false;
  const context = {
    msgSender: memberExpression({
      object: identifierExpression('msg'),
      member: identifierExpression('sender')
    }),
    owner: functionCallExpression({
      callee: identifierExpression(config.usesDelegatedContract ? '_owner' : 'owner')
    })
  };
  const program = {
    license: 'MIT',
    pragma: {
      value: 'solidity ^0.8.9'
    },
    imports: generateImports({
      address: hasWithdraw,
      enumerable: config.enumerable,
      strings: config.tokenParameters.length > 0,
      royalties: !!validRoyaltyBps && !config.usesDelegatedContract,
      delegation: config.usesDelegatedContract,
      hasAccessToken: !!config.requireAccessToken
    }),
    body: [...(config.approvalProxyAddress ? generateProxyContracts() : []), {
      type: 'contractDeclaration',
      name: getValidContractName(tokenName),
      extends: [config.usesDelegatedContract ? 'ERC721Delegated' : config.enumerable ? 'ERC721Enumerable' : 'ERC721', ...(validRoyaltyBps && !config.usesDelegatedContract ? ['IERC2981'] : []), 'ReentrancyGuard', ...(config.usesDelegatedContract ? [] : ['Ownable'])],
      body: [usingDeclaration({
        alias: 'Counters',
        forProperty: 'Counters.Counter'
      }), ...(config.tokenParameters.length > 0 ? [usingDeclaration({
        alias: 'Strings',
        forProperty: 'uint256'
      })] : []), {
        type: 'constructorDeclaration',
        arguments: [...(config.usesDelegatedContract ? ['address baseFactory'] : []), 'string memory customBaseURI_', ...(config.requireAccessToken ? ['address accessTokenAddress_'] : []), ...(config.approvalProxyAddress ? ['address proxyRegistryAddress_'] : [])],
        super: config.usesDelegatedContract ? functionCallExpression({
          callee: identifierExpression(`ERC721Delegated`),
          arguments: [identifierExpression('baseFactory'), literalExpression(`"${tokenName}"`), literalExpression(`"${shortName}"`), functionCallExpression({
            callee: identifierExpression('ConfigSettings'),
            arguments: {
              royaltyBps: literalExpression(validRoyaltyBps ? Number(validRoyaltyBps) * 100 : 0),
              uriBase: identifierExpression('customBaseURI_'),
              uriExtension: literalExpression('""'),
              hasTransferHook: literalExpression(false)
            }
          })]
        }) : functionCallExpression({
          callee: identifierExpression('ERC721'),
          arguments: [literalExpression(`"${tokenName}"`), literalExpression(`"${shortName}"`)]
        }),
        body: compact([!config.usesDelegatedContract && expressionStatement({
          expression: assignmentExpression({
            lhs: identifierExpression('customBaseURI'),
            rhs: identifierExpression('customBaseURI_')
          })
        }), config.requireAccessToken && expressionStatement({
          expression: assignmentExpression({
            lhs: identifierExpression('accessTokenAddress'),
            rhs: identifierExpression('accessTokenAddress_')
          })
        }), config.approvalProxyAddress && expressionStatement({
          expression: assignmentExpression({
            lhs: identifierExpression('proxyRegistryAddress'),
            rhs: identifierExpression('proxyRegistryAddress_')
          })
        }), config.amountAllowedForOwner > 0 && expressionStatement({
          expression: assignmentExpression({
            lhs: indexAccessExpression({
              object: identifierExpression('allowedMintCountMap'),
              index: config.usesDelegatedContract ? context.msgSender : context.owner
            }),
            rhs: literalExpression(config.amountAllowedForOwner)
          })
        }), ...config.allowlistDestinations.filter(dest => dest.amount > 0).map(dest => expressionStatement({
          expression: assignmentExpression({
            lhs: identifierExpression(`allowedMintCountMap[${dest.address}]`),
            rhs: literalExpression(dest.amount)
          })
        }))])
      }, ...(config.tokenParameters.length > 0 ? generateTokenParameters(config) : []), ...(config.amountAllowedForOwner > 0 || config.allowlistDestinations.length > 0 || config.limitPerWallet !== undefined ? generateAllowlist(config) : []), ...generateMinting(config, context), ...generateActivation({
        initialValue: config.activateAutomatically,
        toggleAccessToken: config.toggleAccessToken,
        mutableAccessToken: config.mutableAccessToken
      }), ...generateURIHandling({
        tokenParameters: config.tokenParameters,
        tokenURI: config.tokenURI,
        usesUriStorage: config.usesUriStorage,
        usesDelegatedContract: config.usesDelegatedContract,
        contractURI: config.contractURI
      }), ...(hasWithdraw ? generateWithdrawing({
        payoutDestinations: config.payoutDestinations
      }, context) : []), ...(validRoyaltyBps && !config.usesDelegatedContract ? generateRoyalties({
        royaltyBps: validRoyaltyBps
      }) : []), ...(config.approvalProxyAddress ? generateProxyApprovalFunction({
        usesDelegatedContract: config.usesDelegatedContract
      }) : [])]
    }, blockComment({
      value: 'Contract created with Studio 721 v1.5.0\nhttps://721.so',
      commentType: '//'
    })]
  };
  return print(formatProgram(program));
}
// EXTERNAL MODULE: external "imfs"
var external_imfs_ = __webpack_require__(3922);
;// CONCATENATED MODULE: ../solidity-codegen/src/resolveImports.ts
function resolveImports_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function resolveImports_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { resolveImports_ownKeys(Object(source), true).forEach(function (key) { resolveImports_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { resolveImports_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function resolveImports_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


// eslint-disable-next-line no-useless-escape
const importRe = /import\s+?(?:\{.*?\}\s+?from\s+?)?"([@A-Za-z0-9_\-\/\.]+)"/gm;
function parseImports(source) {
  const result = source.matchAll(importRe);
  return [...result].map(match => match[1]);
}
function normalizeImport(parentName, name) {
  const parentDir = external_imfs_.path.dirname(parentName);

  if (!name.startsWith('@')) {
    return external_imfs_.path.join(parentDir, name);
  } else {
    return name;
  }
}
function getContractURI(importPath, versions) {
  if (versions) {
    const parts = importPath.split(external_imfs_.path.sep); // [ '@openzeppelin', 'contracts', 'token', 'ERC721', 'ERC721.sol' ]

    if (parts[0].startsWith('@')) {
      parts[1] += `@${versions['@openzeppelin/contracts']}`;
    } else {
      parts[0] += `@${versions['gwei-slim-nft-contracts']}`;
    }

    importPath = parts.join(external_imfs_.path.sep);
  }

  return `https://unpkg.com/${importPath}`;
}
async function fetchFile(fetch, importPath, versions) {
  const contractURI = getContractURI(importPath, versions);
  const result = await fetch(contractURI);
  const text = await result.text();
  return text;
}
async function downloadFile(fetch, importPath, versions) {
  const source = await fetchFile(fetch, importPath, versions);
  return {
    importPath,
    source,
    imports: parseImports(source)
  };
}
async function downloadDependencies(fetch, initialImports, versions) {
  const files = {};
  const remaining = [...initialImports];

  while (remaining.length > 0) {
    const downloadedFiles = await Promise.all(remaining.map(importPath => downloadFile(fetch, importPath, versions)));
    remaining.length = 0;
    downloadedFiles.forEach(({
      importPath,
      source
    }) => {
      files[importPath] = source;
    });
    const resolvedImports = downloadedFiles.flatMap(({
      importPath: parentPath,
      imports
    }) => imports.map(importPath => normalizeImport(parentPath, importPath))).filter(name => !(name in files));
    remaining.push(...resolvedImports);
  }

  return files;
}
async function downloadDependenciesForSource(fetch, importPath, source, versions) {
  const files = await downloadDependencies(fetch, parseImports(source), versions);
  return resolveImports_objectSpread({
    [importPath]: source
  }, files);
}
;// CONCATENATED MODULE: ../solidity-codegen/src/index.ts




/***/ }),

/***/ 8997:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cq": () => (/* binding */ createInitialCollectionState),
/* harmony export */   "Eu": () => (/* binding */ collectionReducer),
/* harmony export */   "P0": () => (/* binding */ parseTokenMetadata)
/* harmony export */ });
/* unused harmony export batchUpdateMetadata */
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3922);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(imfs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7133);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(immer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8531);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6221);
/* harmony import */ var files__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2417);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([files__WEBPACK_IMPORTED_MODULE_4__, state__WEBPACK_IMPORTED_MODULE_2__]);
([files__WEBPACK_IMPORTED_MODULE_4__, state__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
const _excluded = ["animation_url"],
      _excluded2 = ["external_url"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function createInitialCollectionState() {
  return {
    didInitialize: false,
    selectedFiles: [],
    volume: imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.create()
  };
}
function collectionReducer(state, action) {
  switch (action.type) {
    case 'setFileHandle':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.fileHandle = action.fileHandle;
        draft.selectedFiles = [];
        draft.didInitialize = true;

        if (action.volume) {
          draft.volume = action.volume;
        }
      });

    case 'selectFile':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        var _action$selectionType;

        (0,state__WEBPACK_IMPORTED_MODULE_2__/* .updateSelection */ .e3)(draft.selectedFiles, action.files, (_action$selectionType = action.selectionType) !== null && _action$selectionType !== void 0 ? _action$selectionType : 'replace');
      });

    case 'addToken':
      if (!state.volume) return state;
      const existingNumbers = new Set(imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.readDirectory(state.volume, '/metadata').map(name => parseInt(name)));
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        let nextNumber = 0;

        while (existingNumbers.has(nextNumber)) {
          nextNumber++;
        }

        const name = `${nextNumber}.token.json`;
        const file = imfs__WEBPACK_IMPORTED_MODULE_0__.path.join('metadata', name);
        const bytes = JSON.stringify({});
        imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.writeFile(draft.volume, file, (0,files__WEBPACK_IMPORTED_MODULE_4__/* .createFileData */ .lo)(bytes));
        draft.selectedFiles = [file];
      });

    case 'deleteFile':
      {
        const files = typeof action.files === 'string' ? [action.files] : action.files;
        return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          (0,state__WEBPACK_IMPORTED_MODULE_2__/* .updateSelection */ .e3)(draft.selectedFiles, [], 'replace');
          files.forEach(name => {
            if (!draft.volume) return;
            imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.removeFile(draft.volume, name);
          });
        });
      }

    case 'writeFile':
      {
        const {
          file,
          value
        } = action;
        return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          if (!draft.volume) return;
          imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.writeFile(draft.volume, file, value);
        });
      }

    case 'makeDirectory':
      {
        const {
          file
        } = action;
        return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          if (!draft.volume) return;
          imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.makeDirectory(draft.volume, file);
        });
      }

    case 'setTokenMetadataName':
      return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
        name: action.value
      }));

    case 'setTokenMetadataDescription':
      return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
        description: action.value
      }));

    case 'setTokenMetadataImage':
      return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
        image: action.value
      }));

    case 'setTokenMetadataAnimationUrl':
      return batchUpdateMetadata(state, action.files, metadata => {
        if (!action.value) {
          const {
            animation_url
          } = metadata,
                rest = _objectWithoutProperties(metadata, _excluded);

          return rest;
        }

        return _objectSpread(_objectSpread({}, metadata), {}, {
          animation_url: action.value
        });
      });

    case 'setTokenMetadataExternalUrl':
      return batchUpdateMetadata(state, action.files, metadata => {
        if (!action.value) {
          const {
            external_url
          } = metadata,
                rest = _objectWithoutProperties(metadata, _excluded2);

          return rest;
        }

        return _objectSpread(_objectSpread({}, metadata), {}, {
          external_url: action.value
        });
      });

    case 'setTokenMetadataAttributes':
      {
        return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
          attributes: action.attributes
        }));
      }

    case 'setGeneratedMetadata':
      {
        state = immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          for (const file in action.generated) {
            const image = action.generated[file].image;

            if (image) {
              imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.setNode(draft.volume, imfs__WEBPACK_IMPORTED_MODULE_0__.path.join('/assets/thumbnail', image[0]), image[1], {
                makeIntermediateDirectories: true
              });
            }
          }
        });
        return batchUpdateMetadata(state, Object.keys(action.generated), (metadata, name) => {
          const {
            image,
            attributes
          } = action.generated[name];
          return _objectSpread(_objectSpread({}, metadata), {}, {
            image: image ? imfs__WEBPACK_IMPORTED_MODULE_0__.path.join('/assets/thumbnail', image[0]) : metadata.image,
            attributes: attributes !== null && attributes !== void 0 ? attributes : metadata.attributes
          });
        });
      }

    case 'setTokenMetadataImageFromComputer':
      {
        const assetName = `/assets/${action.name}`;
        state = immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          if (!draft.volume) return;
          imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.writeFile(draft.volume, assetName, (0,files__WEBPACK_IMPORTED_MODULE_4__/* .createFileData */ .lo)(action.data), {
            makeIntermediateDirectories: true
          });
        });
        return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
          image: assetName
        }));
      }

    case 'addTokenMetadataAttribute':
      {
        if (!state.volume) return state;
        const volume = state.volume;
        const metadata = action.files.map(file => imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.readFile(volume, file)).map(parseTokenMetadata);
        const attributeNames = new Set();
        metadata.forEach(item => {
          var _item$attributes;

          (_item$attributes = item.attributes) === null || _item$attributes === void 0 ? void 0 : _item$attributes.forEach(attribute => {
            attributeNames.add(attribute.trait_type);
          });
        });
        const name = attributeNames.has('Trait') ? (0,utils__WEBPACK_IMPORTED_MODULE_3__.getIncrementedName)('Trait', [...attributeNames.values()]) : 'Trait';
        return batchUpdateMetadata(state, action.files, metadata => _objectSpread(_objectSpread({}, metadata), {}, {
          attributes: [...(metadata.attributes ? metadata.attributes : []), {
            trait_type: name,
            value: ''
          }]
        }));
      }

    case 'removeTokenMetadataAttribute':
      {
        if (!state.volume) return state;
        return batchUpdateMetadata(state, action.files, metadata => {
          var _metadata$attributes;

          return _objectSpread(_objectSpread({}, metadata), {}, {
            attributes: (_metadata$attributes = metadata.attributes) === null || _metadata$attributes === void 0 ? void 0 : _metadata$attributes.filter(attribute => attribute.trait_type !== action.attributeName)
          });
        });
      }

    case 'setTokenMetadataAttributeName':
      {
        if (!state.volume) return state;
        return batchUpdateMetadata(state, action.files, metadata => {
          var _metadata$attributes2;

          return _objectSpread(_objectSpread({}, metadata), {}, {
            attributes: (_metadata$attributes2 = metadata.attributes) === null || _metadata$attributes2 === void 0 ? void 0 : _metadata$attributes2.map(attribute => attribute.trait_type === action.originalAttributeName ? {
              trait_type: action.newAttributeName,
              value: attribute.value
            } : attribute)
          });
        });
      }

    case 'setTokenMetadataAttributeValue':
      {
        if (!state.volume) return state;
        return batchUpdateMetadata(state, action.files, metadata => {
          var _metadata$attributes3;

          return _objectSpread(_objectSpread({}, metadata), {}, {
            attributes: (_metadata$attributes3 = metadata.attributes) === null || _metadata$attributes3 === void 0 ? void 0 : _metadata$attributes3.map(attribute => attribute.trait_type === action.attributeName ? {
              trait_type: action.attributeName,
              value: action.attributeValue
            } : attribute)
          });
        });
      }

    case 'moveTokenMetadataAttribute':
      {
        if (!state.volume) return state;
        return batchUpdateMetadata(state, action.files, metadata => {
          var _metadata$attributes4;

          const attributes = [...((_metadata$attributes4 = metadata.attributes) !== null && _metadata$attributes4 !== void 0 ? _metadata$attributes4 : [])];
          const index = attributes.findIndex(attribute => attribute.trait_type === action.attributeName);

          if (index !== -1) {
            (0,state__WEBPACK_IMPORTED_MODULE_2__/* .moveArrayItem */ .aC)(attributes, index, action.destinationIndex);
          }

          return _objectSpread(_objectSpread({}, metadata), {}, {
            attributes
          });
        });
      }

    case 'setCollectionSize':
      {
        if (!state.volume) return state;
        let template = {};

        if (action.fileToDuplicate) {
          try {
            template = parseTokenMetadata(imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.readFile(state.volume, action.fileToDuplicate));
          } catch {// TODO: Prevent the user from accepting the dialog
            // with an invalid file
          }
        }

        console.log({
          action,
          template
        });
        const metadataNode = imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.getNode(state.volume, '/metadata');
        if (metadataNode.type !== 'directory') return state;
        const existingNumbers = new Set(imfs__WEBPACK_IMPORTED_MODULE_0__.Nodes.readDirectory(metadataNode).map(name => parseInt(name)).filter(Number.isInteger));
        const newNodes = [];

        for (let nextNumber = 0; nextNumber < action.size; nextNumber++) {
          if (existingNumbers.has(nextNumber)) continue;
          const nextFile = `${nextNumber}.token.json`;
          newNodes.push([nextFile, imfs__WEBPACK_IMPORTED_MODULE_0__.Nodes.createFile((0,files__WEBPACK_IMPORTED_MODULE_4__/* .createFileData */ .lo)(template))]);
        }

        const clone = {
          type: 'directory',
          metadata: undefined,
          children: _objectSpread(_objectSpread({}, metadataNode.children), Object.fromEntries(newNodes))
        };
        return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
          if (!draft.volume) return;
          imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.setNode(draft.volume, '/metadata', clone);
        });
      }
  }
}
function parseTokenMetadata(data) {
  if (data.encoding === 'json') {
    return data.value;
  }

  let json;

  try {
    const string = (0,files__WEBPACK_IMPORTED_MODULE_4__/* .fileDataToString */ .cx)(data);
    json = JSON.parse(string);
  } catch {
    json = {};
  }

  return json;
}
function batchUpdateMetadata(state, files, updater) {
  if (!state.volume) return state;
  const metadataNode = imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.getNode(state.volume, ['metadata']);
  if (metadataNode.type !== 'directory') return state;
  const filenames = new Set(files);
  const updatedChildren = {};

  for (const name in metadataNode.children) {
    const file = metadataNode.children[name];
    const filePath = `/metadata/${name}`;

    if (file.type !== 'file' || !filenames.has(filePath)) {
      updatedChildren[name] = file;
      continue;
    }

    const metadata = parseTokenMetadata(file.data);
    const data = updater(metadata, filePath);
    updatedChildren[name] = {
      type: 'file',
      metadata: undefined,
      data: (0,files__WEBPACK_IMPORTED_MODULE_4__/* .createFileData */ .lo)(data)
    };
  }

  const clone = {
    type: 'directory',
    metadata: undefined,
    children: updatedChildren
  };
  return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
    if (!draft.volume) return;
    imfs__WEBPACK_IMPORTED_MODULE_0__.Volume.setNode(draft.volume, ['metadata'], clone);
  });
}
});

/***/ }),

/***/ 6421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "uF": () => (/* binding */ GWEI_SLIM_VERSION),
  "be": () => (/* binding */ OPEN_ZEPPELIN_VERSION),
  "P_": () => (/* binding */ createDefaultConfig),
  "PA": () => (/* binding */ createInitialState),
  "J9": () => (/* binding */ createOpenPaletteConfig),
  "aC": () => (/* binding */ moveArrayItem),
  "I6": () => (/* binding */ reducer),
  "e3": () => (/* reexport */ updateSelection)
});

// EXTERNAL MODULE: external "@openpalette/contract"
var contract_ = __webpack_require__(4008);
// EXTERNAL MODULE: external "immer"
var external_immer_ = __webpack_require__(7133);
var external_immer_default = /*#__PURE__*/__webpack_require__.n(external_immer_);
// EXTERNAL MODULE: ../web3-utils/src/index.ts + 4 modules
var src = __webpack_require__(9772);
// EXTERNAL MODULE: ../utils/src/index.ts + 17 modules
var utils_src = __webpack_require__(6221);
;// CONCATENATED MODULE: ../state/src/utils/selection.ts
function updateSelection(currentIds, newIds, selectionType) {
  const ids = newIds === undefined ? [] : Array.isArray(newIds) ? newIds : [newIds];

  switch (selectionType) {
    case 'intersection':
      currentIds.push(...ids.filter(id => !currentIds.includes(id)));
      return;

    case 'difference':
      ids.forEach(id => {
        const selectedIndex = currentIds.indexOf(id);
        currentIds.splice(selectedIndex, 1);
      });
      return;

    case 'replace':
      // Update currentIds array in-place
      currentIds.length = 0;
      currentIds.push(...ids);
      return;
  }
}
;// CONCATENATED MODULE: ../state/src/contractReducer.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const OPEN_ZEPPELIN_VERSION = '4.3.2';
const GWEI_SLIM_VERSION = '1.0.3';
function createDefaultConfig() {
  return {
    customMaxTokenId: undefined,
    multimint: undefined,
    activateAutomatically: false,
    enumerable: false,
    usesIdParameter: false,
    requireAccessToken: undefined,
    toggleAccessToken: false,
    approvalProxyAddress: undefined
  };
}
function createOpenPaletteConfig() {
  return {
    customMaxTokenId: undefined,
    multimint: 20,
    activateAutomatically: false,
    toggleAccessToken: false,
    enumerable: false,
    usesIdParameter: true,
    requireAccessToken: {
      mainnet: (0,contract_.getContractAddress)(contract_.CHAIN_ID.MAINNET),
      rinkeby: (0,contract_.getContractAddress)(contract_.CHAIN_ID.RINKEBY),
      ropsten: '',
      goerli: '',
      polygon: '',
      mumbai: ''
    },
    approvalProxyAddress: {
      mainnet: (0,src/* getProxyAddress */.nq)(contract_.CHAIN_ID.MAINNET),
      rinkeby: (0,src/* getProxyAddress */.nq)(contract_.CHAIN_ID.RINKEBY),
      ropsten: '',
      goerli: '',
      polygon: '',
      mumbai: ''
    }
  };
}
function createInitialState(initialConfig) {
  var _localStorage$getItem;

  return {
    config: _objectSpread({
      tokenName: 'TestToken',
      shortName: 'TTKN',
      tokenURI: 'https://www.721.so/api/example/metadata/{tokenId}',
      supply: 2000,
      customMaxTokenId: undefined,
      multimint: undefined,
      price: undefined,
      activateAutomatically: false,
      onlyOwnerCanMint: false,
      usesUriStorage: false,
      enumerable: false,
      usesIdParameter: false,
      requireAccessToken: undefined,
      toggleAccessToken: false,
      mutableAccessToken: false,
      tokenParameters: [],
      payoutDestinations: [],
      allowlistDestinations: [],
      amountAllowedForOwner: 0,
      usesDelegatedContract: false
    }, initialConfig),
    compiler: {
      type: 'notStarted'
    },
    deployment: {
      type: 'notStarted'
    },
    verification: {
      type: 'notStarted'
    },
    apiKeys: {
      etherscan: typeof localStorage !== 'undefined' ? (_localStorage$getItem = localStorage.getItem('etherscanApiKey')) !== null && _localStorage$getItem !== void 0 ? _localStorage$getItem : '' : ''
    }
  };
}

function payoutReducer(state, action) {
  switch (action.type) {
    case 'setPayoutDestinationAddress':
      {
        const {
          index,
          address
        } = action;
        return external_immer_default()(state, draft => {
          draft.payoutDestinations[index].address = address;
        });
      }

    case 'setPayoutDestinationAmount':
      {
        const {
          index,
          amount
        } = action;
        return external_immer_default()(state, draft => {
          draft.payoutDestinations[index].amount = amount;
        });
      }

    case 'addPayoutDestination':
      {
        return external_immer_default()(state, draft => {
          draft.payoutDestinations.push({
            address: (0,contract_.createAddress)(utils_src.NullAddress),
            amount: 0
          });
        });
      }

    case 'removePayoutDestination':
      {
        const {
          index
        } = action;
        return external_immer_default()(state, draft => {
          draft.payoutDestinations.splice(index, 1);
        });
      }

    case 'movePayoutDestination':
      {
        const {
          sourceIndex,
          destinationIndex
        } = action;
        return external_immer_default()(state, draft => {
          moveArrayItem(draft.payoutDestinations, sourceIndex, destinationIndex);
        });
      }
  }
}

function allowlistReducer(state, action) {
  switch (action.type) {
    case 'setAmountAllowedForOwner':
      {
        const {
          amount
        } = action;
        return external_immer_default()(state, draft => {
          draft.amountAllowedForOwner = amount;
        });
      }

    case 'setAllowlistDestinationAddress':
      {
        const {
          index,
          address
        } = action;
        return external_immer_default()(state, draft => {
          draft.allowlistDestinations[index].address = address;
        });
      }

    case 'setAllowlistDestinationAmount':
      {
        const {
          index,
          amount
        } = action;
        return external_immer_default()(state, draft => {
          draft.allowlistDestinations[index].amount = amount;
        });
      }

    case 'addAllowlistDestination':
      {
        return external_immer_default()(state, draft => {
          draft.allowlistDestinations.push({
            address: (0,contract_.createAddress)(utils_src.NullAddress),
            amount: 0
          });
        });
      }

    case 'removeAllowlistDestination':
      {
        const {
          index
        } = action;
        return external_immer_default()(state, draft => {
          draft.allowlistDestinations.splice(index, 1);
        });
      }

    case 'moveAllowlistDestination':
      {
        const {
          sourceIndex,
          destinationIndex
        } = action;
        return external_immer_default()(state, draft => {
          moveArrayItem(draft.allowlistDestinations, sourceIndex, destinationIndex);
        });
      }
  }
}

function reducer(state, action) {
  const resetForConfigChange = {
    compiler: {
      type: 'notStarted'
    },
    deployment: {
      type: 'notStarted'
    }
  };

  switch (action.type) {
    case 'setConfig':
      {
        const {
          config
        } = action;
        return external_immer_default()(state, draft => {
          draft.config = _objectSpread(_objectSpread({}, draft.config), config);
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'setTokenParameterName':
      {
        const {
          index,
          name
        } = action;
        return external_immer_default()(state, draft => {
          draft.config.tokenParameters[index].name = name;
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'setTokenParameterType':
      {
        const {
          index,
          tokenType
        } = action;
        return external_immer_default()(state, draft => {
          draft.config.tokenParameters[index].type = tokenType;
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'addTokenParameter':
      {
        return external_immer_default()(state, draft => {
          draft.config.tokenParameters.push({
            name: 'param' + draft.config.tokenParameters.length,
            type: 'uint256'
          });
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'removeTokenParameter':
      {
        const {
          index
        } = action;
        return external_immer_default()(state, draft => {
          draft.config.tokenParameters.splice(index, 1);
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'moveTokenParameter':
      {
        const {
          sourceIndex,
          destinationIndex
        } = action;
        return external_immer_default()(state, draft => {
          moveArrayItem(draft.config.tokenParameters, sourceIndex, destinationIndex);
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'setAmountAllowedForOwner':
    case 'setAllowlistDestinationAddress':
    case 'setAllowlistDestinationAmount':
    case 'addAllowlistDestination':
    case 'removeAllowlistDestination':
    case 'moveAllowlistDestination':
      {
        return external_immer_default()(state, draft => {
          draft.config = allowlistReducer(state.config, action);
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'setPayoutDestinationAddress':
    case 'setPayoutDestinationAmount':
    case 'addPayoutDestination':
    case 'removePayoutDestination':
    case 'movePayoutDestination':
      {
        return external_immer_default()(state, draft => {
          draft.config = payoutReducer(state.config, action);
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }

    case 'setTokenName':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            tokenName: value
          })
        }, resetForConfigChange);
      }

    case 'setShortName':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            shortName: value
          })
        }, resetForConfigChange);
      }

    case 'setTokenURI':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            tokenURI: value
          })
        }, resetForConfigChange);
      }

    case 'setContractURI':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            contractURI: value
          })
        }, resetForConfigChange);
      }

    case 'setSupply':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            supply: value
          })
        }, resetForConfigChange);
      }

    case 'setMultiMint':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            multimint: value
          })
        }, resetForConfigChange);
      }

    case 'setMintingLimitPerWallet':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            limitPerWallet: value
          })
        }, resetForConfigChange);
      }

    case 'setPrice':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            price: value
          })
        }, resetForConfigChange);
      }

    case 'setRoyaltyBps':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            royaltyBps: value
          })
        }, resetForConfigChange);
      }

    case 'setActivateAutomatically':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            activateAutomatically: value
          })
        }, resetForConfigChange);
      }

    case 'setEnumerable':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            enumerable: value
          })
        }, resetForConfigChange);
      }

    case 'setOnlyOwnerCanMint':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            onlyOwnerCanMint: value
          })
        }, resetForConfigChange);
      }

    case 'setUsesUriStorage':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            usesUriStorage: value
          })
        }, resetForConfigChange);
      }

    case 'setUsesIdParameter':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            usesIdParameter: value
          })
        }, resetForConfigChange);
      }

    case 'setCustomMaxTokenId':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            customMaxTokenId: value
          })
        }, resetForConfigChange);
      }

    case 'setAccessToken':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            requireAccessToken: value
          })
        }, resetForConfigChange);
      }

    case 'setToggleAccessToken':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            toggleAccessToken: value
          })
        }, resetForConfigChange);
      }

    case 'setMutableAccessToken':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            mutableAccessToken: value
          })
        }, resetForConfigChange);
      }

    case 'setApprovalProxyAddress':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          config: _objectSpread(_objectSpread({}, state.config), {}, {
            approvalProxyAddress: value
          })
        }, resetForConfigChange);
      }

    case 'downloadFiles':
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          compiler: {
            type: 'downloading'
          }
        });
      }

    case 'setCompilerReady':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          compiler: {
            type: 'ready',
            files: value
          }
        });
      }

    case 'setCompilerDone':
      {
        const {
          value,
          contractName,
          sourceName
        } = action;
        if (state.compiler.type !== 'ready') return state;

        if ('errors' in value) {
          return _objectSpread(_objectSpread({}, state), {}, {
            compiler: {
              type: 'error',
              errors: value.errors
            }
          });
        }

        return _objectSpread(_objectSpread({}, state), {}, {
          compiler: {
            type: 'done',
            contracts: value.contracts,
            files: state.compiler.files,
            sourceName,
            contractName
          }
        });
      }

    case 'setDeploying':
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          deployment: {
            type: 'deploying'
          }
        });
      }

    case 'deployFailure':
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          deployment: {
            type: 'notStarted'
          }
        });
      }

    case 'setDeploymentAddress':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          deployment: {
            type: 'deployed',
            address: value
          }
        });
      }

    case 'setEtherscanApiKey':
      {
        const {
          value
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          apiKeys: _objectSpread(_objectSpread({}, state.apiKeys), {}, {
            etherscan: value
          })
        });
      }

    case 'setVerifying':
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          verification: {
            type: 'verifying'
          }
        });
      }

    case 'setVerified':
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          verification: {
            type: 'verified'
          }
        });
      }

    case 'setVerificationFailed':
      {
        const {
          error
        } = action;
        return _objectSpread(_objectSpread({}, state), {}, {
          verification: {
            type: 'notStarted',
            previousError: error
          }
        });
      }

    case 'setUsesDelegatedContract':
      {
        const {
          value
        } = action;
        return external_immer_default()(state, draft => {
          draft.config.usesDelegatedContract = value;
          draft.config.enumerable = false;
          draft.config.approvalProxyAddress = undefined;
          draft.compiler = resetForConfigChange.compiler;
          draft.deployment = resetForConfigChange.deployment;
        });
      }
  }
}
function moveArrayItem(array, sourceIndex, destinationIndex) {
  const sourceItem = array[sourceIndex];
  array.splice(sourceIndex, 1);
  array.splice(sourceIndex < destinationIndex ? destinationIndex - 1 : destinationIndex, 0, sourceItem);
}

/***/ }),

/***/ 8878:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ historyReducer),
/* harmony export */   "f": () => (/* binding */ createInitialHistoryState)
/* harmony export */ });
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7133);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(immer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _collectionReducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_collectionReducer__WEBPACK_IMPORTED_MODULE_1__]);
_collectionReducer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const FILE_CHANGED_TIMEOUT = 300;
function historyReducer(state, action) {
  const currentState = state.present;

  switch (action.type) {
    case 'setFileHandle':
      {
        const newState = createInitialHistoryState();
        newState.present = (0,_collectionReducer__WEBPACK_IMPORTED_MODULE_1__/* .collectionReducer */ .Eu)(currentState, action);
        return newState;
      }

    case 'undo':
      if (state.past.length === 0) {
        return state;
      } else {
        return immer__WEBPACK_IMPORTED_MODULE_0___default()(state, draft => {
          const nextPresent = draft.past.pop();

          if (nextPresent) {
            draft.future.unshift(createHistoryEntry(nextPresent.actionType, currentState));
            draft.present = nextPresent.state;
          }
        });
      }

    case 'redo':
      if (state.future.length === 0) {
        return state;
      } else {
        return immer__WEBPACK_IMPORTED_MODULE_0___default()(state, draft => {
          const nextPresent = draft.future.shift();

          if (nextPresent) {
            draft.past.push(createHistoryEntry(nextPresent.actionType, currentState));
            draft.present = nextPresent.state;
          }
        });
      }

    default:
      const nextState = (0,_collectionReducer__WEBPACK_IMPORTED_MODULE_1__/* .collectionReducer */ .Eu)(currentState, action);
      const mergableEntry = getMergableHistoryEntry(state, action.type);
      const changed = currentState.volume !== nextState.volume;
      return immer__WEBPACK_IMPORTED_MODULE_0___default()(state, draft => {
        const historyEntry = createHistoryEntry(action.type, currentState);

        if (changed && !action.type.includes('*')) {
          if (mergableEntry) {
            draft.past[draft.past.length - 1] = _objectSpread(_objectSpread({}, historyEntry), {}, {
              state: mergableEntry.state
            });
          } else {
            draft.past.push(historyEntry);
          }

          draft.future = [];
        }

        draft.present = nextState;
      });
  }
}
function createInitialHistoryState() {
  return {
    past: [],
    present: (0,_collectionReducer__WEBPACK_IMPORTED_MODULE_1__/* .createInitialCollectionState */ .cq)(),
    future: []
  };
}

function createHistoryEntry(actionType, state) {
  return {
    actionType,
    state,
    timestamp: Date.now()
  };
}

function getMergableHistoryEntry(state, actionType) {
  if (state.past.length === 0) {
    return;
  }

  const newTimestamp = Date.now();
  const previousEntry = state.past[state.past.length - 1];

  if (actionType !== previousEntry.actionType || newTimestamp - previousEntry.timestamp > FILE_CHANGED_TIMEOUT) {
    return;
  }

  return previousEntry;
}
});

/***/ }),

/***/ 8531:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uF": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.uF),
/* harmony export */   "be": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.be),
/* harmony export */   "P_": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.P_),
/* harmony export */   "PA": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.PA),
/* harmony export */   "J9": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.J9),
/* harmony export */   "aC": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.aC),
/* harmony export */   "I6": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.I6),
/* harmony export */   "e3": () => (/* reexport safe */ _contractReducer__WEBPACK_IMPORTED_MODULE_0__.e3),
/* harmony export */   "P0": () => (/* reexport safe */ _collectionReducer__WEBPACK_IMPORTED_MODULE_1__.P0),
/* harmony export */   "fL": () => (/* reexport safe */ _historyReducer__WEBPACK_IMPORTED_MODULE_2__.f),
/* harmony export */   "Oo": () => (/* reexport safe */ _historyReducer__WEBPACK_IMPORTED_MODULE_2__.O),
/* harmony export */   "FV": () => (/* reexport safe */ _mintStateReducer__WEBPACK_IMPORTED_MODULE_3__.F),
/* harmony export */   "l2": () => (/* reexport safe */ _mintStyleReducer__WEBPACK_IMPORTED_MODULE_4__.l2),
/* harmony export */   "pG": () => (/* reexport safe */ _mintStyleReducer__WEBPACK_IMPORTED_MODULE_4__.pG),
/* harmony export */   "VT": () => (/* reexport safe */ _mintStyleReducer__WEBPACK_IMPORTED_MODULE_4__.VT),
/* harmony export */   "JY": () => (/* reexport safe */ _mintStyleReducer__WEBPACK_IMPORTED_MODULE_4__.JY),
/* harmony export */   "CJ": () => (/* reexport safe */ _publishingReducer__WEBPACK_IMPORTED_MODULE_5__.C)
/* harmony export */ });
/* harmony import */ var _contractReducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6421);
/* harmony import */ var _collectionReducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8997);
/* harmony import */ var _historyReducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8878);
/* harmony import */ var _mintStateReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3137);
/* harmony import */ var _mintStyleReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9700);
/* harmony import */ var _publishingReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9768);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_historyReducer__WEBPACK_IMPORTED_MODULE_2__, _collectionReducer__WEBPACK_IMPORTED_MODULE_1__]);
([_historyReducer__WEBPACK_IMPORTED_MODULE_2__, _collectionReducer__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






});

/***/ }),

/***/ 3137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ mintStateReducer)
/* harmony export */ });
function mintStateReducer(state, action) {
  switch (action.type) {
    case 'mint':
      return {
        type: 'minting'
      };

    case 'reset':
      return {
        type: 'ready'
      };

    case 'success':
      return {
        type: 'success',
        tokenIds: action.tokenIds
      };

    case 'failure':
      return {
        type: 'failure',
        message: action.message,
        reason: action.reason
      };
  }
}

/***/ }),

/***/ 9700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l2": () => (/* binding */ DEFAULT_FUNCTION_NAME),
/* harmony export */   "pG": () => (/* binding */ DEFAULT_PARAMETER_NAME),
/* harmony export */   "JY": () => (/* binding */ mintStyleReducer),
/* harmony export */   "VT": () => (/* binding */ createInitialMintStyle)
/* harmony export */ });
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7133);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(immer__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const DEFAULT_FUNCTION_NAME = {
  PRICE: 'PRICE',
  MAX_SUPPLY: 'MAX_SUPPLY',
  MAX_MULTIMINT: 'MAX_MULTIMINT',
  totalSupply: 'totalSupply',
  saleIsActive: 'saleIsActive',
  mint: 'mint'
};
const DEFAULT_PARAMETER_NAME = {
  mint: {
    count: 'count'
  }
};
function mintStyleReducer(state, action) {
  switch (action.type) {
    case 'setContractAddress':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.contractAddress = action.value;
      });

    case 'setChainId':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.chainId = action.value;
      });

    case 'setCreatorAddress':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.creatorAddress = action.value;
      });

    case 'setBackground':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.background = action.value;
      });

    case 'setCardBackground':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.cardBackground = action.value;
      });

    case 'setTitle':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.title = action.value;
      });

    case 'setDescription':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.description = action.value;
      });

    case 'setCoverAsset':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.coverAsset = action.value;
      });

    case 'setCoverAssetType':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.coverAsset.type = action.value;

        if (action.value === 'none') {
          draft.coverAsset.url = '';
          draft.coverAsset.size = {
            width: '',
            height: ''
          };
        }
      });

    case 'setCoverAssetUrl':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.coverAsset.url = action.value;
      });

    case 'setCoverAssetWidth':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.coverAsset.size.width = action.value;
      });

    case 'setCoverAssetHeight':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.coverAsset.size.height = action.value;
      });

    case 'setPriceFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.price.name = action.value;
      });

    case 'setTotalSupplyFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.totalSupply.name = action.value;
      });

    case 'setMaxSupplyFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.MAX_SUPPLY.name = action.value;
      });

    case 'setSaleIsActiveFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.saleIsActive.name = action.value;
      });

    case 'setSaleIsActiveEnabled':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.saleIsActive.disabled = !action.value;
      });

    case 'setMaxMultimintFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.MAX_MULTIMINT.name = action.value;
      });

    case 'setMintFunctionName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.mint.name = action.value;
      });

    case 'setMintCountParameterName':
      return immer__WEBPACK_IMPORTED_MODULE_1___default()(state, draft => {
        draft.dataSources.mint.parameters.count = action.value;
      });
  }
}

const legacyChainNameToId = name => {
  switch (name) {
    case 'rinkeby':
      return _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.RINKEBY;

    case 'mainnet':
      return _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.MAINNET;
  }
};

function createInitialMintStyle(partial) {
  var _partial$dataSources, _partial$dataSources2, _partial$dataSources3, _partial$dataSources4, _partial$dataSources5, _partial$dataSources6, _partial$dataSources7, _partial$dataSources8;

  const legacyChainName = partial && 'chainName' in partial ? partial.chainName : undefined;

  const result = _objectSpread(_objectSpread(_objectSpread({
    contractAddress: '',
    background: '#1c1c1c',
    cardBackground: '#282828',
    description: ''
  }, partial), legacyChainName ? {
    chainId: legacyChainNameToId(legacyChainName)
  } : {}), {}, {
    coverAsset: _objectSpread({
      type: 'none',
      url: '',
      size: {
        width: '',
        height: ''
      }
    }, partial === null || partial === void 0 ? void 0 : partial.coverAsset),
    dataSources: {
      price: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.PRICE
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources = partial.dataSources) === null || _partial$dataSources === void 0 ? void 0 : _partial$dataSources.price),
      totalSupply: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.totalSupply
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources2 = partial.dataSources) === null || _partial$dataSources2 === void 0 ? void 0 : _partial$dataSources2.totalSupply),
      saleIsActive: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.saleIsActive
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources3 = partial.dataSources) === null || _partial$dataSources3 === void 0 ? void 0 : _partial$dataSources3.saleIsActive),
      MAX_MULTIMINT: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.MAX_MULTIMINT
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources4 = partial.dataSources) === null || _partial$dataSources4 === void 0 ? void 0 : _partial$dataSources4.MAX_MULTIMINT),
      MAX_SUPPLY: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.MAX_SUPPLY
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources5 = partial.dataSources) === null || _partial$dataSources5 === void 0 ? void 0 : _partial$dataSources5.MAX_SUPPLY),
      mint: _objectSpread({
        name: DEFAULT_FUNCTION_NAME.mint,
        parameters: _objectSpread({
          count: DEFAULT_PARAMETER_NAME.mint.count
        }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources6 = partial.dataSources) === null || _partial$dataSources6 === void 0 ? void 0 : (_partial$dataSources7 = _partial$dataSources6.mint) === null || _partial$dataSources7 === void 0 ? void 0 : _partial$dataSources7.parameters)
      }, partial === null || partial === void 0 ? void 0 : (_partial$dataSources8 = partial.dataSources) === null || _partial$dataSources8 === void 0 ? void 0 : _partial$dataSources8.mint)
    }
  }); // Delete legacy chainName


  delete result.chainName;
  return result;
}

/***/ }),

/***/ 9768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ publishingStateReducer)
/* harmony export */ });
function publishingStateReducer(state, action) {
  var _action$rootAssetsCID;

  switch (action.type) {
    case 'reset':
      return {
        type: 'ready'
      };

    case 'setUploadingAssets':
      return {
        type: 'uploadingAssets',
        value: action.value
      };

    case 'setUploadingMetadata':
      return {
        type: 'uploadingMetadata',
        value: action.value,
        rootAssetsCID: (_action$rootAssetsCID = action.rootAssetsCID) !== null && _action$rootAssetsCID !== void 0 ? _action$rootAssetsCID : state.type === 'uploadingMetadata' ? state.rootAssetsCID : undefined
      };
  }
}

/***/ }),

/***/ 9772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "bf": () => (/* reexport */ getBlockExplorerName),
  "Ui": () => (/* reexport */ getEtherActorBaseURL),
  "YU": () => (/* reexport */ getEtherscanAddressUrl),
  "y5": () => (/* reexport */ getEtherscanApiUrl),
  "TN": () => (/* reexport */ getOpenSeaUrl),
  "nq": () => (/* reexport */ getProxyAddress),
  "_4": () => (/* reexport */ isMainnetOrPolygon),
  "xA": () => (/* reexport */ populateTemplateMetadata)
});

// EXTERNAL MODULE: external "@openpalette/contract"
var contract_ = __webpack_require__(4008);
;// CONCATENATED MODULE: ../web3-utils/src/etherActor.ts

function getEtherActorBaseURL(chainId) {
  const prefix = chainId !== contract_.CHAIN_ID.MAINNET ? `${(0,contract_.getChainName)(chainId)}.` : '';
  return `https://${prefix}ether.actor`;
}
;// CONCATENATED MODULE: ../web3-utils/src/etherscan.ts

function isMainnetOrPolygon(chainId) {
  return chainId === contract_.CHAIN_ID.MAINNET || chainId === contract_.CHAIN_ID.POLYGON;
}

function getHost(chainId) {
  switch (chainId) {
    case contract_.CHAIN_ID.POLYGON:
    case contract_.CHAIN_ID.MUMBAI:
      return `polygonscan.com`;

    default:
      return `etherscan.io`;
  }
}

function getBlockExplorerName(chainId) {
  switch (chainId) {
    case contract_.CHAIN_ID.POLYGON:
    case contract_.CHAIN_ID.MUMBAI:
      return `Polygonscan`;

    default:
      return `Etherscan`;
  }
}
function getEtherscanAddressUrl(chainId, address) {
  const prefix = !isMainnetOrPolygon(chainId) ? `${(0,contract_.getChainName)(chainId)}.` : '';
  return `https://${prefix}${getHost(chainId)}/address/${address}`;
}
function getEtherscanApiUrl(chainId) {
  const prefix = !isMainnetOrPolygon(chainId) ? `api-${(0,contract_.getChainName)(chainId)}` : 'api';
  return `https://${prefix}.${getHost(chainId)}/api`;
}
// EXTERNAL MODULE: ../utils/src/index.ts + 17 modules
var src = __webpack_require__(6221);
;// CONCATENATED MODULE: ../web3-utils/src/openSea.ts



function getOpenSeaUrl(chainId, contractAddress, index) {
  const prefix = !isMainnetOrPolygon(chainId) ? `testnets.` : '';
  const chainName = chainId === contract_.CHAIN_ID.POLYGON || chainId === contract_.CHAIN_ID.MUMBAI ? 'matic/' : '';
  return `https://${prefix}opensea.io/assets/${chainName}${contractAddress}/${index}`;
}
const proxyAddressMap = {
  [contract_.CHAIN_ID.MAINNET]: (0,contract_.createAddress)('0xa5409ec958c83c3f309868babaca7c86dcb077c1'),
  [contract_.CHAIN_ID.RINKEBY]: (0,contract_.createAddress)('0xf57b2c51ded3a29e6891aba85459d600256cf317'),
  [contract_.CHAIN_ID.ROPSTEN]: (0,contract_.createAddress)(src.NullAddress),
  [contract_.CHAIN_ID.GOERLI]: (0,contract_.createAddress)(src.NullAddress),
  [contract_.CHAIN_ID.POLYGON]: (0,contract_.createAddress)(src.NullAddress),
  [contract_.CHAIN_ID.MUMBAI]: (0,contract_.createAddress)(src.NullAddress)
};
function getProxyAddress(chainId) {
  return proxyAddressMap[chainId];
}
// EXTERNAL MODULE: ../solidity-codegen/src/index.ts + 15 modules
var solidity_codegen_src = __webpack_require__(656);
;// CONCATENATED MODULE: ../web3-utils/src/nftMetadata.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


function populateTemplateMetadata(metadata, parameters) {
  return _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, metadata), metadata.name !== undefined && {
    name: (0,solidity_codegen_src/* populateTemplate */.E0)(metadata.name, parameters)
  }), metadata.description !== undefined && {
    description: (0,solidity_codegen_src/* populateTemplate */.E0)(metadata.description, parameters)
  }), metadata.image !== undefined && {
    image: (0,solidity_codegen_src/* populateTemplate */.E0)(metadata.image, parameters)
  }), metadata.external_url !== undefined && {
    external_url: (0,solidity_codegen_src/* populateTemplate */.E0)(metadata.external_url, parameters)
  }), metadata.animation_url !== undefined && {
    animation_url: (0,solidity_codegen_src/* populateTemplate */.E0)(metadata.animation_url, parameters)
  });
}
;// CONCATENATED MODULE: ../web3-utils/src/index.ts





/***/ })

};
;
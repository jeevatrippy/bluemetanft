"use strict";
exports.id = 254;
exports.ids = [254];
exports.modules = {

/***/ 2060:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ socialConfig)
/* harmony export */ });
const socialConfig = {
  title: 'Studio 721',
  location: {
    host: 'www.721.so'
  },
  author: {
    twitter: 'dvnabbott'
  },
  favicons: [{
    type: 'image/x-icon',
    path: '/favicon.ico'
  }],
  previewImage: {
    type: 'image/png',
    width: '1200',
    height: '630',
    alt: 'Studio 721',
    path: '/studio-721-preview-card.png'
  }
};

/***/ }),

/***/ 9504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ JavascriptPlaygrounds)
/* harmony export */ });
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9615);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3922);
/* harmony import */ var imfs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(imfs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var javascript_playgrounds__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3431);
/* harmony import */ var javascript_playgrounds__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(javascript_playgrounds__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const workspaceCSS = `
/*
  Name:       material
  Author:     Mattia Astorino (http://github.com/equinusocio)
  Website:    https://material-theme.site/
*/

.cm-s-react.CodeMirror {
  background-color: #1c1c1c;
  color: #EEFFFF;
}

.cm-s-react .CodeMirror-gutters {
  background: #1c1c1c;
  color: #545454;
  border: none;
}

.cm-s-react .CodeMirror-guttermarker,
.cm-s-react .CodeMirror-guttermarker-subtle,
.cm-s-react .CodeMirror-linenumber {
  color: #545454;
}

.cm-s-react .CodeMirror-cursor {
  border-left: 1px solid #FFCC00;
}

.cm-s-react div.CodeMirror-selected {
  background: rgba(4, 116, 255, 0.35);
}

.cm-s-react.CodeMirror-focused div.CodeMirror-selected {
  background: rgba(4, 116, 255, 0.35);
}

.cm-s-react .CodeMirror-line::selection,
.cm-s-react .CodeMirror-line>span::selection,
.cm-s-react .CodeMirror-line>span>span::selection {
  background: rgba(128, 203, 196, 0.2);
}

.cm-s-react .CodeMirror-line::-moz-selection,
.cm-s-react .CodeMirror-line>span::-moz-selection,
.cm-s-react .CodeMirror-line>span>span::-moz-selection {
  background: rgba(128, 203, 196, 0.2);
}

.cm-s-react .CodeMirror-activeline-background {
  background: rgba(0, 0, 0, 0.5);
}

.cm-s-react span.cm-keyword {
  color: #C792EA;
}

.cm-s-react span.cm-operator {
  color: #89DDFF;
}

.cm-s-react span.cm-variable-2 {
  color: #EEFFFF;
}

.cm-s-react span.cm-variable-3,
.cm-s-react span.cm-type {
  color: #f07178;
}

.cm-s-react span.cm-builtin {
  color: #FFCB6B;
}

.cm-s-react span.cm-atom {
  color: #F78C6C;
}

.cm-s-react span.cm-number {
  color: #FF5370;
}

.cm-s-react span.cm-def {
  color: #82AAFF;
}

.cm-s-react span.cm-string {
  color: #C3E88D;
}

.cm-s-react span.cm-string-2 {
  color: #f07178;
}

.cm-s-react span.cm-comment {
  color: #545454;
}

.cm-s-react span.cm-variable {
  color: #f07178;
}

.cm-s-react span.cm-tag {
  color: #FF5370;
}

.cm-s-react span.cm-meta {
  color: #FFCB6B;
}

.cm-s-react span.cm-attribute {
  color: #C792EA;
}

.cm-s-react span.cm-property {
  color: #C792EA;
}

.cm-s-react span.cm-qualifier {
  color: #DECB6B;
}

.cm-s-react span.cm-variable-3,
.cm-s-react span.cm-type {
  color: #DECB6B;
}


.cm-s-react span.cm-error {
  color: rgba(255, 255, 255, 1.0);
  background-color: #FF5370;
}

.cm-s-react .CodeMirror-matchingbracket {
  text-decoration: underline;
  color: white !important;
}

.cm-s-react .cm-line-error {
  background-color: #740000;
}

@keyframes cm-line-warning {
  0% {
    background-color: #1c1c1c;
  }
  66% {
    background-color: #1c1c1c;
  }
  100% {
    background-color: #740000;
  }
}
`;
function JavascriptPlaygrounds({
  entry,
  files,
  playerPane,
  onChangeFile
}) {
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!onChangeFile) return;

    const handler = event => {
      if (event.origin !== 'https://unpkg.com') return;
      const data = JSON.parse(event.data);

      if (data.files) {
        Object.entries(data.files).forEach(([name, source]) => {
          if (files[name] === source) return;
          onChangeFile(name, source);
        });
      }
    };

    window.addEventListener('message', handler);
    return () => {
      window.removeEventListener('message', handler);
    };
  }, [files, onChangeFile]);
  const theme = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .VStack */ .gC, {
    flex: "1",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .VStack */ .gC, {
      position: "relative",
      flex: "1",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components__WEBPACK_IMPORTED_MODULE_0__/* .VStack */ .gC, {
        position: "absolute",
        inset: "0",
        overflow: "hidden",
        alignItems: "center",
        justifyContent: "center",
        background: "white",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx((javascript_playgrounds__WEBPACK_IMPORTED_MODULE_2___default()), _objectSpread(_objectSpread({
          targetOrigin: "*",
          _css: workspaceCSS,
          preset: "html",
          entry: entry
        }, playerPane === 'full' && Object.keys(files).length === 1 ? {
          title: imfs__WEBPACK_IMPORTED_MODULE_1__.path.basename(entry)
        } : {}), {}, {
          files: files,
          reloadMode: "hard",
          fullscreen: true,
          compiler: {
            type: playerPane === 'full' ? 'babel' : 'none'
          },
          playground: {
            enabled: false
          },
          panes: ['editor', ...(playerPane !== 'none' ? [{
            id: 'player',
            type: 'player',
            platform: 'web',
            reloadable: true,
            title: 'Live Preview',
            style: playerPane === 'hidden' ? {
              width: 0
            } : {
              flex: '1'
            },
            console: {
              collapsible: true,
              maximized: false,
              renderReactElements: false,
              showFileName: true,
              showLineNumber: true,
              visible: false
            }
          }] : [])],
          style: {
            width: '100%',
            height: '100%',
            background: '#1c1c1c'
          },
          styles: {
            tab: {
              backgroundColor: '#1c1c1c'
            },
            header: {
              backgroundColor: '#1c1c1c'
            },
            playerHeader: {
              backgroundColor: '#1c1c1c'
            },
            tabTextActive: {
              borderBottom: `3px solid ${theme.colors.primary}`
            },
            status: _objectSpread(_objectSpread({}, playerPane !== 'full' && {
              display: 'none'
            }), {}, {
              backgroundColor: '#1c1c1c',
              borderTop: '1px solid black',
              borderLeft: 'none'
            }),
            consolePane: {
              backgroundColor: '#555',
              borderTop: '1px solid black',
              borderLeft: 'none'
            },
            consoleRow: {
              boxShadow: 'rgb(0, 0, 0, 25%) 0px -1px 0px 0px inset'
            }
          }
        }))
      })
    })
  });
}

/***/ })

};
;
exports.id = 615;
exports.ids = [615];
exports.modules = {

/***/ 9615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "qj": () => (/* reexport */ AutoSizer),
  "V6": () => (/* reexport */ Blockquote),
  "uT": () => (/* reexport */ Body),
  "zx": () => (/* reexport */ Button),
  "Fj": () => (/* reexport */ Caret),
  "XZ": () => (/* reexport */ Checkbox),
  "EK": () => (/* reexport */ Code),
  "P4": () => (/* reexport */ CodeHighlight),
  "NL": () => (/* reexport */ ConnectButton),
  "Vn": () => (/* reexport */ ConnectionDisplay),
  "Vq": () => (/* reexport */ Dialog),
  "ds": () => (/* reexport */ DiscordLogoIcon),
  "iz": () => (/* reexport */ Divider),
  "$2": () => (/* reexport */ EditableTextArea),
  "Q1": () => (/* reexport */ FileDropTarget),
  "RO": () => (/* reexport */ FolderIcon),
  "p7": () => (/* reexport */ FormRow),
  "S6": () => (/* reexport */ FormRowError),
  "hj": () => (/* reexport */ FormSection),
  "Ug": () => (/* reexport */ Stack_HStack),
  "nL": () => (/* reexport */ Heading1),
  "XJ": () => (/* reexport */ Heading2),
  "aC": () => (/* reexport */ Heading3),
  "zs": () => (/* reexport */ HoverCard),
  "No": () => (/* reexport */ InfoHoverCard),
  "__": () => (/* reexport */ Text_Label),
  "lE": () => (/* reexport */ LinkChip),
  "OL": () => (/* reexport */ NavLink),
  "CT": () => (/* reexport */ OpenSeaLogoIcon),
  "FE": () => (/* reexport */ Regular),
  "nq": () => (/* reexport */ ScrollableStack),
  "x4": () => (/* reexport */ Small),
  "lC": () => (/* reexport */ SpacerHorizontal),
  "Nw": () => (/* reexport */ SpacerVertical),
  "S4": () => (/* reexport */ TwitterChip),
  "S3": () => (/* reexport */ TwitterLogoIcon),
  "gC": () => (/* reexport */ Stack_VStack),
  "$K": () => (/* reexport */ VirtualizedGrid),
  "Bm": () => (/* reexport */ getHeadTags)
});

// UNUSED EXPORTS: Chip, InputField, Italic, ListItem, OrderedList, Tabs, Text, UnorderedList, formatDisplayAddress, isSupportedFile

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ../hooks/src/index.ts + 6 modules
var src = __webpack_require__(5781);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ../components/src/AutoSizer.tsx





const Container = external_styled_components_default().div.withConfig({
  displayName: "AutoSizer__Container",
  componentId: "sc-1tevv3u-0"
})({
  display: 'flex',
  flex: '1 0 0',
  flexDirection: 'column'
});
const AutoSizer = /*#__PURE__*/(0,external_react_.memo)(function AutoSizer({
  children
}) {
  const containerRef = (0,external_react_.useRef)(null);
  const containerSize = (0,src/* useSize */.tH)(containerRef);
  return /*#__PURE__*/jsx_runtime_.jsx(Container, {
    ref: containerRef,
    children: containerSize && containerSize.width > 0 && containerSize.height > 0 && children(containerSize)
  });
});
;// CONCATENATED MODULE: ../components/src/Blockquote.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Blockquote = external_styled_components_default().blockquote.withConfig({
  displayName: "Blockquote",
  componentId: "sc-19a5nvt-0"
})(({
  theme
}) => _objectSpread(_objectSpread({}, theme.textStyles.body), {}, {
  backgroundColor: "rgba(255,255,255,0.1)",
  borderLeft: `4px solid ${theme.colors.primaryMuted}`,
  padding: "8px 12px",
  marginBottom: "12px"
}));
;// CONCATENATED MODULE: ../components/src/Spacer.tsx
function Spacer_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Spacer_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Spacer_ownKeys(Object(source), true).forEach(function (key) { Spacer_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Spacer_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Spacer_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* ----------------------------------------------------------------------------
 * Vertical
 * ------------------------------------------------------------------------- */
const SpacerVertical = ({
  size,
  inline
}) => {
  const Element = inline ? 'span' : 'div';
  const style = (0,external_react_.useMemo)(() => Spacer_objectSpread({
    display: inline ? 'inline-block' : 'block'
  }, size === undefined ? {
    flex: 1
  } : {
    minHeight: size,
    height: size,
    maxHeight: size
  }), [inline, size]);
  return /*#__PURE__*/jsx_runtime_.jsx(Element, {
    style: style
  });
}; // /* ----------------------------------------------------------------------------
//  * Horizontal
//  * ------------------------------------------------------------------------- */

const SpacerHorizontal = ({
  size,
  inline
}) => {
  const Element = inline ? 'span' : 'div';
  const style = (0,external_react_.useMemo)(() => Spacer_objectSpread({
    display: inline ? 'inline-block' : 'block'
  }, size === undefined ? {
    flex: 1
  } : {
    minWidth: size,
    width: size,
    maxWidth: size
  }), [inline, size]);
  return /*#__PURE__*/jsx_runtime_.jsx(Element, {
    style: style
  });
};
// EXTERNAL MODULE: ../utils/src/index.ts + 17 modules
var utils_src = __webpack_require__(6221);
;// CONCATENATED MODULE: ../components/src/Text.tsx
const _excluded = ["as", "variant", "breakpoints", "children", "className"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function Text_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Text_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Text_ownKeys(Object(source), true).forEach(function (key) { Text_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Text_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Text_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Text_elements = {
  heading1: 'h1',
  heading2: 'h2',
  heading3: 'h3',
  body: 'p',
  small: 'span',
  regular: 'span',
  label: 'span'
};
const StyledElement = external_styled_components_default().span.withConfig({
  displayName: "Text__StyledElement",
  componentId: "sc-1wwwc24-0"
})(({
  theme,
  variant,
  styleProps,
  breakpoints
}) => Text_objectSpread(Text_objectSpread(Text_objectSpread({}, theme.textStyles[variant]), styleProps), (0,utils_src.mergeBreakpoints)(breakpoints || [])));
const Text = /*#__PURE__*/(0,external_react_.forwardRef)(function Text(_ref, forwardedRef) {
  var _ref2;

  let {
    as,
    variant,
    breakpoints,
    children,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const element = (_ref2 = as !== null && as !== void 0 ? as : Text_elements[variant]) !== null && _ref2 !== void 0 ? _ref2 : 'span';
  return /*#__PURE__*/jsx_runtime_.jsx(StyledElement, {
    ref: forwardedRef,
    as: element,
    className: className,
    variant: variant,
    breakpoints: breakpoints,
    styleProps: rest,
    children: children
  });
});
const Heading1 = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "heading1"
})));
const Heading2 = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "heading2"
})));
const Heading3 = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "heading3"
})));
const Body = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "body"
})));
const Regular = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "regular"
})));
const Small = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "small"
})));
const Text_Label = /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Text, Text_objectSpread(Text_objectSpread({
  ref: ref
}, props), {}, {
  variant: "label"
})));
const Italic = ({
  children
}) => /*#__PURE__*/_jsx("span", {
  style: {
    fontStyle: 'italic'
  },
  children: children
});
;// CONCATENATED MODULE: ../components/src/Button.tsx
function Button_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Button_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Button_ownKeys(Object(source), true).forEach(function (key) { Button_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Button_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Button_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const Button_Container = external_styled_components_default().button.withConfig({
  displayName: "Button__Container",
  componentId: "sc-1i8y9z7-0"
})(({
  theme,
  disabled,
  variant
}) => ({
  appearance: 'none',
  padding: variant === 'header' ? '4px 8px' : variant === 'thin' ? '0 16px' : variant === 'medium' ? '8px 12px' : '12px 16px',
  // background: "#7a6af7",
  background: disabled ? '#444' : 'linear-gradient(45deg, #7a6af7, #bb47bb)',
  border: disabled ? '1px solid #555' : undefined,
  borderRadius: '4px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontWeight: 500,
  cursor: 'pointer',
  userSelect: 'none'
}));
const CaretContainer = external_styled_components_default().span.withConfig({
  displayName: "Button__CaretContainer",
  componentId: "sc-1i8y9z7-1"
})({
  backgroundColor: 'rgba(255, 255, 255, 0.2)',
  height: '24px',
  width: '24px',
  borderRadius: '50%',
  cursor: 'pointer',
  userSelect: 'none',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center'
});
function Button({
  as,
  children,
  onClick,
  disabled,
  showsCaret = false,
  variant = 'regular',
  href
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button_Container, Button_objectSpread(Button_objectSpread({
    as: as,
    onClick: onClick,
    disabled: disabled,
    variant: variant
  }, href && {
    href
  }), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Body, Button_objectSpread(Button_objectSpread({
      color: disabled ? '#888' : 'white',
      fontWeight: 600
    }, (variant === 'thin' || variant === 'header') && {
      fontSize: '0.9rem'
    }), {}, {
      children: children
    })), !disabled && showsCaret && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(SpacerHorizontal, {
        size: 8
      }), /*#__PURE__*/jsx_runtime_.jsx(CaretContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Caret, {
          strokeWidth: 3.5,
          color: "white",
          direction: "right"
        })
      })]
    })]
  }));
}
;// CONCATENATED MODULE: ../components/src/Caret.tsx



function getRotation(direction) {
  switch (direction) {
    case 'right':
      return 0;

    case 'down':
      return 90;

    case 'left':
      return 180;

    case 'up':
      return 270;
  }
}

function Caret({
  color,
  direction = 'right',
  size = 14,
  strokeWidth = 2.5
}) {
  const style = (0,external_react_.useMemo)(() => ({
    width: `${size}px`,
    height: `${size}px`
  }), [size]);
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    style: style,
    fill: "none",
    preserveAspectRatio: "xMidYMid meet",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: strokeWidth,
    stroke: color,
    viewBox: "0 0 24 24",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/jsx_runtime_.jsx("polyline", {
      points: "9,6 16,12 9,18",
      transform: `rotate(${getRotation(direction)} 12 12)`
    })
  });
}
// EXTERNAL MODULE: external "@radix-ui/react-checkbox"
var react_checkbox_ = __webpack_require__(7093);
// EXTERNAL MODULE: external "@radix-ui/react-icons"
var react_icons_ = __webpack_require__(2132);
;// CONCATENATED MODULE: ../components/src/Checkbox.tsx
function Checkbox_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Checkbox_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Checkbox_ownKeys(Object(source), true).forEach(function (key) { Checkbox_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Checkbox_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Checkbox_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const StyledCheckbox = external_styled_components_default()(react_checkbox_.Root).withConfig({
  displayName: "Checkbox__StyledCheckbox",
  componentId: "sc-1yzl0rb-0"
})(({
  disabled,
  variant,
  theme
}) => Checkbox_objectSpread(Checkbox_objectSpread({
  all: 'unset',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '4px',
  width: 19,
  height: 19,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  opacity: disabled ? 0.5 : undefined,
  flex: '0 0 auto'
}, variant === 'dark' ? {
  backgroundColor: theme.colors.inputBackground
} : {
  backgroundColor: 'white'
}), {}, {
  '&:hover': {
    boxShadow: 'none'
  },
  '&:focus': {
    // boxShadow: `0 0 0 2px ${theme.colors.primary}`,
    boxShadow: `0 0 0 1px ${theme.colors.sidebar.background}, 0 0 0 3px ${theme.colors.primary}`
  }
}));
const StyledIndicator = external_styled_components_default()(react_checkbox_.Indicator).withConfig({
  displayName: "Checkbox__StyledIndicator",
  componentId: "sc-1yzl0rb-1"
})({
  color: '#7a6af7'
});
function Checkbox({
  disabled,
  checked,
  onCheckedChange,
  variant = 'light'
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(StyledCheckbox, {
    checked: checked,
    onCheckedChange: onCheckedChange,
    disabled: disabled,
    variant: variant,
    children: /*#__PURE__*/jsx_runtime_.jsx(StyledIndicator, {
      children: /*#__PURE__*/jsx_runtime_.jsx(react_icons_.CheckIcon, {
        width: 20,
        height: 20,
        style: {
          position: 'relative',
          top: '1px'
        }
      })
    })
  });
}
;// CONCATENATED MODULE: ../components/src/Chip.tsx
function Chip_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Chip_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Chip_ownKeys(Object(source), true).forEach(function (key) { Chip_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Chip_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Chip_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const Chip = external_styled_components_default().span.withConfig({
  displayName: "Chip",
  componentId: "sc-1v5r7wa-0"
})({
  background: 'rgba(255,255,255,0.1)',
  borderRadius: '4px',
  padding: '4px 6px',
  userSelect: 'none',
  fontSize: 'inherit'
});
function LinkChip({
  children,
  href,
  style,
  openInNewTab
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Chip, Chip_objectSpread(Chip_objectSpread({
    as: "a",
    href: href,
    style: style
  }, openInNewTab && {
    target: '_blank',
    rel: 'noreferrer'
  }), {}, {
    children: [children, openInNewTab ? ' →' : '']
  }));
}
function TwitterChip({
  value,
  openInNewTab = true,
  hasMargin = true
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(LinkChip, {
    href: `https://twitter.com/${value.slice(1)}`,
    style: {
      margin: hasMargin ? '0 2px 0 6px' : '0'
    },
    openInNewTab: openInNewTab,
    children: value
  });
}
// EXTERNAL MODULE: external "prism-react-renderer"
var external_prism_react_renderer_ = __webpack_require__(7096);
var external_prism_react_renderer_default = /*#__PURE__*/__webpack_require__.n(external_prism_react_renderer_);
// EXTERNAL MODULE: external "prism-react-renderer/themes/vsDark"
var vsDark_ = __webpack_require__(4196);
var vsDark_default = /*#__PURE__*/__webpack_require__.n(vsDark_);
;// CONCATENATED MODULE: ../components/src/CodeHighlight.tsx
function CodeHighlight_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function CodeHighlight_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { CodeHighlight_ownKeys(Object(source), true).forEach(function (key) { CodeHighlight_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { CodeHighlight_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function CodeHighlight_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function Code({
  children,
  loading
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(Regular, {
    as: "code",
    className: loading ? 'flickerAnimation' : undefined,
    fontSize: "13px",
    fontWeight: "bold",
    whiteSpace: "pre-wrap",
    wordBreak: "break-all",
    lineHeight: "1.3",
    children: children
  });
}
function CodeHighlight({
  code,
  language
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(Code, {
    children: /*#__PURE__*/jsx_runtime_.jsx((external_prism_react_renderer_default()), CodeHighlight_objectSpread(CodeHighlight_objectSpread({}, external_prism_react_renderer_.defaultProps), {}, {
      theme: (vsDark_default()),
      code: code,
      language: language,
      children: ({
        className,
        style,
        tokens,
        getLineProps,
        getTokenProps
      }) => /*#__PURE__*/jsx_runtime_.jsx("pre", {
        className: className,
        style: style,
        children: tokens.map((line, i) => /*#__PURE__*/jsx_runtime_.jsx("div", CodeHighlight_objectSpread(CodeHighlight_objectSpread({}, getLineProps({
          line,
          key: i
        })), {}, {
          children: line.map((token, key) => /*#__PURE__*/jsx_runtime_.jsx("span", CodeHighlight_objectSpread({}, getTokenProps({
            token,
            key
          })), key))
        }), i))
      })
    }))
  });
}
// EXTERNAL MODULE: ../contexts/src/index.ts + 2 modules
var contexts_src = __webpack_require__(9022);
;// CONCATENATED MODULE: ../components/src/Stack.tsx
const Stack_excluded = ["paddingVertical", "paddingHorizontal"],
      _excluded2 = ["id", "as", "children", "separator", "breakpoints", "href"];

function Stack_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Stack_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Stack_ownKeys(Object(source), true).forEach(function (key) { Stack_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Stack_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Stack_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Stack_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = Stack_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function Stack_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








function normalizeStyleProps(_ref) {
  let {
    paddingVertical,
    paddingHorizontal
  } = _ref,
      rest = Stack_objectWithoutProperties(_ref, Stack_excluded);

  return Stack_objectSpread(Stack_objectSpread(Stack_objectSpread({}, paddingVertical !== undefined && {
    paddingTop: paddingVertical,
    paddingBottom: paddingVertical
  }), paddingHorizontal !== undefined && {
    paddingLeft: paddingHorizontal,
    paddingRight: paddingHorizontal
  }), rest);
}

const Element = external_styled_components_default().div.withConfig({
  displayName: "Stack__Element",
  componentId: "sc-12huu73-0"
})(({
  styleProps,
  breakpoints
}) => Stack_objectSpread(Stack_objectSpread({}, normalizeStyleProps(styleProps)), (0,utils_src.mergeBreakpoints)(breakpoints || [], normalizeStyleProps)));
const Stack = /*#__PURE__*/(0,external_react_.forwardRef)(function Stack(_ref2, forwardedRef) {
  let {
    id,
    as,
    children,
    separator,
    breakpoints,
    href
  } = _ref2,
      rest = Stack_objectWithoutProperties(_ref2, _excluded2);

  const elements = separator ? (0,utils_src.withSeparatorElements)(external_react_.Children.toArray(children), separator) : children;

  const styleProps = Stack_objectSpread({
    display: 'flex',
    position: 'relative',
    flexDirection: 'column',
    alignItems: 'stretch'
  }, rest);

  return /*#__PURE__*/jsx_runtime_.jsx(Element, Stack_objectSpread(Stack_objectSpread({
    ref: forwardedRef,
    id: id,
    as: as,
    styleProps: styleProps,
    breakpoints: breakpoints
  }, href && {
    href
  }), {}, {
    children: elements
  }));
}); // eslint-disable-next-line @typescript-eslint/no-empty-interface

const Stack_VStack = /*#__PURE__*/(0,external_react_.memo)( /*#__PURE__*/(0,external_react_.forwardRef)(function VStack(props, forwardedRef) {
  return /*#__PURE__*/jsx_runtime_.jsx(Stack, Stack_objectSpread(Stack_objectSpread({}, props), {}, {
    flexDirection: "column",
    ref: forwardedRef
  }));
}));
const Stack_HStack = /*#__PURE__*/(0,external_react_.memo)( /*#__PURE__*/(0,external_react_.forwardRef)(function HStack(props, forwardedRef) {
  return /*#__PURE__*/jsx_runtime_.jsx(Stack, Stack_objectSpread(Stack_objectSpread({}, props), {}, {
    flexDirection: "row",
    ref: forwardedRef
  }));
}));
// EXTERNAL MODULE: external "@openpalette/contract"
var contract_ = __webpack_require__(4008);
;// CONCATENATED MODULE: ../components/src/ConnectButton.tsx











function formatDisplayAddress(address) {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}
function ConnectionDisplay() {
  const address = (0,contexts_src/* useAddress */.SF)();
  const chainId = (0,contexts_src/* useChainId */.xx)();
  const {
    disconnect
  } = (0,contexts_src/* useWeb3API */.ry)();
  if (!address) return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
  return /*#__PURE__*/jsx_runtime_.jsx(Stack_HStack, {
    background: "#111",
    paddingHorizontal: 10,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Body, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        style: {
          fontFamily: 'monospace'
        },
        children: [(0,contract_.getChainName)(chainId !== null && chainId !== void 0 ? chainId : contract_.CHAIN_ID.MAINNET), " |", ' ', formatDisplayAddress(address)]
      }), /*#__PURE__*/jsx_runtime_.jsx(SpacerHorizontal, {
        inline: true,
        size: 6
      }), /*#__PURE__*/jsx_runtime_.jsx(react_icons_.Cross2Icon, {
        onClick: disconnect,
        style: {
          cursor: 'pointer',
          position: 'relative',
          top: '1px'
        }
      })]
    })
  });
}
function ConnectButton({
  variant
}) {
  const address = (0,contexts_src/* useAddress */.SF)();
  const {
    connect
  } = (0,contexts_src/* useWeb3API */.ry)();
  return address ? /*#__PURE__*/jsx_runtime_.jsx(ConnectionDisplay, {}) : /*#__PURE__*/jsx_runtime_.jsx(Button, {
    variant: variant,
    onClick: () => {
      connect();
    },
    children: "Connect wallet"
  });
}
// EXTERNAL MODULE: external "@radix-ui/react-dialog"
var react_dialog_ = __webpack_require__(3363);
;// CONCATENATED MODULE: ../components/src/Divider.tsx

const Divider = external_styled_components_default().div.withConfig({
  displayName: "Divider",
  componentId: "sc-vgvmqm-0"
})(({
  variant = "dark"
}) => ({
  height: "1px",
  minHeight: "1px",
  maxHeight: "1px",
  backgroundColor: variant === "dark" ? "rgba(0,0,0,0.4)" : "rgba(255,255,255,0.1)"
}));
;// CONCATENATED MODULE: ../components/src/Dialog.tsx
function Dialog_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Dialog_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dialog_ownKeys(Object(source), true).forEach(function (key) { Dialog_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dialog_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dialog_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const StyledOverlay = external_styled_components_default()(react_dialog_.Overlay).withConfig({
  displayName: "Dialog__StyledOverlay",
  componentId: "sc-bo9tuc-0"
})({
  backgroundColor: 'rgba(0,0,0,0.5)',
  position: 'fixed',
  inset: 0
});
const StyledContent = external_styled_components_default()(react_dialog_.Content).withConfig({
  displayName: "Dialog__StyledContent",
  componentId: "sc-bo9tuc-1"
})(({
  theme
}) => Dialog_objectSpread(Dialog_objectSpread({
  // boxShadow:
  //   'hsl(206 22% 7% / 35%) 0px 10px 38px -10px, hsl(206 22% 7% / 20%) 0px 10px 20px -15px',
  boxShadow: ['1.3px 1.6px 2.2px rgba(0, 0, 0, 0.031)', '3.2px 3.9px 5.3px rgba(0, 0, 0, 0.044)', '6px 7.3px 10px rgba(0, 0, 0, 0.055)', '10.7px 13px 17.9px rgba(0, 0, 0, 0.066)', '20.1px 24.2px 33.4px rgba(0, 0, 0, 0.079)', '48px 58px 80px rgba(0, 0, 0, 0.11)'].join(', '),
  position: 'fixed',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  // width: "90vw",
  // maxWidth: "450px",
  // maxHeight: "85vh",
  maxWidth: '90vw',
  maxHeight: '90vh',
  padding: theme.spacing.gutterSmall,
  borderRadius: 4,
  border: `1px solid ${theme.colors.divider}`
}, theme.textStyles.body), {}, {
  backgroundColor: theme.colors.background,
  overflowY: 'auto',
  // color: theme.colors.textMuted,
  '&:focus': {
    outline: 'none'
  }
}));
const StyledTitle = external_styled_components_default()(react_dialog_.Title).withConfig({
  displayName: "Dialog__StyledTitle",
  componentId: "sc-bo9tuc-2"
})(({
  theme
}) => Dialog_objectSpread({
  margin: 0
}, theme.textStyles.heading2));
const StyledDescription = external_styled_components_default()(react_dialog_.Description).withConfig({
  displayName: "Dialog__StyledDescription",
  componentId: "sc-bo9tuc-3"
})(({
  theme
}) => Dialog_objectSpread({
  margin: 0
}, theme.textStyles.label));
const CloseButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "Dialog__CloseButtonContainer",
  componentId: "sc-bo9tuc-4"
})(({
  theme
}) => ({
  position: 'absolute',
  top: theme.spacing.gutterSmall,
  right: theme.spacing.gutterSmall
}));
const Dialog = /*#__PURE__*/(0,external_react_.forwardRef)(function Dialog({
  children,
  title,
  description,
  open,
  onOpenChange,
  onOpenAutoFocus
}, forwardedRef) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_dialog_.Root, {
    open: open,
    onOpenChange: onOpenChange,
    children: [/*#__PURE__*/jsx_runtime_.jsx(StyledOverlay, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(StyledContent, {
      onOpenAutoFocus: onOpenAutoFocus,
      children: [/*#__PURE__*/jsx_runtime_.jsx(CloseButtonContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(react_dialog_.Close, {
          style: {
            appearance: 'none',
            WebkitAppearance: 'none',
            background: 'none'
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(react_icons_.Cross1Icon, {
            color: "white"
          })
        })
      }), title && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(StyledTitle, {
          children: title
        }), /*#__PURE__*/jsx_runtime_.jsx(SpacerVertical, {
          size: description ? 10 : 20
        })]
      }), description && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(SpacerVertical, {
          size: 10
        }), /*#__PURE__*/jsx_runtime_.jsx(StyledDescription, {
          children: description
        }), /*#__PURE__*/jsx_runtime_.jsx(SpacerVertical, {
          size: 20
        })]
      }), (title || description) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Divider, {
          variant: "light"
        }), /*#__PURE__*/jsx_runtime_.jsx(SpacerVertical, {
          size: 20
        })]
      }), children]
    })]
  });
});
;// CONCATENATED MODULE: ../components/src/EditableTextArea.tsx





const StyledTextArea = external_styled_components_default().textarea.withConfig({
  displayName: "EditableTextArea__StyledTextArea",
  componentId: "sc-1hkoqqy-0"
})({
  background: 'none',
  appearance: 'none',
  resize: 'none',
  position: 'absolute',
  inset: 0,
  width: '100%',
  height: '100%',
  overflow: 'hidden',
  fontFamily: 'inherit',
  fontWeight: 'inherit',
  fontSize: 'inherit',
  lineHeight: 'inherit',
  color: 'inherit',
  outline: '1px solid rgba(255,255,255,0.2)',
  '&::placeholder': {
    color: 'inherit',
    opacity: 0.5
  }
});
function EditableTextArea({
  editing,
  value,
  placeholder,
  onChange
}) {
  return editing ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(StyledTextArea, {
      value: value,
      placeholder: placeholder,
      onChange: event => {
        onChange(event.target.value);
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
      style: {
        visibility: 'hidden',
        whiteSpace: 'pre-wrap'
      },
      children: !value || value.endsWith('\n') ? `${value} ` : value
    })]
  }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: value || ''
  });
}
;// CONCATENATED MODULE: ../components/src/FileDropTarget.tsx
function FileDropTarget_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function FileDropTarget_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { FileDropTarget_ownKeys(Object(source), true).forEach(function (key) { FileDropTarget_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { FileDropTarget_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function FileDropTarget_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function isSupportedFile(file, supportedFileTypes) {
  return supportedFileTypes.includes(file.type);
}
const FileDropTarget_Container = external_styled_components_default().div.withConfig({
  displayName: "FileDropTarget__Container",
  componentId: "sc-4vc1h6-0"
})(() => ({
  display: 'flex',
  flex: 1
}));
const FileDropTarget = /*#__PURE__*/(0,external_react_.memo)(function FileDropTarget({
  children,
  onDropFiles,
  supportedFileTypes
}) {
  const handleFile = (0,external_react_.useCallback)(event => {
    event.preventDefault();
    const offsetPoint = {
      offsetX: event.nativeEvent.offsetX,
      offsetY: event.nativeEvent.offsetY
    };
    const unsupportedTypes = supportedFileTypes ? [...event.dataTransfer.files].flatMap(file => {
      if (!isSupportedFile(file, supportedFileTypes)) {
        return [file.type];
      } else {
        return [];
      }
    }) : [];

    if (unsupportedTypes.length > 0) {
      alert(`Files of type ${unsupportedTypes.join(', ')} aren't supported. The following types are supported: ${supportedFileTypes === null || supportedFileTypes === void 0 ? void 0 : supportedFileTypes.join(', ')}`);
    }

    const files = [...event.dataTransfer.files].flatMap(file => !supportedFileTypes || isSupportedFile(file, supportedFileTypes) ? [file] : []);
    onDropFiles(files, offsetPoint);
  }, [onDropFiles, supportedFileTypes]);
  const {
    dropTargetProps,
    isDropTargetActive
  } = (0,src/* useFileDropTarget */.Er)(handleFile);
  return /*#__PURE__*/jsx_runtime_.jsx(FileDropTarget_Container, FileDropTarget_objectSpread(FileDropTarget_objectSpread({}, dropTargetProps), {}, {
    children: typeof children === 'function' ? children(isDropTargetActive) : children
  }));
});
;// CONCATENATED MODULE: ../components/src/InfoHoverCard.tsx




const InfoHoverCard = /*#__PURE__*/(0,external_react_.memo)(function InfoHoverCard({
  children,
  top = '3px'
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(HoverCard, {
    trigger: /*#__PURE__*/jsx_runtime_.jsx("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(react_icons_.InfoCircledIcon, {
        style: {
          position: 'relative',
          top
        },
        color: "white"
      })
    }),
    children: children
  });
});
;// CONCATENATED MODULE: ../components/src/FormRow.tsx






const FormRow = /*#__PURE__*/(0,external_react_.memo)(function FormRow({
  title,
  children,
  tooltip,
  indent,
  variant = 'regular'
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Stack_HStack, {
    gap: 10,
    alignItems: "center",
    minHeight: 27,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Stack_HStack, {
      width: variant === 'small' ? 110 : variant === 'medium' ? 150 : 190,
      children: [indent && /*#__PURE__*/jsx_runtime_.jsx(SpacerHorizontal, {
        size: indent * 20
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Small, {
        children: [title, tooltip && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(SpacerHorizontal, {
            inline: true,
            size: 6
          }), /*#__PURE__*/jsx_runtime_.jsx(InfoHoverCard, {
            children: tooltip
          })]
        })]
      })]
    }), children]
  });
});
;// CONCATENATED MODULE: ../components/src/FormRowError.tsx



function FormRowError({
  children
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(Stack_HStack, {
    justifyContent: "flex-end",
    children: /*#__PURE__*/jsx_runtime_.jsx(Small, {
      color: "red",
      flex: "0 0 auto",
      children: children
    })
  });
}
;// CONCATENATED MODULE: ../components/src/FormSection.tsx





const FormSection = /*#__PURE__*/(0,external_react_.memo)(function FormSection({
  title,
  right,
  children,
  showContent = true
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Stack_VStack, {
    gap: 20,
    children: [(title || right) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(Stack_HStack, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Heading2, {
        children: title
      }), right && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(SpacerHorizontal, {}), right]
      })]
    }), showContent && /*#__PURE__*/jsx_runtime_.jsx(Stack_VStack, {
      gap: 8,
      padding: 20,
      background: "rgba(0,0,0,0.2)",
      children: children
    })]
  });
});
;// CONCATENATED MODULE: ../components/src/HeadTags.tsx


function getHeadTags({
  config,
  pageTitle,
  pageDescription
}) {
  var _config$favicons, _config$author, _config$author2;

  return [/*#__PURE__*/jsx_runtime_.jsx("title", {
    children: pageTitle
  }, "title"), // Site
  config.title && /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:site_name",
    content: config.title
  }, "og:site_name"),
  /*#__PURE__*/
  // Page
  jsx_runtime_.jsx("meta", {
    property: "og:title",
    content: pageTitle
  }, "og:title"), pageDescription && /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "description",
    content: pageDescription
  }, "description"), pageDescription && /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:description",
    content: pageDescription
  }, "og:description"),
  /*#__PURE__*/
  // Card
  jsx_runtime_.jsx("meta", {
    property: "og:type",
    content: "article"
  }, "og:type"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:locale",
    content: "en_US"
  }, "og:locale"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:card",
    content: "summary"
  }, "og:card"), // Location
  config.location && /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:url",
    content: `https://${config.location.host}`
  }, "og:url"), (_config$favicons = config.favicons) === null || _config$favicons === void 0 ? void 0 : _config$favicons.map(({
    type,
    path
  }, index) => /*#__PURE__*/jsx_runtime_.jsx("link", {
    rel: "icon",
    type: type,
    href: path
  }, index)), // Author
  ...((_config$author = config.author) !== null && _config$author !== void 0 && _config$author.twitter ? [/*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:creator",
    content: `@${config.author.twitter}`
  }, "og:creator"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "article:author",
    content: `https://twitter.com/${config.author.twitter}`
  }, "article:author")] : []), // Preview Image
  ...(config.location && config.previewImage ? [/*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image",
    content: `http://${config.location.host}${config.previewImage.path}`
  }, "og:image"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image:secure_url",
    content: `https://${config.location.host}${config.previewImage.path}`
  }, "og:image:secure_url"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image:type",
    content: config.previewImage.type
  }, "og:image:type"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image:width",
    content: config.previewImage.width
  }, "og:image:width"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image:height",
    content: config.previewImage.height
  }, "og:image:height"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    property: "og:image:alt",
    content: config.previewImage.alt
  }, "og:image:alt")] : []), // Twitter
  ...((_config$author2 = config.author) !== null && _config$author2 !== void 0 && _config$author2.twitter ? [/*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:card",
    content: "summary_large_image"
  }, "twitter:card"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:site",
    content: `@${config.author.twitter}`
  }, "twitter:site"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:creator",
    content: `@${config.author.twitter}`
  }, "twitter:creator"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:title",
    content: pageTitle
  }, "twitter:title"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:description",
    content: pageDescription
  }, "twitter:description"), config.location && config.previewImage && /*#__PURE__*/jsx_runtime_.jsx("meta", {
    name: "twitter:image",
    content: `https://${config.location.host}${config.previewImage.path}`
  }, "twitter:image")] : [])];
}
// EXTERNAL MODULE: external "@radix-ui/react-hover-card"
var react_hover_card_ = __webpack_require__(599);
;// CONCATENATED MODULE: ../components/src/HoverCard.tsx
function HoverCard_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function HoverCard_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { HoverCard_ownKeys(Object(source), true).forEach(function (key) { HoverCard_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { HoverCard_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function HoverCard_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const HoverCard_StyledContent = external_styled_components_default()(react_hover_card_.Content).withConfig({
  displayName: "HoverCard__StyledContent",
  componentId: "sc-xnyi5z-0"
})(({
  theme
}) => HoverCard_objectSpread(HoverCard_objectSpread({}, theme.textStyles.small), {}, {
  padding: "8px 12px",
  width: 400,
  lineHeight: "1.7",
  backgroundColor: "#333",
  boxShadow: "hsl(206 22% 7% / 50%) 0px 10px 38px -10px, hsl(206 22% 7% / 35%) 0px 10px 20px -15px",
  wordBreak: "break-word",
  borderRadius: "4px"
}));
const StyledArrow = external_styled_components_default()(react_hover_card_.Arrow).withConfig({
  displayName: "HoverCard__StyledArrow",
  componentId: "sc-xnyi5z-1"
})({
  fill: "#333"
});
const HoverCardRoot = react_hover_card_.Root;
const HoverCardTrigger = react_hover_card_.Trigger;
const HoverCardContent = HoverCard_StyledContent;
const HoverCardArrow = StyledArrow;
const HoverCard = ({
  trigger,
  children
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(HoverCardRoot, {
  children: [/*#__PURE__*/jsx_runtime_.jsx(HoverCardTrigger, {
    asChild: true,
    children: trigger
  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(HoverCardContent, {
    sideOffset: 4,
    children: [children, /*#__PURE__*/jsx_runtime_.jsx(HoverCardArrow, {
      offset: 4
    })]
  })]
});
;// CONCATENATED MODULE: ../components/src/icons/DiscordLogoIcon.tsx
const DiscordLogoIcon_excluded = ["color"];

function DiscordLogoIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function DiscordLogoIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { DiscordLogoIcon_ownKeys(Object(source), true).forEach(function (key) { DiscordLogoIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { DiscordLogoIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function DiscordLogoIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DiscordLogoIcon_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = DiscordLogoIcon_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function DiscordLogoIcon_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const DiscordLogoIcon = /*#__PURE__*/(0,external_react_.memo)(function (_ref) {
  let {
    color = 'currentColor'
  } = _ref,
      props = DiscordLogoIcon_objectWithoutProperties(_ref, DiscordLogoIcon_excluded);

  return /*#__PURE__*/jsx_runtime_.jsx("svg", DiscordLogoIcon_objectSpread(DiscordLogoIcon_objectSpread({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M12.005 2.82139C11.1765 2.4412 10.288 2.1611 9.35894 2.00067C9.34203 1.99758 9.32513 2.00531 9.31641 2.02079C9.20214 2.22403 9.07556 2.48918 8.98692 2.69758C7.98772 2.54799 6.99364 2.54799 6.01492 2.69758C5.92627 2.48454 5.7951 2.22403 5.68031 2.02079C5.6716 2.00583 5.6547 1.99809 5.63778 2.00067C4.70928 2.16059 3.82076 2.44069 2.99167 2.82139C2.9845 2.82448 2.97834 2.82965 2.97426 2.83635C1.28892 5.35421 0.827235 7.81019 1.05372 10.2357C1.05475 10.2476 1.06141 10.2589 1.07063 10.2661C2.18257 11.0827 3.25967 11.5785 4.31678 11.9071C4.33369 11.9122 4.35162 11.906 4.36239 11.8921C4.61244 11.5506 4.83535 11.1906 5.02647 10.8119C5.03774 10.7897 5.02698 10.7634 5.00393 10.7546C4.65036 10.6205 4.3137 10.457 3.98985 10.2713C3.96424 10.2563 3.96219 10.2197 3.98575 10.2022C4.0539 10.1511 4.12207 10.098 4.18714 10.0443C4.19892 10.0345 4.21532 10.0325 4.22916 10.0386C6.3567 11.01 8.66 11.01 10.7624 10.0386C10.7763 10.0319 10.7927 10.034 10.805 10.0438C10.8701 10.0975 10.9382 10.1511 11.0069 10.2022C11.0304 10.2197 11.0289 10.2563 11.0033 10.2713C10.6794 10.4606 10.3428 10.6205 9.98869 10.7541C9.96564 10.7629 9.95539 10.7897 9.96667 10.8119C10.1619 11.19 10.3848 11.5501 10.6302 11.8916C10.6405 11.906 10.6589 11.9122 10.6758 11.9071C11.7381 11.5785 12.8152 11.0827 13.9271 10.2661C13.9368 10.2589 13.943 10.2481 13.944 10.2362C14.2151 7.43205 13.49 4.99622 12.0219 2.83686C12.0184 2.82965 12.0122 2.82448 12.005 2.82139ZM5.34418 8.75882C4.70365 8.75882 4.17586 8.17076 4.17586 7.44857C4.17586 6.72637 4.69341 6.13831 5.34418 6.13831C6.00006 6.13831 6.52273 6.73153 6.51248 7.44857C6.51248 8.17076 5.99493 8.75882 5.34418 8.75882ZM9.66382 8.75882C9.02331 8.75882 8.49552 8.17076 8.49552 7.44857C8.49552 6.72637 9.01305 6.13831 9.66382 6.13831C10.3197 6.13831 10.8424 6.73153 10.8321 7.44857C10.8321 8.17076 10.3197 8.75882 9.66382 8.75882Z",
      fill: color
    })
  }));
});
;// CONCATENATED MODULE: ../components/src/icons/FolderIcon.tsx
const FolderIcon_excluded = ["color"];

function FolderIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function FolderIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { FolderIcon_ownKeys(Object(source), true).forEach(function (key) { FolderIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { FolderIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function FolderIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function FolderIcon_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = FolderIcon_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function FolderIcon_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const FolderIcon = /*#__PURE__*/(0,external_react_.memo)(function (_ref) {
  let {
    color = 'currentColor'
  } = _ref,
      props = FolderIcon_objectWithoutProperties(_ref, FolderIcon_excluded);

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", FolderIcon_objectSpread(FolderIcon_objectSpread({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M2.5 3C2.22386 3 2 3.22386 2 3.5V6.5V11.5C2 11.7761 2.22386 12 2.5 12H12.5C12.7761 12 13 11.7761 13 11.5V4H10H6.80278C6.50664 4 6.21713 3.91234 5.97073 3.74808L4.97457 3.08397C4.89244 3.02922 4.79594 3 4.69722 3H2.5ZM1 3.5C1 2.67157 1.67157 2 2.5 2H4.69722C4.99336 2 5.28287 2.08766 5.52927 2.25192L6.52543 2.91603C6.60756 2.97078 6.70406 3 6.80278 3H10H13.25C13.6642 3 14 3.33579 14 3.75V11.5C14 12.3284 13.3284 13 12.5 13H2.5C1.67157 13 1 12.3284 1 11.5V6.5V3.5Z",
      fill: color
    }), /*#__PURE__*/jsx_runtime_.jsx("line", {
      x1: "2",
      y1: "5.5",
      x2: "13",
      y2: "5.5",
      stroke: color
    })]
  }));
});
;// CONCATENATED MODULE: ../components/src/icons/OpenSeaLogoIcon.tsx
const OpenSeaLogoIcon_excluded = ["color"];

function OpenSeaLogoIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function OpenSeaLogoIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { OpenSeaLogoIcon_ownKeys(Object(source), true).forEach(function (key) { OpenSeaLogoIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { OpenSeaLogoIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function OpenSeaLogoIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function OpenSeaLogoIcon_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = OpenSeaLogoIcon_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function OpenSeaLogoIcon_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const OpenSeaLogoIcon = /*#__PURE__*/(0,external_react_.memo)(function (_ref) {
  let {
    color = 'currentColor'
  } = _ref,
      props = OpenSeaLogoIcon_objectWithoutProperties(_ref, OpenSeaLogoIcon_excluded);

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", OpenSeaLogoIcon_objectSpread(OpenSeaLogoIcon_objectSpread({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M1.77355 8.08082L1.81903 8.00933L4.56204 3.71825C4.60213 3.65541 4.69637 3.66192 4.72672 3.73015C5.18495 4.75717 5.58039 6.03442 5.39513 6.82958C5.31605 7.15674 5.09938 7.59983 4.85562 8.00933C4.82422 8.06892 4.78954 8.12742 4.7527 8.18375C4.73539 8.20974 4.70612 8.22492 4.6747 8.22492H1.85371C1.77786 8.22492 1.73346 8.14259 1.77355 8.08082Z",
      fill: color
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M14 8.87828V9.55752C14 9.59651 13.9762 9.63119 13.9415 9.64635C13.7292 9.73736 13.0022 10.071 12.7 10.4914C11.9287 11.5649 11.3393 13.1 10.022 13.1H4.52624C2.57842 13.1 1 11.5162 1 9.56186V9.49901C1 9.44702 1.04225 9.40477 1.09424 9.40477H4.15791C4.21858 9.40477 4.263 9.4611 4.25759 9.52069C4.23592 9.72002 4.27275 9.92369 4.367 10.1089C4.54899 10.4783 4.92601 10.7091 5.33333 10.7091H6.85V9.52502H5.35067C5.27374 9.52502 5.22826 9.43619 5.27266 9.37335C5.28892 9.34844 5.30734 9.32243 5.32684 9.29319C5.46874 9.0917 5.67133 8.7786 5.87282 8.42218C6.01041 8.1817 6.14367 7.92493 6.25092 7.66711C6.27259 7.62053 6.28991 7.57287 6.30725 7.52626C6.33649 7.44395 6.36684 7.36702 6.38849 7.29012C6.41016 7.22512 6.4275 7.15686 6.44484 7.09294C6.49576 6.87411 6.51741 6.64227 6.51741 6.40177C6.51741 6.30752 6.51307 6.20895 6.5044 6.11468C6.50009 6.01177 6.48709 5.90885 6.47408 5.80594C6.46541 5.71493 6.44918 5.62502 6.43184 5.53078C6.41016 5.39319 6.37984 5.2567 6.34516 5.11911L6.33326 5.06711C6.30725 4.97287 6.28557 4.88294 6.25525 4.78869C6.16966 4.49294 6.07108 4.20477 5.96709 3.93502C5.92917 3.82778 5.88583 3.72486 5.8425 3.62195C5.77858 3.46702 5.71358 3.32619 5.65399 3.19294C5.62367 3.13227 5.59766 3.07702 5.57167 3.02069C5.54241 2.95677 5.51209 2.89287 5.48174 2.83218C5.46009 2.7856 5.43516 2.74227 5.41782 2.69895L5.23259 2.35661C5.20658 2.31002 5.24991 2.25477 5.30083 2.26885L6.46 2.58303H6.46326C6.46541 2.58303 6.46649 2.58411 6.46759 2.58411L6.62032 2.62635L6.78826 2.67402L6.85 2.69135V2.00236C6.85 1.66977 7.11649 1.40002 7.44583 1.40002C7.6105 1.40002 7.76 1.46718 7.86725 1.57661C7.9745 1.68603 8.04167 1.83553 8.04167 2.00236V3.02502L8.16516 3.05968C8.17491 3.06294 8.18466 3.06727 8.19333 3.07376C8.22367 3.09651 8.267 3.13012 8.32225 3.17126C8.36557 3.20594 8.41216 3.24819 8.46851 3.29151C8.58009 3.38145 8.71333 3.49736 8.85959 3.6306C8.89858 3.6642 8.93649 3.69885 8.97117 3.73353C9.15966 3.90901 9.37092 4.11486 9.57241 4.34236C9.62874 4.40626 9.68399 4.47126 9.74032 4.53952C9.79668 4.60885 9.85624 4.67711 9.90826 4.74537C9.97649 4.83635 10.0502 4.9306 10.1141 5.0292C10.1444 5.07578 10.1791 5.12344 10.2083 5.17002C10.2907 5.29461 10.3633 5.42353 10.4326 5.55243C10.4618 5.61202 10.4922 5.67702 10.5182 5.74094C10.5951 5.91319 10.6558 6.08869 10.6947 6.2642C10.7067 6.30211 10.7153 6.34328 10.7197 6.38012V6.38876C10.7327 6.44078 10.737 6.49603 10.7413 6.55236C10.7587 6.73218 10.75 6.91202 10.711 7.09294C10.6947 7.16986 10.6731 7.24243 10.6471 7.31936C10.6211 7.39303 10.5951 7.46993 10.5615 7.54252C10.4965 7.6931 10.4196 7.84369 10.3286 7.98452C10.2993 8.03651 10.2647 8.09177 10.23 8.14376C10.1921 8.19901 10.1531 8.25103 10.1184 8.30195C10.0708 8.36695 10.0198 8.43518 9.96782 8.49585C9.92124 8.55977 9.87358 8.62369 9.82158 8.68002C9.74899 8.7656 9.67966 8.84686 9.60709 8.92486C9.56374 8.97578 9.51716 9.02778 9.4695 9.07436C9.42291 9.12635 9.37525 9.17294 9.3319 9.21626C9.25934 9.28885 9.19867 9.34518 9.14775 9.39177L9.02858 9.50119C9.01124 9.51635 8.98849 9.52502 8.96466 9.52502H8.04167V10.7091H9.20301C9.46301 10.7091 9.71 10.617 9.90934 10.448C9.97757 10.3884 10.2755 10.1306 10.6276 9.7417C10.6395 9.72869 10.6547 9.71895 10.672 9.71461L13.8797 8.78727C13.9393 8.76993 14 8.81544 14 8.87828Z",
      fill: color
    })]
  }));
});
;// CONCATENATED MODULE: ../components/src/icons/TwitterLogoIcon.tsx
const TwitterLogoIcon_excluded = ["color"];

function TwitterLogoIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function TwitterLogoIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { TwitterLogoIcon_ownKeys(Object(source), true).forEach(function (key) { TwitterLogoIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { TwitterLogoIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function TwitterLogoIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function TwitterLogoIcon_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = TwitterLogoIcon_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function TwitterLogoIcon_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const TwitterLogoIcon = /*#__PURE__*/(0,external_react_.memo)(function (_ref) {
  let {
    color = 'currentColor'
  } = _ref,
      props = TwitterLogoIcon_objectWithoutProperties(_ref, TwitterLogoIcon_excluded);

  return /*#__PURE__*/jsx_runtime_.jsx("svg", TwitterLogoIcon_objectSpread(TwitterLogoIcon_objectSpread({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M7.23336 4.69629C7.23336 2.96884 8.63335 1.56857 10.36 1.56857C11.3736 1.56857 12.183 2.04804 12.7254 2.74385C13.3079 2.62467 13.8557 2.40913 14.3513 2.11508C14.1559 2.72598 13.7424 3.2396 13.2033 3.56463C13.2038 3.56568 13.2042 3.56674 13.2047 3.56779C13.7334 3.50361 14.2364 3.36302 14.7048 3.15546L14.7037 3.15715C14.3667 3.66183 13.9431 4.10736 13.4561 4.47034C13.4823 4.64672 13.4956 4.82427 13.4956 5.00079C13.4956 8.6871 10.6873 12.9746 5.52122 12.9746C3.93906 12.9746 2.46544 12.511 1.22505 11.7152C0.992632 11.5661 0.925108 11.2568 1.07423 11.0244C1.0874 11.0038 1.10183 10.9846 1.11734 10.9666C1.20582 10.8202 1.37438 10.7309 1.5554 10.7522C2.47066 10.8601 3.38568 10.7485 4.19219 10.3962C3.39226 10.0434 2.77129 9.35975 2.50204 8.51974C2.45359 8.3686 2.48835 8.20311 2.59351 8.08422C2.59716 8.0801 2.60087 8.07606 2.60464 8.0721C1.96391 7.50819 1.55973 6.68208 1.55973 5.76143V5.72759C1.55973 5.56814 1.64411 5.42059 1.78155 5.33974C1.82671 5.31317 1.87537 5.29511 1.92532 5.28558C1.70549 4.86154 1.58116 4.37984 1.58116 3.86958C1.58116 3.40165 1.58384 2.81192 1.91332 2.28081C1.98718 2.16175 2.10758 2.08915 2.2364 2.07195C2.42588 2.01237 2.64087 2.06969 2.77406 2.23302C3.86536 3.57126 5.44066 4.49583 7.23366 4.73961L7.23336 4.69629ZM5.52122 11.9746C4.73387 11.9746 3.97781 11.8435 3.27248 11.6023C4.13012 11.4538 4.95307 11.1159 5.66218 10.5602C5.81211 10.4427 5.87182 10.2435 5.81126 10.0629C5.7507 9.88234 5.583 9.75943 5.39255 9.75607C4.68968 9.74366 4.06712 9.39716 3.67793 8.86845C3.86828 8.85306 4.05428 8.82039 4.23445 8.77167C4.43603 8.71716 4.57363 8.53114 4.56674 8.32243C4.55985 8.11372 4.41029 7.93718 4.20555 7.89607C3.42694 7.73977 2.79883 7.16764 2.56169 6.42174C2.76255 6.47025 2.97102 6.4991 3.18482 6.5061C3.38563 6.51267 3.56646 6.38533 3.62795 6.19405C3.68943 6.00277 3.61666 5.79391 3.44963 5.68224C2.86523 5.29155 2.48116 4.62464 2.48116 3.86958C2.48116 3.70213 2.48352 3.55268 2.49355 3.41719C3.85115 4.79913 5.70873 5.68931 7.77588 5.79338C7.93225 5.80126 8.08328 5.73543 8.18395 5.61553C8.28463 5.49562 8.32332 5.33548 8.28851 5.18284C8.25255 5.02517 8.23336 4.86284 8.23336 4.69629C8.23336 3.52085 9.18591 2.56857 10.36 2.56857C11.5943 2.56857 12.4956 3.71208 12.4956 5.00079C12.4956 8.25709 10.0202 11.9746 5.52122 11.9746Z",
      fill: color // fillRule="evenodd"
      // clipRule="evenodd"

    })
  }));
});
;// CONCATENATED MODULE: ../components/src/InputField.tsx
function InputField_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function InputField_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { InputField_ownKeys(Object(source), true).forEach(function (key) { InputField_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { InputField_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function InputField_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function InputField({
  value,
  onChange,
  type = 'text',
  placeholder,
  disabled,
  style
}) {
  return /*#__PURE__*/_jsx("input", {
    disabled: disabled,
    value: value,
    type: type,
    placeholder: placeholder,
    style: InputField_objectSpread({
      appearance: 'none',
      WebkitAppearance: 'none',
      flex: '1',
      color: 'black',
      background: 'white',
      padding: '8px 8px',
      fontSize: '16px',
      opacity: disabled ? 0.5 : undefined
    }, style),
    onChange: event => {
      const newValue = event.target.value;
      onChange(newValue);
    }
  });
}
;// CONCATENATED MODULE: ../components/src/List.tsx

const OrderedList = external_styled_components_default().ol.withConfig({
  displayName: "List__OrderedList",
  componentId: "sc-k6vyjr-0"
})({
  marginTop: '0px',
  marginBottom: '10px',
  display: 'block',
  paddingLeft: '40px',
  paddingTop: '5px',
  paddingBottom: '5px',
  fontSize: '1.1rem',
  fontWeight: 400,
  lineHeight: '1.75',
  listStylePosition: 'outside'
});
const UnorderedList = external_styled_components_default().ul.withConfig({
  displayName: "List__UnorderedList",
  componentId: "sc-k6vyjr-1"
})(({
  itemGap = '20px'
}) => ({
  marginTop: '0px',
  marginBottom: '10px',
  display: 'block',
  paddingTop: '5px',
  paddingBottom: '5px',
  fontSize: '1.1rem',
  fontWeight: 400,
  lineHeight: '1.75',
  listStylePosition: 'outside',
  '& > li + & > li': {
    marginTop: itemGap
  }
}));
const ListItem = external_styled_components_default().li.withConfig({
  displayName: "List__ListItem",
  componentId: "sc-k6vyjr-2"
})({});
// EXTERNAL MODULE: ../../node_modules/next/link.js
var next_link = __webpack_require__(9097);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ../components/src/NavLink.tsx





const Anchor = external_styled_components_default().a.withConfig({
  displayName: "NavLink__Anchor",
  componentId: "sc-10xqoqz-0"
})({
  fontSize: '1rem',
  lineHeight: '60px',
  whiteSpace: 'pre',
  flex: '0 0 auto',
  display: 'flex',
  alignItems: 'center'
});
function NavLink({
  children,
  href
}) {
  const router = (0,router_.useRouter)();

  if (!href.startsWith('/')) {
    return /*#__PURE__*/jsx_runtime_.jsx(Anchor, {
      href: href,
      target: "_blank",
      rel: "noreferrer",
      children: children
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: href,
    passHref: true,
    children: /*#__PURE__*/jsx_runtime_.jsx(Anchor, {
      className: router.asPath === href && router.asPath !== '/' ? 'active' : '',
      style: {},
      children: children
    })
  });
}
;// CONCATENATED MODULE: ../components/src/ScrollableStack.tsx
function ScrollableStack_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function ScrollableStack_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ScrollableStack_ownKeys(Object(source), true).forEach(function (key) { ScrollableStack_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ScrollableStack_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ScrollableStack_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ScrollableStack = /*#__PURE__*/(0,external_react_.memo)(function ScrollableStack({
  children,
  outerProps,
  innerProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(Stack_VStack, ScrollableStack_objectSpread(ScrollableStack_objectSpread({
    flex: "1 1 0px"
  }, outerProps), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Stack_VStack, ScrollableStack_objectSpread(ScrollableStack_objectSpread({
      overflowY: "auto",
      flex: "1 1 0px"
    }, innerProps), {}, {
      children: children
    }))
  }));
});
;// CONCATENATED MODULE: ../components/src/Tabs.tsx






const Tab = external_styled_components_default().button.withConfig({
  displayName: "Tabs__Tab",
  componentId: "sc-1ry1fdx-0"
})(({
  theme,
  selected
}) => ({
  padding: '8px 16px',
  border: 'none',
  background: selected ? theme.colors.primary : 'rgba(255,255,255,0.2)',
  borderRadius: 20,
  justifyContent: 'center',
  alignItems: 'center',
  display: 'flex'
}));
function Tabs({
  selectedTabId,
  onChangeTabId,
  tabIds,
  renderTitle,
  renderContent
}) {
  return /*#__PURE__*/_jsxs(VStack, {
    gap: 40,
    children: [/*#__PURE__*/_jsx(HStack, {
      gap: 10,
      children: tabIds.map(id => {
        var _renderTitle;

        const selected = id === selectedTabId;
        return /*#__PURE__*/_jsx(Tab, {
          selected: selected,
          onClick: () => {
            onChangeTabId === null || onChangeTabId === void 0 ? void 0 : onChangeTabId(id);
          },
          children: /*#__PURE__*/_jsx(Label, {
            color: selected ? 'white' : 'lightgrey',
            children: (_renderTitle = renderTitle === null || renderTitle === void 0 ? void 0 : renderTitle(id)) !== null && _renderTitle !== void 0 ? _renderTitle : id
          })
        }, id);
      })
    }), /*#__PURE__*/_jsx(VStack, {
      children: renderContent(selectedTabId)
    })]
  });
}
// EXTERNAL MODULE: external "react-window"
var external_react_window_ = __webpack_require__(551);
;// CONCATENATED MODULE: ../components/src/VirtualizedGrid.tsx
const VirtualizedGrid_excluded = ["style"];

function VirtualizedGrid_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function VirtualizedGrid_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { VirtualizedGrid_ownKeys(Object(source), true).forEach(function (key) { VirtualizedGrid_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { VirtualizedGrid_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function VirtualizedGrid_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function VirtualizedGrid_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = VirtualizedGrid_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function VirtualizedGrid_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const ItemContext = /*#__PURE__*/(0,external_react_.createContext)(undefined);
const ContainerElement = external_styled_components_default().div.withConfig({
  displayName: "VirtualizedGrid__ContainerElement",
  componentId: "sc-xixby3-0"
})({
  flex: '1 1 0%',
  position: 'relative'
});
const GridInnerElement = /*#__PURE__*/(0,external_react_.forwardRef)((_ref, ref) => {
  let {
    style
  } = _ref,
      rest = VirtualizedGrid_objectWithoutProperties(_ref, VirtualizedGrid_excluded);

  const {
    gutter
  } = (0,external_react_.useContext)(ItemContext);
  const computedStyle = (0,external_react_.useMemo)(() => {
    var _style$height;

    return VirtualizedGrid_objectSpread(VirtualizedGrid_objectSpread({}, style), {}, {
      height: Number((_style$height = style.height) !== null && _style$height !== void 0 ? _style$height : 0) + gutter * 2
    });
  }, [style, gutter]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", VirtualizedGrid_objectSpread({
    ref: ref,
    style: computedStyle
  }, rest));
});

function Cell({
  columnIndex,
  rowIndex,
  style
}) {
  const {
    items,
    columnCount,
    gap,
    gutter,
    renderItem
  } = (0,external_react_.useContext)(ItemContext);
  const index = rowIndex * columnCount + columnIndex;
  const item = items[index];
  if (!item) return null;

  const computedStyle = VirtualizedGrid_objectSpread(VirtualizedGrid_objectSpread({}, style), {}, {
    top: Number(style.top) + gutter,
    left: Number(style.left) + gutter + columnIndex * gap
  });

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: computedStyle,
    children: renderItem({
      item,
      index
    })
  });
}

function VirtualizedGrid({
  items,
  size,
  renderItem,
  rowHeight,
  minimumItemWidth = 300,
  gap = 20,
  gutter = 20
}) {
  const {
    width,
    height
  } = size;
  const widthMinusGutter = width - gutter * 2;
  const columnCount = Math.floor(widthMinusGutter / minimumItemWidth);
  const columnWidth = Math.floor((widthMinusGutter - gap * (columnCount - 1)) / columnCount);
  const contextValue = (0,external_react_.useMemo)(() => {
    return {
      items,
      columnCount,
      columnWidth,
      gap,
      gutter,
      renderItem: renderItem
    };
  }, [items, columnCount, columnWidth, gap, gutter, renderItem]);
  const grid = (0,external_react_.useMemo)(() => {
    return /*#__PURE__*/jsx_runtime_.jsx(ItemContext.Provider, {
      value: contextValue,
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_window_.FixedSizeGrid, {
        height: height,
        width: width,
        columnCount: contextValue.columnCount,
        columnWidth: contextValue.columnWidth,
        rowCount: Math.ceil(contextValue.items.length / contextValue.columnCount),
        rowHeight: rowHeight(contextValue.columnWidth),
        innerElementType: GridInnerElement,
        overscanRowCount: 10,
        children: Cell
      })
    });
  }, [contextValue, height, width, rowHeight]);
  return /*#__PURE__*/jsx_runtime_.jsx(ContainerElement, {
    children: width > 0 && grid
  });
}
;// CONCATENATED MODULE: ../components/src/index.ts
































/***/ }),

/***/ 9022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "eS": () => (/* reexport */ EnvironmentParametersProvider),
  "l": () => (/* reexport */ FAILURE_ABORTED),
  "Sp": () => (/* reexport */ FAILURE_NOT_LOADED),
  "g7": () => (/* reexport */ FAILURE_UNKNOWN),
  "vP": () => (/* reexport */ Web3ContextProvider),
  "SF": () => (/* reexport */ useAddress),
  "xx": () => (/* reexport */ useChainId),
  "ry": () => (/* reexport */ useWeb3API),
  "Rf": () => (/* reexport */ useWeb3Data)
});

// UNUSED EXPORTS: useEnvironmentParameter, useNoWallet

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ../contexts/src/EnvironmentParametersContext.tsx

const EnvironmentParametersContext = /*#__PURE__*/(0,external_react_.createContext)(undefined);
const EnvironmentParametersProvider = EnvironmentParametersContext.Provider;

function useEnvironmentParameters() {
  const value = useContext(EnvironmentParametersContext);

  if (!value) {
    throw new Error('Missing EnvironmentParametersProvider');
  }

  return value;
}

function useEnvironmentParameter(key) {
  return useEnvironmentParameters()[key];
}
// EXTERNAL MODULE: external "@metamask/detect-provider"
var detect_provider_ = __webpack_require__(3427);
var detect_provider_default = /*#__PURE__*/__webpack_require__.n(detect_provider_);
// EXTERNAL MODULE: external "@openpalette/contract"
var contract_ = __webpack_require__(4008);
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ../contexts/src/Web3ProviderContext.tsx





const Web3Context = /*#__PURE__*/(0,external_react_.createContext)({
  api: {
    connect: async () => {},
    disconnect: async () => {}
  }
});

function reducer(state, action) {
  switch (action.type) {
    case 'connected':
      {
        return {
          address: action.address,
          provider: action.provider,
          chainId: action.chainId
        };
      }
  }

  if (!state) return state;

  switch (action.type) {
    case 'disconnect':
      {
        return undefined;
      }
  }
}

const FAILURE_NOT_LOADED = {
  type: 'failure',
  reason: 'error',
  message: 'Something went wrong. Please reload the page.'
};
const FAILURE_UNKNOWN = {
  type: 'failure',
  reason: 'error',
  message: 'An error occurred.'
};
const FAILURE_ABORTED = {
  type: 'failure',
  reason: 'aborted',
  message: 'Aborted.'
};
const Web3ContextProvider = ({
  children,
  mockData = false
}) => {
  const {
    0: data,
    1: dispatch
  } = (0,external_react_.useReducer)(reducer, undefined);
  const {
    0: noWallet,
    1: setNoWallet
  } = (0,external_react_.useState)();
  const connect = (0,external_react_.useCallback)(async () => {
    const injectedProvider = await detect_provider_default()();
    const ethereum = injectedProvider;

    if (!ethereum) {
      setNoWallet(true);
      return;
    }

    async function handleAccountsChanged(accounts) {
      localStorage.setItem('shouldAutoconnect', JSON.stringify(true));
      const provider = new external_ethers_.ethers.providers.Web3Provider(ethereum);
      const chainId = await ethereum.request({
        method: 'eth_chainId'
      });
      dispatch({
        type: 'connected',
        address: (0,contract_.createAddress)(accounts[0]),
        provider,
        chainId
      });
    }

    ethereum.request({
      method: 'eth_requestAccounts'
    }).then(handleAccountsChanged);
    ethereum.on('accountsChanged', handleAccountsChanged);
    ethereum.on('chainChanged', () => {
      window.location.reload();
    });
  }, []);
  const disconnect = (0,external_react_.useCallback)(() => {
    localStorage.removeItem('shouldAutoconnect');
    dispatch({
      type: 'disconnect'
    });
  }, []);
  const value = {
    data,
    noWallet,
    api: {
      connect,
      disconnect
    }
  }; // Try to connect once on launch

  (0,external_react_.useEffect)(() => {
    const shouldAutoconnect = localStorage.getItem('shouldAutoconnect');

    if (shouldAutoconnect && JSON.parse(shouldAutoconnect) === true) {
      connect();
    }
  }, [connect]);
  return /*#__PURE__*/jsx_runtime_.jsx(Web3Context.Provider, {
    value: value,
    children: children
  });
};
function useWeb3Data() {
  var _useContext;

  return (_useContext = (0,external_react_.useContext)(Web3Context)) === null || _useContext === void 0 ? void 0 : _useContext.data;
}
function useAddress() {
  var _useContext2, _useContext2$data;

  return (_useContext2 = (0,external_react_.useContext)(Web3Context)) === null || _useContext2 === void 0 ? void 0 : (_useContext2$data = _useContext2.data) === null || _useContext2$data === void 0 ? void 0 : _useContext2$data.address;
}
function useWeb3API() {
  return (0,external_react_.useContext)(Web3Context).api;
}
function useChainId() {
  var _useContext3, _useContext3$data;

  return (_useContext3 = (0,external_react_.useContext)(Web3Context)) === null || _useContext3 === void 0 ? void 0 : (_useContext3$data = _useContext3.data) === null || _useContext3$data === void 0 ? void 0 : _useContext3$data.chainId;
}
function useNoWallet() {
  var _useContext4;

  return (_useContext4 = useContext(Web3Context)) === null || _useContext4 === void 0 ? void 0 : _useContext4.noWallet;
}
;// CONCATENATED MODULE: ../contexts/src/index.ts



/***/ }),

/***/ 5781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "d0": () => (/* reexport */ castHashParameter),
  "PV": () => (/* reexport */ mapPromiseState),
  "ib": () => (/* reexport */ useFetch),
  "Er": () => (/* reexport */ useFileDropTarget),
  "nv": () => (/* reexport */ usePrismExtensions),
  "tH": () => (/* reexport */ useSize),
  "Qw": () => (/* reexport */ useUrlHashParameters)
});

// UNUSED EXPORTS: getUrlHashParameters, useWindowSize

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ../utils/src/index.ts + 17 modules
var src = __webpack_require__(6221);
;// CONCATENATED MODULE: ../hooks/src/urlHashParameters.ts


function getUrlHashParameters() {
  try {
    return (0,src.decodeQueryParameters)(window.location.hash.slice(1));
  } catch (e) {
    // console.warn(e);
    return {};
  }
}
function useUrlHashParameters() {
  const {
    0: parameters,
    1: setParameters
  } = (0,external_react_.useState)(() => getUrlHashParameters());
  (0,external_react_.useEffect)(() => {
    const handler = () => setParameters(getUrlHashParameters());

    window.addEventListener('hashchange', handler);
    return () => {
      window.removeEventListener('hashchange', handler);
    };
  }, []);
  return parameters;
}
function castHashParameter(value, type) {
  switch (type) {
    case 'boolean':
      return value === 'true';

    case 'number':
      {
        const result = Number(value);
        return isNaN(result) ? 0 : result;
      }

    case 'string':
      return String(value);

    default:
      throw new Error('Invalid type');
  }
}
;// CONCATENATED MODULE: ../hooks/src/useFetch.ts


function mapPromiseState(state, f) {
  return state.type === 'success' ? {
    type: 'success',
    value: f(state.value)
  } : state;
}
function useFetch(url, encoding = 'json') {
  const {
    0: state,
    1: setState
  } = (0,external_react_.useState)({
    type: 'pending'
  });
  (0,external_react_.useEffect)(() => {
    let isStale = false;

    async function getInfo() {
      try {
        if (!url) {
          setState({
            type: 'pending'
          });
          return;
        }

        const data = await (0,src.fetchData)(url, encoding);
        if (isStale) return;
        setState({
          type: 'success',
          value: data
        });
      } catch (error) {
        if (isStale) return;
        setState({
          type: 'failure',
          value: error
        });
      }
    }

    getInfo();
    return () => {
      isStale = true;
    };
  }, [url, encoding]);
  return state;
}
;// CONCATENATED MODULE: ../hooks/src/useFileDropTarget.ts

function useFileDropTarget(dropEvent) {
  const {
    0: isDropTargetActive,
    1: setIsDropTargetActive
  } = (0,external_react_.useState)(false);
  const handleDragEvent = (0,external_react_.useCallback)((event, on) => {
    if (on !== undefined) setIsDropTargetActive(on);
    event.preventDefault();
  }, []);
  const handleDropEvent = (0,external_react_.useCallback)(event => {
    dropEvent(event);
    setIsDropTargetActive(false);
  }, [dropEvent, setIsDropTargetActive]);
  return {
    dropTargetProps: {
      onDragOver: handleDragEvent,
      onDragEnter: event => handleDragEvent(event, true),
      onDragLeave: event => handleDragEvent(event, false),
      onDrop: handleDropEvent
    },
    isDropTargetActive
  };
}
;// CONCATENATED MODULE: ../hooks/src/usePrismExtensions.ts

function usePrismExtensions() {
  const {
    1: setPrismLoaded
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    const Prism = (__webpack_require__(4607)["default"]);

    Prism.languages.solidity = Prism.languages.extend('clike', {
      'class-name': {
        pattern: /(\b(?:contract|enum|interface|library|new|struct|using)\s+)(?!\d)[\w$]+/,
        lookbehind: true
      },
      keyword: /\b(?:_|anonymous|as|assembly|assert|break|calldata|case|constant|constructor|continue|contract|default|delete|do|else|emit|enum|event|external|for|from|function|if|import|indexed|inherited|interface|internal|is|let|library|mapping|memory|modifier|new|payable|pragma|private|public|pure|require|returns?|revert|selfdestruct|solidity|storage|struct|suicide|switch|this|throw|using|var|view|while)\b/,
      operator: /=>|->|:=|=:|\*\*|\+\+|--|\|\||&&|<<=?|>>=?|[-+*/%^&|<>!=]=?|[~?]/
    });
    Prism.languages.insertBefore('solidity', 'keyword', {
      builtin: /\b(?:address|bool|string|u?int(?:8|16|24|32|40|48|56|64|72|80|88|96|104|112|120|128|136|144|152|160|168|176|184|192|200|208|216|224|232|240|248|256)?|byte|bytes(?:[1-9]|[12]\d|3[0-2])?)\b/
    });
    Prism.languages.insertBefore('solidity', 'number', {
      version: {
        pattern: /([<>]=?|\^)\d+\.\d+\.\d+\b/,
        lookbehind: true,
        alias: 'number'
      }
    });
    Prism.languages.sol = Prism.languages.solidity;
    setPrismLoaded(true);
  }, []);
}
;// CONCATENATED MODULE: ../hooks/src/useSize.ts
// MIT License
//
// Copyright (c) 2020 Modulz
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// https://github.com/radix-ui/primitives/blob/f3de622e944785d01eb6041249ca1645f79ce102/packages/react/utils/src/useSize.tsx
/// <reference types="resize-observer-browser" />

function useSize(
/** A reference to the element whose size to observe */
refToObserve) {
  const [size, setSize] = external_react_.useState(undefined);
  external_react_.useEffect(() => {
    if (refToObserve.current) {
      const elementToObserve = refToObserve.current;
      const resizeObserver = new ResizeObserver(entries => {
        if (!Array.isArray(entries)) {
          return;
        } // Since we only observe the one element, we don't need to loop over the
        // array


        if (!entries.length) {
          return;
        }

        const entry = entries[0];
        let width;
        let height;

        if ("borderBoxSize" in entry) {
          const borderSizeEntry = entry["borderBoxSize"]; // iron out differences between browsers

          const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
          width = borderSize["inlineSize"];
          height = borderSize["blockSize"];
        } else {
          // for browsers that don't support `borderBoxSize`
          // we calculate a rect ourselves to get the correct border box.
          const rect = elementToObserve.getBoundingClientRect();
          width = rect.width;
          height = rect.height;
        }

        setSize({
          width,
          height
        });
      });
      resizeObserver.observe(elementToObserve, {
        box: "border-box"
      });
      return () => {
        setSize(undefined);
        resizeObserver.unobserve(elementToObserve);
      };
    }

    return;
  }, [refToObserve]);
  return size;
}
;// CONCATENATED MODULE: ../hooks/src/useWindowSize.ts

function useWindowSize() {
  const {
    0: size,
    1: setSize
  } = useState( false ? 0 : {
    width: 0,
    height: 0
  });
  useEffect(() => {
    function handleLayoutChange() {
      setSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    }

    window.addEventListener("resize", handleLayoutChange);
    return () => {
      window.removeEventListener("resize", handleLayoutChange);
    };
  }, []);
  return size;
}
;// CONCATENATED MODULE: ../hooks/src/index.ts







/***/ }),

/***/ 5865:
/***/ (() => {



/***/ }),

/***/ 6221:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "NullAddress": () => (/* reexport */ NullAddress),
  "UTF16": () => (/* reexport */ UTF16),
  "copyToClipboard": () => (/* reexport */ copyToClipboard),
  "decodeQueryParameters": () => (/* reexport */ decodeQueryParameters),
  "encodeQueryParameters": () => (/* reexport */ encodeQueryParameters),
  "fetchData": () => (/* reexport */ fetchData),
  "getAllFunctionFragments": () => (/* reexport */ getAllFunctionFragments),
  "getFirstFunctionFragment": () => (/* reexport */ getFirstFunctionFragment),
  "getIncrementedName": () => (/* reexport */ getIncrementedName),
  "getMultiValue": () => (/* reexport */ getMultiValue),
  "getSignerFromProvider": () => (/* reexport */ getSignerFromProvider),
  "groupBy": () => (/* reexport */ groupBy),
  "isDeepEqual": () => (/* reexport */ isDeepEqual),
  "isExternalUrl": () => (/* reexport */ isExternalUrl),
  "memoize": () => (/* reexport */ memoize),
  "mergeBreakpoints": () => (/* reexport */ mergeBreakpoints),
  "range": () => (/* reexport */ range),
  "unique": () => (/* reexport */ unique),
  "upperFirst": () => (/* reexport */ upperFirst),
  "withSeparatorElements": () => (/* reexport */ withSeparatorElements)
});

// UNUSED EXPORTS: initMiddleware, isAbsoluteUrl, parseUrl

;// CONCATENATED MODULE: ../utils/src/types.ts
const NullAddress = '0x0000000000000000000000000000000000000000';
;// CONCATENATED MODULE: ../utils/src/range.ts
// Adapted from lodash (MIT): https://github.com/lodash/lodash/blob/4.17.15/lodash.js#L6839

/**
 * Creates an array of numbers (positive and/or negative) progressing from start up to,
 * but not including, end. A step of -1 is used if a negative start is specified without
 * an end or step. If end is not specified, it's set to start with start then set to 0.
 *
 * @param {number} start The start of the range.
 * @param {number} end The end of the range.
 * @param {number} step The value to increment or decrement by.
 * @returns {Array} Returns the range of numbers.
 */
function range(start, end, step) {
  var _step;

  if (end === undefined) {
    end = start;
    start = 0;
  }

  step = (_step = step) !== null && _step !== void 0 ? _step : start < end ? 1 : -1;
  let index = -1;
  let length = Math.max(Math.ceil((end - start) / (step || 1)), 0);
  const result = Array(length);

  while (length--) {
    result[++index] = start;
    start += step;
  }

  return result;
}
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ../utils/src/withSeparatorElements.ts


function createKey(key) {
  return `s-${key}`;
}

function withSeparatorElements(elements, separator) {
  const childrenArray = external_react_.Children.toArray(elements);

  for (let i = childrenArray.length - 1; i > 0; i--) {
    let sep = typeof separator === 'function' ? separator() : /*#__PURE__*/(0,external_react_.isValidElement)(separator) ? /*#__PURE__*/(0,external_react_.cloneElement)(separator, {
      key: createKey(i)
    }) : separator;

    if ( /*#__PURE__*/(0,external_react_.isValidElement)(sep) && sep.key == null) {
      sep = /*#__PURE__*/(0,external_react_.cloneElement)(sep, {
        key: createKey(i)
      });
    }

    childrenArray.splice(i, 0, sep);
  }

  return childrenArray;
}
;// CONCATENATED MODULE: ../utils/src/url.ts
const externalLinkRE = /https?:/;
function isExternalUrl(url) {
  return !!externalLinkRE.exec(url);
}
function isAbsoluteUrl(url) {
  return url.startsWith('/');
}
/**
 * Parses a url, returning a pathname, query, and fragment.
 *
 * The query and fragment do not include a leading "?" or "#".
 *
 * @param url
 */

function parseUrl(url) {
  const normalized = isExternalUrl(url) ? url : isAbsoluteUrl(url) ? `http://a.com${url}` : `http://a.com/${url}`;
  const {
    pathname,
    search,
    hash
  } = new URL(normalized);
  return {
    pathname,
    query: search.slice(1),
    fragment: hash.slice(1)
  };
}
function decodeQueryParameters(encodedParameters) {
  if (!encodedParameters) return {};
  const params = encodedParameters.split('&').reduce((params, item) => {
    const [key, value] = item.split('=');
    params[decodeURIComponent(key)] = decodeURIComponent(value);
    return params;
  }, {});
  return params;
}
function encodeQueryParameters(parameters) {
  const encoded = [];

  for (const key in parameters) {
    encoded.push(`${key}=${encodeURIComponent(parameters[key])}`);
  }

  return encoded.join('&');
}
;// CONCATENATED MODULE: ../utils/src/internal/isEqual.ts
function isEqualArray(a, b, deep) {
  if (a === b) return true;
  if (a.length !== b.length) return false;

  for (let i = 0; i < a.length; i++) {
    if (!(deep ? isEqual(a[i], b[i], deep) : a[i] === b[i])) {
      return false;
    }
  }

  return true;
}

function isEqualObject(a, b, deep) {
  if (a === b) return true;
  if (!a || !b) return false;
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;

  for (let i = 0; i < aKeys.length; i++) {
    const key = aKeys[i];

    if (!(deep ? isEqual(a[key], b[key], deep) : a[key] === b[key]) || !Object.prototype.hasOwnProperty.call(b, key)) {
      return false;
    }
  }

  return true;
}

function isEqual(a, b, deep) {
  const aType = typeof a;
  const bType = typeof b;
  if (aType !== bType) return false;
  if (aType !== 'object') return a === b;

  if (a instanceof Array && b instanceof Array) {
    return isEqualArray(a, b, deep);
  }

  return isEqualObject(a, b, deep);
}
;// CONCATENATED MODULE: ../utils/src/isDeepEqual.ts

function isDeepEqual(a, b) {
  return isEqual(a, b, true);
}
// EXTERNAL MODULE: ../utils/src/GuidebookConfig.ts
var GuidebookConfig = __webpack_require__(5865);
;// CONCATENATED MODULE: ../utils/src/breakpoints.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function mergeBreakpoints(breakpoints, transform) {
  const breakpointMap = Array.isArray(breakpoints) ? breakpoints.reduce((result, item) => {
    const [key, value] = item;
    result[key] = result[key] ? _objectSpread(_objectSpread({}, result[key]), value) : value;
    return result;
  }, {}) : breakpoints;
  const breakpointList = Object.entries(breakpointMap);
  const transformedList = breakpointList.sort((a, b) => Number(b[0]) - Number(a[0])).map(([width, value]) => {
    var _transform;

    return [`@media screen and (max-width: ${width}px)`, (_transform = transform === null || transform === void 0 ? void 0 : transform(value)) !== null && _transform !== void 0 ? _transform : value];
  });
  return Object.fromEntries(transformedList);
}
// EXTERNAL MODULE: external "cross-fetch"
var external_cross_fetch_ = __webpack_require__(9031);
var external_cross_fetch_default = /*#__PURE__*/__webpack_require__.n(external_cross_fetch_);
;// CONCATENATED MODULE: ../utils/src/fetchData.ts


/**
 * Fetch from a url.
 *
 * If the response status code is >=400, throw an error.
 *
 * @param url
 */
async function fetchData(url, encoding) {
  const response = await external_cross_fetch_default()(url);

  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}`);
  }

  switch (encoding) {
    case 'text':
      return response.text();

    case 'arrayBuffer':
      return response.arrayBuffer();

    case 'json':
      return response.json();
  }
}
;// CONCATENATED MODULE: ../utils/src/utf16.ts
function toUTF8(string) {
  const encoder = new TextEncoder();
  return encoder.encode(string);
}

function fromUTF8(encoded) {
  const decoder = new TextDecoder();
  return decoder.decode(encoded);
}

const UTF16 = {
  toUTF8,
  fromUTF8
};
;// CONCATENATED MODULE: ../utils/src/upperFirst.ts
function upperFirst(string) {
  return string.slice(0, 1).toUpperCase() + string.slice(1);
}
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
;// CONCATENATED MODULE: ../utils/src/ethersUtils.ts

function getFirstFunctionFragment(interface_, filters) {
  const results = getAllFunctionFragments(interface_, filters);
  return results.length > 0 ? results[0] : undefined;
}
function getSignerFromProvider(provider) {
  return provider instanceof external_ethers_.ethers.providers.Web3Provider ? provider.getSigner() : undefined;
}
function getAllFunctionFragments(interface_, filters = {}) {
  const results = interface_.fragments.filter(fragment => fragment.type === 'function');
  return applyFilters(results, [typeof filters.name === 'string' && (fragment => fragment.name === filters.name), typeof filters.inputs === 'number' && (fragment => fragment.inputs.length === filters.inputs), filters.stateMutability !== undefined && (fragment => Array.isArray(filters.stateMutability) ? filters.stateMutability.includes(fragment.stateMutability) : fragment.stateMutability === filters.stateMutability), filters.outputs !== undefined && (fragment => {
    const filter = filters.outputs;

    if (fragment.outputs && filter) {
      return fragment.outputs.length === filter.length && fragment.outputs.every((item, index) => item.type === filter[index]);
    }

    return true;
  })]);
}

function applyFilters(items, filters) {
  return filters.reduce((result, filter) => typeof filter === 'function' ? result.filter(filter) : result, items);
}
;// CONCATENATED MODULE: ../utils/src/unique.ts
function unique(array) {
  return [...new Set(array)];
}
;// CONCATENATED MODULE: ../utils/src/getIncrementedName.ts
const numberSuffixRegExp = /(.*?)(\d+)?$/;
function getIncrementedName(originalName, names) {
  const [, prefix] = originalName.match(numberSuffixRegExp) || [];
  const numbers = [originalName, ...names].filter(name => name.startsWith(prefix)).map(name => {
    const [,, number] = name.match(numberSuffixRegExp) || [];
    return number ? parseInt(number) : 1;
  }).sort();
  const maxNumber = numbers[numbers.length - 1];
  return `${prefix} ${maxNumber + 1}`;
}
;// CONCATENATED MODULE: ../utils/src/getMultiValue.ts
function getMultiValue(values, isEqual = (a, b) => a === b) {
  if (values.length === 1) {
    return values[0];
  } else if (values.length > 1) {
    const first = values[0];
    return values.every(v => isEqual(v, first)) ? first : undefined;
  } else {
    return undefined;
  }
}
;// CONCATENATED MODULE: ../utils/src/groupBy.ts
function groupBy(values, projection) {
  const result = {};
  values.forEach(value => {
    const key = projection(value);

    if (key in result) {
      result[key].push(value);
    } else {
      result[key] = [value];
    }
  });
  return result;
}
;// CONCATENATED MODULE: ../utils/src/memoize.ts
/**
 * @param f
 * @returns A memoized version of the function, using the first argument as the key.
 */
function memoize(f) {
  const cache = new Map();
  return (...values) => {
    if (!cache.has(values[0])) {
      cache.set(values[0], f(...values));
    }

    return cache.get(values[0]);
  };
}
;// CONCATENATED MODULE: ../utils/src/clipboard.ts
function triggerCopyEvent() {
  const isSafari = /Apple Computer/.test(navigator.vendor);

  if (isSafari) {
    var _window$getSelection, _window$getSelection2;

    const range = document.createRange();
    range.selectNode(document.body);
    (_window$getSelection = window.getSelection()) === null || _window$getSelection === void 0 ? void 0 : _window$getSelection.removeAllRanges();
    (_window$getSelection2 = window.getSelection()) === null || _window$getSelection2 === void 0 ? void 0 : _window$getSelection2.addRange(range);
  }

  document.execCommand('copy');

  if (isSafari) {
    var _window$getSelection3;

    (_window$getSelection3 = window.getSelection()) === null || _window$getSelection3 === void 0 ? void 0 : _window$getSelection3.removeAllRanges();
  }
}

function copyToClipboard(text) {
  const handler = event => {
    var _event$clipboardData;

    event.preventDefault();
    (_event$clipboardData = event.clipboardData) === null || _event$clipboardData === void 0 ? void 0 : _event$clipboardData.setData('text/plain', text);
  };

  document.addEventListener('copy', handler);
  triggerCopyEvent();
  document.removeEventListener('copy', handler);
}
;// CONCATENATED MODULE: ../utils/src/index.ts




















/***/ })

};
;
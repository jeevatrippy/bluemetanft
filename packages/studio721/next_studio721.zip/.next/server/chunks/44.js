"use strict";
exports.id = 44;
exports.ids = [44];
exports.modules = {

/***/ 4044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "jK": () => (/* reexport */ getCurrencySymbol),
  "w9": () => (/* reexport */ priceToString),
  "IH": () => (/* reexport */ useReadOnlyContractData)
});

// UNUSED EXPORTS: callReadOnlyContractFunction, functionOutputToString

// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(5757);
// EXTERNAL MODULE: external "@ethersproject/units"
var units_ = __webpack_require__(3138);
// EXTERNAL MODULE: external "@openpalette/contract"
var contract_ = __webpack_require__(4008);
// EXTERNAL MODULE: ../components/src/index.ts + 31 modules
var src = __webpack_require__(9615);
;// CONCATENATED MODULE: ../contract-data/src/format.ts




function getCurrencySymbol(chainId) {
  switch (chainId) {
    case contract_.CHAIN_ID.POLYGON:
    case contract_.CHAIN_ID.MUMBAI:
      return `MATIC`;

    default:
      return `Ξ`;
  }
}
function priceToString(chainId, value) {
  const minimumValue = (0,units_.parseEther)('0.001'); // A large value is probably ether

  if (value.gte(minimumValue)) {
    return value.div(minimumValue).toNumber() / 1000 + ' ' + getCurrencySymbol(chainId);
  }

  return value.toString();
}
function functionOutputToString(chainId, fragment, output) {
  if (fragment.outputs && fragment.outputs.length > 0) {
    const outputType = fragment.outputs[0].type;

    switch (outputType) {
      case 'address':
        return formatDisplayAddress(output.toString());
    }
  }

  if (BigNumber.isBigNumber(output)) {
    return priceToString(chainId, output);
  }

  return output.toString();
}
// EXTERNAL MODULE: external "@ethersproject/contracts"
var contracts_ = __webpack_require__(2792);
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: ../web3-utils/src/index.ts + 4 modules
var web3_utils_src = __webpack_require__(9772);
;// CONCATENATED MODULE: ../contract-data/src/call.ts






function isPolygonOrMumbai(chainId) {
  return chainId === contract_.CHAIN_ID.MUMBAI || chainId === contract_.CHAIN_ID.POLYGON;
}

async function fetchJsonRpcData(infuraProjectId, {
  chainId,
  fragment,
  contract,
  args = []
}) {
  if (isPolygonOrMumbai(chainId)) {
    throw new Error('Unsupported chain for JsonRpc');
  }

  const provider = new external_ethers_.ethers.providers.JsonRpcProvider(`https://${(0,contract_.getChainName)(chainId)}.infura.io/v3/${infuraProjectId}`);
  const contractWithProvider = new contracts_.Contract(contract.address, contract.interface, provider);
  return contractWithProvider.callStatic[fragment.name](...args);
}

async function fetchEthorActorData({
  chainId,
  address,
  fragment,
  args
}) {
  const components = [(0,web3_utils_src/* getEtherActorBaseURL */.Ui)(chainId), address, fragment.name, ...args];
  const response = await fetch(components.join('/'));
  const result = await response.text();
  let json;

  try {
    json = JSON.parse(result);
  } catch (e) {//
  }

  if (typeof json === 'object' && json !== null && typeof json.statusCode === 'number' && json.statusCode > 200) {
    throw new Error('Failed to fetch contract data');
  }

  if (fragment.outputs && fragment.outputs.length > 0) {
    const outputType = fragment.outputs[0].type;

    switch (outputType) {
      case 'uint256':
        return bignumber_.BigNumber.from(result);

      case 'bool':
        return result === 'true';
    }
  }

  return result;
}

async function callReadOnlyContractFunction(chainId, fragment, contract, providerChainId, args = []) {
  if (fragment.stateMutability !== 'view') {
    throw new Error('Not a read-only function');
  }

  const infuraProjectId = process.env.NEXT_PUBLIC_INFURA_PROJECT_ID; // Try fetching from both ether.actor and the connected provider.
  // Sometimes one will fail, so this gives a better change of
  // getting data quickly.

  const output = await Promise.any([fetchEthorActorData({
    chainId,
    address: contract.address,
    fragment,
    args
  }), ...(infuraProjectId && !isPolygonOrMumbai(chainId) ? [fetchJsonRpcData(infuraProjectId, {
    chainId,
    fragment,
    contract,
    args
  })] : []), ...(contract.provider && providerChainId === chainId ? [contract.callStatic[fragment.name](...args)] : [])]).catch(errors => Promise.reject(errors[0]));
  return output;
}
// EXTERNAL MODULE: ../contexts/src/index.ts + 2 modules
var contexts_src = __webpack_require__(9022);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ../contract-data/src/hooks.ts



function useReadOnlyContractData({
  fragment,
  contract,
  chainId,
  args
}) {
  const {
    0: result,
    1: setResult
  } = (0,external_react_.useState)({
    type: 'pending'
  });
  const providerChainId = (0,contexts_src/* useChainId */.xx)();
  (0,external_react_.useEffect)(() => {
    let isStale = false;

    async function main() {
      try {
        if (!contract || !fragment || !chainId) return;
        const result = await callReadOnlyContractFunction(chainId, fragment, contract, providerChainId, args);
        if (isStale) return;
        setResult({
          type: 'success',
          value: result
        });
      } catch (e) {
        if (isStale) return;
        setResult({
          type: 'failure',
          value: e
        });
      }
    }

    main();
    return () => {
      isStale = true;
    };
  }, [fragment, contract, chainId, providerChainId, args]);
  return result;
}
;// CONCATENATED MODULE: ../contract-data/src/index.ts





/***/ })

};
;
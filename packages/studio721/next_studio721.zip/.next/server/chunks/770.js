"use strict";
exports.id = 770;
exports.ids = [770];
exports.modules = {

/***/ 7770:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C3": () => (/* binding */ baseURIToHTTPS),
/* harmony export */   "u2": () => (/* binding */ proxyURL),
/* harmony export */   "a0": () => (/* binding */ TokenPreview)
/* harmony export */ });
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4008);
/* harmony import */ var _openpalette_contract__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openpalette_contract__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9693);
/* harmony import */ var _radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9615);
/* harmony import */ var contexts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9022);
/* harmony import */ var designsystem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1801);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5781);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var solidity_codegen__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(656);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6221);
/* harmony import */ var contract_data__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4044);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([designsystem__WEBPACK_IMPORTED_MODULE_4__]);
designsystem__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];














function baseURIToHTTPS(baseURI) {
  if (baseURI.startsWith('ipfs://')) {
    return baseURI.replace('ipfs://', 'https://ipfs.io/ipfs/');
  }

  return baseURI;
}
function proxyURL(url) {
  return `/api/proxy?${(0,utils__WEBPACK_IMPORTED_MODULE_8__.encodeQueryParameters)({
    url
  })}`;
}
const TokenPreview = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_6__.memo)(function TokenPreview({
  dispatch,
  config,
  disabled
}) {
  var _generateURI, _config$supply, _config$price, _config$royaltyBps, _config$contractURI;

  const {
    0: tokenPreviewId,
    1: setTokenPreviewId
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(0);
  const parsedURI = (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_7__/* .parseURITemplate */ .P5)(config.tokenURI);
  const tokenURI = (_generateURI = (0,solidity_codegen__WEBPACK_IMPORTED_MODULE_7__/* .generateURI */ .f7)(config.tokenURI, tokenPreviewId, config.tokenParameters)) !== null && _generateURI !== void 0 ? _generateURI : '';
  const httpsTokenURI = baseURIToHTTPS(tokenURI);
  const proxyTokenURI = proxyURL(httpsTokenURI);
  const tokenMetadata = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useFetch */ .ib)(proxyTokenURI, 'json');
  const tokenImageUrl = tokenMetadata.type === 'success' && tokenMetadata.value.image;
  const chainId = (0,contexts__WEBPACK_IMPORTED_MODULE_3__/* .useChainId */ .xx)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
    background: "linear-gradient(to bottom right, #6A78FD, #8163FF)",
    justifyContent: "center",
    padding: 20,
    margin: '0 -40px',
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
      background: '#222',
      padding: 20,
      gap: 8,
      boxShadow: ['1.3px 1.6px 2.2px rgba(0, 0, 0, 0.031)', '3.2px 3.9px 5.3px rgba(0, 0, 0, 0.044)', '6px 7.3px 10px rgba(0, 0, 0, 0.055)', '10.7px 13px 17.9px rgba(0, 0, 0, 0.066)', '20.1px 24.2px 33.4px rgba(0, 0, 0, 0.079)', '48px 58px 80px rgba(0, 0, 0, 0.11)'].join(', '),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
        alignItems: "center",
        background: "black",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
          width: 300,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_radix_ui_react_aspect_ratio__WEBPACK_IMPORTED_MODULE_1__.Root, {
            ratio: 1,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
              width: '100%',
              height: '100%',
              padding: 10,
              background: ['black', ...(tokenImageUrl ? [`center / cover url("${baseURIToHTTPS(tokenImageUrl)}")`] : [])].join(' '),
              alignItems: "flex-start",
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
                gap: 8,
                background: "#222",
                alignItems: "center",
                padding: "4px 8px",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                  flex: "0 0 auto",
                  children: "Preview of Token"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
                  width: "60px",
                  opacity: 0.8,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
                    id: "input-token-preview-id",
                    size: 60,
                    flex: "0 0 60px",
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.NumberInput */ .UP.Y2, {
                      value: tokenPreviewId,
                      onNudge: (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(value => {
                        setTokenPreviewId(x => x + value);
                      }, []),
                      onChange: (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(value => {
                        const numberValue = Number(value);
                        if (!Number.isInteger(numberValue)) return;
                        setTokenPreviewId(numberValue);
                      }, [])
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .InfoHoverCard */ .No, {
                  top: "0",
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                    gap: 8,
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                      children: "Token URI"
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                      background: "black",
                      padding: 8,
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
                        children: tokenURI
                      })
                    }), tokenURI !== httpsTokenURI && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                        children: "HTTPS URI"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                        background: "black",
                        padding: 8,
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
                          children: httpsTokenURI
                        })
                      })]
                    }), tokenMetadata.type === 'success' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                        children: "The metadata for this token:"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                        overflowY: "auto",
                        background: "black",
                        padding: 8,
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                          flex: "1 1 0px",
                          maxHeight: "300px",
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .CodeHighlight */ .P4, {
                            code: JSON.stringify(tokenMetadata.value, null, 2),
                            language: "json"
                          })
                        })
                      })]
                    }), tokenMetadata.type === 'pending' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                        className: "flickerAnimation",
                        children: "Fetching metadata..."
                      })
                    }), tokenMetadata.type === 'failure' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Small */ .x4, {
                        children: "Failed to fetch metadata..."
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .VStack */ .gC, {
                        padding: 8,
                        background: "black",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
                          children: tokenMetadata.value.message
                        })
                      })]
                    })]
                  })
                })]
              })
            })
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Name",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["The name of the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
            openInNewTab: true,
            href: "https://docs.openzeppelin.com/contracts/2.x/api/token/erc721",
            children: "ERC 721"
          }), ' ', "non-fungible token (NFT). This also becomes the name of the smart contract. The name will be detected automatically by some marketplaces like OpenSea."]
        }),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-token-name",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Input */ .UP.II, {
            disabled: disabled,
            value: config.tokenName,
            onChange: (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(value => {
              dispatch({
                type: 'setTokenName',
                value
              });
            }, [dispatch])
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Abbreviation",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["A short, usually 3-4 letter abbreviation for the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
            href: "https://docs.openzeppelin.com/contracts/2.x/api/token/erc721",
            openInNewTab: true,
            children: "ERC 721"
          }), ' ', "token. This typically isn", "'", "t used for much with NFTs, though it sometimes appears on e.g. rarity tracking tools."]
        }),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-short-name",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Input */ .UP.II, {
            disabled: disabled,
            value: config.shortName,
            onChange: value => {
              dispatch({
                type: 'setShortName',
                value
              });
            }
          })
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Supply",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["The total quantity of NFTs that can be minted.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "If you don't want to limit the quantity that can be minted, uncheck this option."]
        }),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.supply !== null,
          onCheckedChange: value => {
            dispatch({
              type: 'setSupply',
              value: value ? 2000 : null
            });
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-supply",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.NumberInput */ .UP.Y2, {
            disabled: disabled || config.supply === null,
            value: (_config$supply = config.supply) !== null && _config$supply !== void 0 ? _config$supply : undefined,
            placeholder: 'Unlimited',
            onSubmit: value => {
              const numberValue = Number(value);
              if (!Number.isInteger(numberValue) && numberValue > 0) return;
              dispatch({
                type: 'setSupply',
                value: numberValue
              });
            }
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Price",
        variant: "small",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.price !== undefined,
          onCheckedChange: value => {
            dispatch({
              type: 'setPrice',
              value: value ? '0.02' : undefined
            });
          }
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-price",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.NumberInput */ .UP.Y2, {
            disabled: disabled || config.price === undefined,
            value: Number((_config$price = config.price) !== null && _config$price !== void 0 ? _config$price : '0'),
            onSubmit: value => {
              dispatch({
                type: 'setPrice',
                value: value.toString()
              });
            }
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Label */ .UP.__, {
            children: (0,contract_data__WEBPACK_IMPORTED_MODULE_9__/* .getCurrencySymbol */ .jK)(chainId || _openpalette_contract__WEBPACK_IMPORTED_MODULE_0__.CHAIN_ID.MAINNET)
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Royalties",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["A percentage of each sale paid back to this NFT contract. Call the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("code", {
            children: "withdraw()"
          }), " function to transfer funds from this contract to the payout addresses you configure below.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "Note: it's currently the responsibility of the marketplace (e.g. OpenSea) to honor the number set here."]
        }),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.royaltyBps !== undefined,
          onCheckedChange: value => {
            dispatch({
              type: 'setRoyaltyBps',
              value: value ? '10' : undefined
            });
          }
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-royalties",
          labelSize: 12,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.NumberInput */ .UP.Y2, {
            disabled: disabled || config.royaltyBps === undefined,
            value: Number((_config$royaltyBps = config.royaltyBps) !== null && _config$royaltyBps !== void 0 ? _config$royaltyBps : '0'),
            onSubmit: value => {
              dispatch({
                type: 'setRoyaltyBps',
                value: value.toString()
              });
            }
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Label */ .UP.__, {
            children: "%"
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Token URI",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["The URI of the metadata for each token.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "The ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
            children: `{tokenId}`
          }), " variable will be replaced with the current token ID. As an example,", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
            children: ["https://www.721.so/api/example/metadata/", `{tokenId}`]
          }), ' ', "becomes", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
            openInNewTab: true,
            href: "https://www.721.so/api/example/metadata/0",
            children: "https://www.721.so/api/example/metadata/0"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "If you choose to add parameters to your NFT, you can use the", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Code */ .EK, {
            children: `{parameters}`
          }), " variable to add them in a query string.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "The part of the URI before any bracket variables can be changed after deploying the contract by calling ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("code", {
            children: "setBaseURI"
          }), ".", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "The metadata should be a JSON object as documented here on OpenSea:", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
            openInNewTab: true,
            href: "https://docs.opensea.io/docs/metadata-standards#metadata-structure",
            children: "Metadata structure"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .Blockquote */ .V6, {
            style: {
              fontSize: 'inherit'
            },
            children: ["Studio 721 doesn", "'", "t host your assets or metadata - you can host it anywhere you like.", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
              href: "https://ipfs.io/",
              openInNewTab: true,
              children: "IPFS"
            }), ' ', "is a popular decentalized solution for hosting NFT assets and metadata, but you can also use more traditional hosting services like", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
              href: "https://aws.amazon.com/s3/",
              openInNewTab: true,
              children: "Amazon S3"
            }), "."]
          })]
        }),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .HStack */ .Ug, {
          flex: "1 1 auto",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .TextArea */ .Kx, {
            disabled: disabled,
            value: config.tokenURI,
            onChange: event => {
              dispatch({
                type: 'setTokenURI',
                value: event.target.value
              });
            },
            style: {
              minHeight: '100px',
              maxWidth: '1000px',
              minWidth: '0px',
              flex: '1 1 auto'
            }
          })
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRow */ .p7, {
        title: "Contract URI",
        variant: "small",
        tooltip: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
          children: ["The URI of the metadata for the marketplace storefront.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "This an OpenSea-specific feature, and most contracts don't use it. You may also configure this metadata through the OpenSea website after deploying your contract.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .SpacerVertical */ .Nw, {
            size: 20
          }), "If you choose to use this, the metadata should be a JSON object as documented here on OpenSea:", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .LinkChip */ .lE, {
            openInNewTab: true,
            href: "https://docs.opensea.io/docs/contract-level-metadata",
            children: "Contract-level Metadata"
          })]
        }),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .Checkbox */ .XZ, {
          variant: "dark",
          disabled: disabled,
          checked: config.contractURI !== undefined,
          onCheckedChange: value => {
            dispatch({
              type: 'setContractURI',
              value: value ? '' : undefined
            });
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Root */ .UP.fC, {
          id: "input-contract-uri",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(designsystem__WEBPACK_IMPORTED_MODULE_4__/* .InputField.Input */ .UP.II, {
            disabled: disabled || config.contractURI === undefined,
            value: (_config$contractURI = config.contractURI) !== null && _config$contractURI !== void 0 ? _config$contractURI : '',
            onChange: value => {
              dispatch({
                type: 'setContractURI',
                value
              });
            }
          })
        })]
      }), parsedURI.type === 'failure' && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components__WEBPACK_IMPORTED_MODULE_2__/* .FormRowError */ .S6, {
        children: parsedURI.message
      })]
    })
  });
});
});

/***/ })

};
;